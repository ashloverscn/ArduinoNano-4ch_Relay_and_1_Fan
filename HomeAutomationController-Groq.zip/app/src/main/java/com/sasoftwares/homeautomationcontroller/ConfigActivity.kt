package com.sasoftwares.homeautomationcontroller

import android.content.Context
import android.content.res.ColorStateList
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.edit
import androidx.core.graphics.toColorInt
import com.sasoftwares.homeautomationcontroller.databinding.ActivityConfigBinding

class ConfigActivity : AppCompatActivity() {
    private lateinit var binding: ActivityConfigBinding
    private var editingProfile: Int = 1 // 1..4

    private data class ProfileConfig(
        var ip: String = "192.168.29.110",
        var user: String = "admin",
        var pass: String = "admin1234S",
        var mqttEnabled: Boolean = true,
        var mqttServer: String = "i11b0026.ala.eu-central-1.emqxsl.com",
        var mqttPort: Int = 8883,
        var mqttUser: String = "admin",
        var mqttPass: String = "admin1234S",
        var mqttTopicCmd: String = "home/room1/command",
        var mqttTopicState: String = "home/room1/state",
        var groqApiKey: String = "",
        var groqModel: String = DEFAULT_GROQ_MODEL,
        var wakeWord: String = DEFAULT_WAKE_WORD,
        var ttsEnabled: Boolean = true
    )

    private val profiles = Array(4) { index ->
        val num = index + 1
        ProfileConfig(
            mqttTopicCmd = "home/room$num/command",
            mqttTopicState = "home/room$num/state"
        )
    }

    companion object {
        const val PREFS_NAME = "HomeAutomationPrefs"
        const val KEY_ACTIVE_PROFILE = "active_profile" // 1..4
        const val KEY_IP = "esp_ip"
        const val KEY_USER = "esp_user"
        const val KEY_PASS = "esp_pass"
        const val KEY_MQTT_ENABLED = "mqtt_enabled"
        const val KEY_MQTT_SERVER = "mqtt_server"
        const val KEY_MQTT_PORT = "mqtt_port"
        const val KEY_MQTT_USER = "mqtt_user"
        const val KEY_MQTT_PASS = "mqtt_pass"
        const val KEY_MQTT_TOPIC_CMD = "mqtt_topic_cmd"
        const val KEY_MQTT_TOPIC_STATE = "mqtt_topic_state"
        const val KEY_GROQ_API_KEY = "groq_api_key"
        const val KEY_GROQ_MODEL = "groq_model"
        const val KEY_WAKE_WORD = "wake_word"
        const val KEY_TTS_ENABLED = "tts_enabled"

        const val DEFAULT_GROQ_MODEL = "openai/gpt-oss-120b"
        const val DEFAULT_WAKE_WORD = "hey home, home, hey there home, ok home, hi home"

        fun key(baseKey: String, profile: Int): String {
            return "p${profile}_$baseKey"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityConfigBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        editingProfile = prefs.getInt(KEY_ACTIVE_PROFILE, 1).coerceIn(1, 4)

        loadAllProfilesFromPrefs()
        setupProfileTabs()
        updateTabVisuals()
        displayProfileInForm(editingProfile)

        binding.btnSave.setOnClickListener {
            captureFormIntoMemory(editingProfile)
            saveAllProfilesToPrefs()
            Toast.makeText(this, "All 4 Configurations Saved!", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun setupProfileTabs() {
        val tabs = listOf(binding.btnTab1, binding.btnTab2, binding.btnTab3, binding.btnTab4)
        tabs.forEachIndexed { idx, button ->
            val targetProfile = idx + 1
            button.setOnClickListener {
                if (targetProfile == editingProfile) return@setOnClickListener
                captureFormIntoMemory(editingProfile)
                editingProfile = targetProfile
                updateTabVisuals()
                displayProfileInForm(editingProfile)
            }
        }
    }

    private fun updateTabVisuals() {
        val tabs = listOf(binding.btnTab1, binding.btnTab2, binding.btnTab3, binding.btnTab4)
        tabs.forEachIndexed { idx, button ->
            val profileNum = idx + 1
            val isSelected = profileNum == editingProfile
            val bgColor = if (isSelected) "#2E7D32" else "#6200EE"
            button.backgroundTintList = ColorStateList.valueOf(bgColor.toColorInt())
            button.setTextColor("#FFFFFF".toColorInt())
        }
    }

    private fun loadAllProfilesFromPrefs() {
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

        for (profile in 1..4) {
            val defaultIp = if (profile == 1) {
                prefs.getString(KEY_IP, "192.168.29.110") ?: "192.168.29.110"
            } else {
                "192.168.29.110"
            }

            profiles[profile - 1] = ProfileConfig(
                ip = prefs.getString(key(KEY_IP, profile), defaultIp) ?: defaultIp,
                user = prefs.getString(key(KEY_USER, profile), prefs.getString(KEY_USER, "admin")) ?: "admin",
                pass = prefs.getString(key(KEY_PASS, profile), prefs.getString(KEY_PASS, "admin1234S")) ?: "admin1234S",
                mqttEnabled = prefs.getBoolean(key(KEY_MQTT_ENABLED, profile), prefs.getBoolean(KEY_MQTT_ENABLED, true)),
                mqttServer = prefs.getString(
                    key(KEY_MQTT_SERVER, profile),
                    prefs.getString(KEY_MQTT_SERVER, "i11b0026.ala.eu-central-1.emqxsl.com")
                ) ?: "i11b0026.ala.eu-central-1.emqxsl.com",
                mqttPort = prefs.getInt(key(KEY_MQTT_PORT, profile), prefs.getInt(KEY_MQTT_PORT, 8883)),
                mqttUser = prefs.getString(key(KEY_MQTT_USER, profile), prefs.getString(KEY_MQTT_USER, "admin")) ?: "admin",
                mqttPass = prefs.getString(key(KEY_MQTT_PASS, profile), prefs.getString(KEY_MQTT_PASS, "admin1234S")) ?: "admin1234S",
                mqttTopicCmd = prefs.getString(key(KEY_MQTT_TOPIC_CMD, profile), "home/room$profile/command")
                    ?: "home/room$profile/command",
                mqttTopicState = prefs.getString(key(KEY_MQTT_TOPIC_STATE, profile), "home/room$profile/state")
                    ?: "home/room$profile/state",
                groqApiKey = prefs.getString(key(KEY_GROQ_API_KEY, profile), "") ?: "",
                groqModel = prefs.getString(key(KEY_GROQ_MODEL, profile), DEFAULT_GROQ_MODEL)
                    ?.ifEmpty { DEFAULT_GROQ_MODEL } ?: DEFAULT_GROQ_MODEL,
                wakeWord = prefs.getString(key(KEY_WAKE_WORD, profile), DEFAULT_WAKE_WORD)
                    ?.trim()?.lowercase()?.ifEmpty { DEFAULT_WAKE_WORD } ?: DEFAULT_WAKE_WORD,
                ttsEnabled = prefs.getBoolean(key(KEY_TTS_ENABLED, profile), true)
            )
        }
    }

    private fun displayProfileInForm(profile: Int) {
        val cfg = profiles[profile - 1]
        binding.etIp.setText(cfg.ip)
        binding.etUser.setText(cfg.user)
        binding.etPass.setText(cfg.pass)
        binding.cbMqttEnabled.isChecked = cfg.mqttEnabled
        binding.etMqttServer.setText(cfg.mqttServer)
        binding.etMqttPort.setText(cfg.mqttPort.toString())
        binding.etMqttUser.setText(cfg.mqttUser)
        binding.etMqttPass.setText(cfg.mqttPass)
        binding.etMqttTopicCmd.setText(cfg.mqttTopicCmd)
        binding.etMqttTopicState.setText(cfg.mqttTopicState)
        binding.etGroqApiKey.setText(cfg.groqApiKey)
        binding.etGroqModel.setText(cfg.groqModel.ifEmpty { DEFAULT_GROQ_MODEL })
        binding.etWakeWord.setText(cfg.wakeWord.ifEmpty { DEFAULT_WAKE_WORD })
        binding.cbEnableTts.isChecked = cfg.ttsEnabled
    }

    private fun captureFormIntoMemory(profile: Int) {
        val portInt = binding.etMqttPort.text.toString().toIntOrNull() ?: 8883
        val modelStr = binding.etGroqModel.text.toString().trim().ifEmpty { DEFAULT_GROQ_MODEL }
        val wakeStr = binding.etWakeWord.text.toString().trim().lowercase().ifEmpty { DEFAULT_WAKE_WORD }
        profiles[profile - 1] = ProfileConfig(
            ip = binding.etIp.text.toString().trim(),
            user = binding.etUser.text.toString().trim(),
            pass = binding.etPass.text.toString().trim(),
            mqttEnabled = binding.cbMqttEnabled.isChecked,
            mqttServer = binding.etMqttServer.text.toString().trim(),
            mqttPort = portInt,
            mqttUser = binding.etMqttUser.text.toString().trim(),
            mqttPass = binding.etMqttPass.text.toString().trim(),
            mqttTopicCmd = binding.etMqttTopicCmd.text.toString().trim(),
            mqttTopicState = binding.etMqttTopicState.text.toString().trim(),
            groqApiKey = binding.etGroqApiKey.text.toString().trim(),
            groqModel = modelStr,
            wakeWord = wakeStr,
            ttsEnabled = binding.cbEnableTts.isChecked
        )
    }

    private fun saveAllProfilesToPrefs() {
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit {
            for (profile in 1..4) {
                val cfg = profiles[profile - 1]
                putString(key(KEY_IP, profile), cfg.ip)
                putString(key(KEY_USER, profile), cfg.user)
                putString(key(KEY_PASS, profile), cfg.pass)
                putBoolean(key(KEY_MQTT_ENABLED, profile), cfg.mqttEnabled)
                putString(key(KEY_MQTT_SERVER, profile), cfg.mqttServer)
                putInt(key(KEY_MQTT_PORT, profile), cfg.mqttPort)
                putString(key(KEY_MQTT_USER, profile), cfg.mqttUser)
                putString(key(KEY_MQTT_PASS, profile), cfg.mqttPass)
                putString(key(KEY_MQTT_TOPIC_CMD, profile), cfg.mqttTopicCmd)
                putString(key(KEY_MQTT_TOPIC_STATE, profile), cfg.mqttTopicState)
                putString(key(KEY_GROQ_API_KEY, profile), cfg.groqApiKey)
                putString(key(KEY_GROQ_MODEL, profile), cfg.groqModel.ifEmpty { DEFAULT_GROQ_MODEL })
                putString(key(KEY_WAKE_WORD, profile), cfg.wakeWord.trim().lowercase().ifEmpty { DEFAULT_WAKE_WORD })
                putBoolean(key(KEY_TTS_ENABLED, profile), cfg.ttsEnabled)
            }
        }
    }
}