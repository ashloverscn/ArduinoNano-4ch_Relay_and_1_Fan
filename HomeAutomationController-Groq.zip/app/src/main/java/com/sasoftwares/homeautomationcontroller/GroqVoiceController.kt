package com.sasoftwares.homeautomationcontroller

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

class GroqVoiceController(
    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()
) {
    companion object {
        const val SAMPLE_RATE = 16000
        const val MAX_RECORD_SECONDS = 6
        const val GROQ_TRANSCRIPTIONS_URL = "https://api.groq.com/openai/v1/audio/transcriptions"
        const val GROQ_CHAT_URL = "https://api.groq.com/openai/v1/chat/completions"
        const val WHISPER_MODEL = "whisper-large-v3-turbo"
        val FALLBACK_MODELS = listOf(
            "openai/gpt-oss-120b",
            "openai/gpt-oss-20b",
            "qwen/qwen3.8-27b"
        )
    }

    interface HardwareBridge {
        fun sendRawCommand(cmd: String)
        fun setDimmerLevel(level: Int)
        fun switchProfile(profile: Int)
        fun getRelayStates(): BooleanArray
        fun getDimmerLevel(): Int
        fun onLog(msg: String)
    }

    private val isRecording = AtomicBoolean(false)
    private val stopRequested = AtomicBoolean(false)

    fun isRecording(): Boolean = isRecording.get()

    fun requestStopRecording() {
        stopRequested.set(true)
    }

    @SuppressLint("MissingPermission")
    suspend fun recordWav(
        maxSeconds: Int = MAX_RECORD_SECONDS,
        onLog: (String) -> Unit
    ): ByteArray? = withContext(Dispatchers.IO) {
        if (isRecording.getAndSet(true)) return@withContext null
        stopRequested.set(false)

        val channelConfig = AudioFormat.CHANNEL_IN_MONO
        val audioFormat = AudioFormat.ENCODING_PCM_16BIT
        val minBuf = AudioRecord.getMinBufferSize(SAMPLE_RATE, channelConfig, audioFormat)
        val bufferSize = maxOf(minBuf, SAMPLE_RATE * 2)

        val recorder = AudioRecord(
            MediaRecorder.AudioSource.MIC,
            SAMPLE_RATE,
            channelConfig,
            audioFormat,
            bufferSize
        )

        if (recorder.state != AudioRecord.STATE_INITIALIZED) {
            isRecording.set(false)
            onLog(">> [Mic Error] AudioRecord failed to initialize.\n")
            return@withContext null
        }

        val pcmOut = ByteArrayOutputStream()
        val readBuf = ByteArray(1600)
        val startNs = System.nanoTime()
        val maxNs = maxSeconds * 1_000_000_000L

        try {
            recorder.startRecording()
            while (!stopRequested.get() && (System.nanoTime() - startNs) < maxNs) {
                val read = recorder.read(readBuf, 0, readBuf.size)
                if (read > 0) {
                    pcmOut.write(readBuf, 0, read)
                }
            }
        } catch (e: Exception) {
            onLog(">> [Mic Error] ${e.localizedMessage}\n")
        } finally {
            try {
                recorder.stop()
            } catch (_: Exception) {
            }
            recorder.release()
            isRecording.set(false)
        }

        val pcmBytes = pcmOut.toByteArray()
        if (pcmBytes.isEmpty()) return@withContext null
        pcmToWav(pcmBytes, SAMPLE_RATE, channels = 1, bitsPerSample = 16)
    }

    suspend fun transcribeWav(wavBytes: ByteArray, apiKey: String): String = withContext(Dispatchers.IO) {
        val trimmedKey = apiKey.trim()
        require(trimmedKey.isNotEmpty()) { "Groq API key is missing. Set it in Settings." }

        val audioBody = wavBytes.toRequestBody("audio/wav".toMediaType())
        val multipart = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("model", WHISPER_MODEL)
            .addFormDataPart("file", "speech.wav", audioBody)
            .build()

        val request = Request.Builder()
            .url(GROQ_TRANSCRIPTIONS_URL)
            .addHeader("Authorization", "Bearer $trimmedKey")
            .post(multipart)
            .build()

        httpClient.newCall(request).execute().use { resp ->
            val bodyStr = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) {
                throw RuntimeException("Whisper HTTP ${resp.code}: $bodyStr")
            }
            JSONObject(bodyStr).optString("text", "").trim()
        }
    }

    suspend fun runIntent(
        transcript: String,
        apiKey: String,
        primaryModel: String,
        bridge: HardwareBridge
    ): String = withContext(Dispatchers.IO) {
        val trimmedKey = apiKey.trim()
        val chosenPrimary = primaryModel.trim().ifEmpty { ConfigActivity.DEFAULT_GROQ_MODEL }
        val modelsToTry = buildList {
            add(chosenPrimary)
            for (m in FALLBACK_MODELS) {
                if (m != chosenPrimary) add(m)
            }
        }

        if (trimmedKey.isEmpty()) {
            return@withContext localFallback(transcript, bridge)
                ?: "Groq API key not set. Add it in Settings."
        }

        var lastError: Throwable? = null
        for (modelId in modelsToTry) {
            try {
                return@withContext executeChatTurn(transcript, trimmedKey, modelId, bridge)
            } catch (e: Exception) {
                lastError = e
                bridge.onLog(">> [Groq $modelId Error] ${e.localizedMessage}\n")
            }
        }

        localFallback(transcript, bridge)?.let { "$it (via local fallback)" }
            ?: throw (lastError ?: RuntimeException("Groq intent failed"))
    }

    private fun executeChatTurn(
        userPrompt: String,
        apiKey: String,
        modelId: String,
        bridge: HardwareBridge
    ): String {
        val systemMsg = JSONObject()
            .put("role", "system")
            .put(
                "content",
                "You are a smart room controller. Call tools for relays (1-4), dimmer (0-9), " +
                        "all-on/off, or status. Reply in one short sentence under 15 words."
            )
        val userMsg = JSONObject()
            .put("role", "user")
            .put("content", userPrompt)

        val messages = JSONArray().put(systemMsg).put(userMsg)
        val firstRespJson = postChatCompletion(apiKey, modelId, messages, includeTools = true)
        val choice = firstRespJson.optJSONArray("choices")?.optJSONObject(0)
        val assistantMsg = choice?.optJSONObject("message")
            ?: return "Done."

        val toolCalls = assistantMsg.optJSONArray("tool_calls")
        if (toolCalls != null && toolCalls.length() > 0) {
            val cleanAssistant = JSONObject()
                .put("role", "assistant")
                .put("content", assistantMsg.optString("content", ""))
                .put("tool_calls", toolCalls)
            messages.put(cleanAssistant)

            for (i in 0 until toolCalls.length()) {
                val tc = toolCalls.optJSONObject(i) ?: continue
                val callId = tc.optString("id", "call_$i")
                val fnObj = tc.optJSONObject("function")
                val fnName = fnObj?.optString("name", "").orEmpty()
                val argsJson = try {
                    JSONObject(fnObj?.optString("arguments", "{}").orEmpty())
                } catch (_: Exception) {
                    JSONObject()
                }

                val toolResult = executeTool(fnName, argsJson, bridge)
                messages.put(
                    JSONObject()
                        .put("role", "tool")
                        .put("tool_call_id", callId)
                        .put("content", toolResult)
                )
            }

            return try {
                val followJson = postChatCompletion(apiKey, modelId, messages, includeTools = false)
                val followReply = followJson.optJSONArray("choices")
                    ?.optJSONObject(0)
                    ?.optJSONObject("message")
                    ?.optString("content", "")
                    ?.trim()
                    .orEmpty()
                if (followReply.isNotEmpty()) followReply
                else "Done. Relays: ${bridge.getRelayStates().contentToString()}, dimmer: ${bridge.getDimmerLevel()}."
            } catch (_: Exception) {
                "Done. Relays: ${bridge.getRelayStates().contentToString()}, dimmer: ${bridge.getDimmerLevel()}."
            }
        }

        val directReply = assistantMsg.optString("content", "").trim()
        return directReply.ifEmpty { "Done." }
    }

    private fun postChatCompletion(
        apiKey: String,
        modelId: String,
        messages: JSONArray,
        includeTools: Boolean
    ): JSONObject {
        val payload = JSONObject()
            .put("model", modelId)
            .put("messages", messages)
        if (includeTools) {
            payload.put("tools", buildToolsArray())
            payload.put("tool_choice", "auto")
        }

        val reqBody = payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
        val request = Request.Builder()
            .url(GROQ_CHAT_URL)
            .addHeader("Authorization", "Bearer $apiKey")
            .post(reqBody)
            .build()

        httpClient.newCall(request).execute().use { resp ->
            val raw = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) {
                throw RuntimeException("Groq HTTP ${resp.code}: $raw")
            }
            return JSONObject(raw)
        }
    }

    private fun executeTool(name: String, args: JSONObject, bridge: HardwareBridge): String {
        return when (name) {
            "set_relay" -> {
                val ch = args.optInt("channel", 0)
                if (ch !in 1..4) return "Invalid relay channel."
                val stateStr = if (args.optBoolean("turn_on", false)) "ON" else "OFF"
                bridge.sendRawCommand("POWER$ch $stateStr")
                "Sent POWER$ch $stateStr."
            }
            "set_dimmer" -> {
                val lvl = args.optInt("level", 0).coerceIn(0, 9)
                bridge.setDimmerLevel(lvl)
                "Set dimmer to $lvl."
            }
            "set_all_relays" -> {
                val cmd = if (args.optBoolean("turn_on", false)) "ALL_ON" else "ALL_OFF"
                bridge.sendRawCommand(cmd)
                "Sent $cmd."
            }
            "get_device_status" -> {
                bridge.sendRawCommand("STATUS")
                JSONObject()
                    .put("relays", JSONArray(bridge.getRelayStates().toList()))
                    .put("dimmer", bridge.getDimmerLevel())
                    .toString()
            }
            else -> "Unknown tool: $name"
        }
    }

    private fun localFallback(text: String, bridge: HardwareBridge): String? {
        val t = text.lowercase().trim()
        val actions = mutableListOf<String>()

        if (Regex("""\ball\s+on\b|\bturn\s+on\s+all\b""").containsMatchIn(t)) {
            bridge.sendRawCommand("ALL_ON")
            actions += "all relays on"
        } else if (Regex("""\ball\s+off\b|\bturn\s+off\s+all\b""").containsMatchIn(t)) {
            bridge.sendRawCommand("ALL_OFF")
            actions += "all relays off"
        }

        Regex("""\brelay\s*([1-4])\s*(on|off)\b""").findAll(t).forEach { m ->
            val ch = m.groupValues[1].toInt()
            val state = m.groupValues[2].uppercase()
            bridge.sendRawCommand("POWER$ch $state")
            actions += "relay $ch ${state.lowercase()}"
        }

        Regex("""\bturn\s+(on|off)\s+relay\s*([1-4])\b""").findAll(t).forEach { m ->
            val state = m.groupValues[1].uppercase()
            val ch = m.groupValues[2].toInt()
            bridge.sendRawCommand("POWER$ch $state")
            actions += "relay $ch ${state.lowercase()}"
        }

        Regex("""\bdimmer(?:\s*(?:to|at|level|:))?\s*([0-9])\b""").find(t)?.let { dm ->
            val lvl = dm.groupValues[1].toInt().coerceIn(0, 9)
            bridge.setDimmerLevel(lvl)
            actions += "dimmer $lvl"
        }

        if (actions.isEmpty() && (t.contains("status") || t.contains("state"))) {
            bridge.sendRawCommand("STATUS")
            return "Relays ${bridge.getRelayStates().contentToString()}, dimmer ${bridge.getDimmerLevel()}."
        }

        return if (actions.isNotEmpty()) "Done: ${actions.joinToString(", ")}." else null
    }

    private fun buildToolsArray(): JSONArray {
        fun prop(type: String, enumVals: List<Int>? = null, min: Int? = null, max: Int? = null) =
            JSONObject().put("type", type).apply {
                if (enumVals != null) put("enum", JSONArray(enumVals))
                if (min != null) put("minimum", min)
                if (max != null) put("maximum", max)
            }

        fun tool(name: String, desc: String, props: JSONObject, required: List<String>) =
            JSONObject()
                .put("type", "function")
                .put(
                    "function",
                    JSONObject()
                        .put("name", name)
                        .put("description", desc)
                        .put(
                            "parameters",
                            JSONObject()
                                .put("type", "object")
                                .put("properties", props)
                                .put("required", JSONArray(required))
                        )
                )

        return JSONArray()
            .put(
                tool(
                    "set_relay",
                    "Turn relay channel 1..4 ON or OFF.",
                    JSONObject()
                        .put("channel", prop("integer", enumVals = listOf(1, 2, 3, 4)))
                        .put("turn_on", prop("boolean")),
                    listOf("channel", "turn_on")
                )
            )
            .put(
                tool(
                    "set_dimmer",
                    "Set dimmer or fan speed level from 0 (min/off) to 9 (max).",
                    JSONObject().put("level", prop("integer", min = 0, max = 9)),
                    listOf("level")
                )
            )
            .put(
                tool(
                    "set_all_relays",
                    "Turn all relays ON or OFF.",
                    JSONObject().put("turn_on", prop("boolean")),
                    listOf("turn_on")
                )
            )
            .put(
                tool(
                    "get_device_status",
                    "Query current relay and dimmer status from the ESP.",
                    JSONObject(),
                    emptyList()
                )
            )
    }

    private fun pcmToWav(pcm: ByteArray, sampleRate: Int, channels: Int, bitsPerSample: Int): ByteArray {
        val byteRate = sampleRate * channels * (bitsPerSample / 8)
        val blockAlign = channels * (bitsPerSample / 8)
        val dataSize = pcm.size
        val chunkSize = 36 + dataSize

        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN).apply {
            put("RIFF".toByteArray(Charsets.US_ASCII))
            putInt(chunkSize)
            put("WAVE".toByteArray(Charsets.US_ASCII))
            put("fmt ".toByteArray(Charsets.US_ASCII))
            putInt(16)
            putShort(1)
            putShort(channels.toShort())
            putInt(sampleRate)
            putInt(byteRate)
            putShort(blockAlign.toShort())
            putShort(bitsPerSample.toShort())
            put("data".toByteArray(Charsets.US_ASCII))
            putInt(dataSize)
        }

        return ByteArrayOutputStream(44 + dataSize).apply {
            write(header.array())
            write(pcm)
        }.toByteArray()
    }
}