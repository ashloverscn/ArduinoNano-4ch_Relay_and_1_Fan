package com.sasoftwares.homeautomationcontroller

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.content.res.ColorStateList
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.util.Log
import android.view.WindowManager
import android.widget.Button
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import androidx.core.content.edit
import androidx.core.graphics.toColorInt
import com.hivemq.client.mqtt.MqttClient
import com.hivemq.client.mqtt.mqtt5.Mqtt5AsyncClient
import com.sasoftwares.homeautomationcontroller.databinding.ActivityMainBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.lang.ref.WeakReference
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    private var mqttClient: Mqtt5AsyncClient? = null
    private var webSocket: WebSocket? = null
    private val okHttpClient = OkHttpClient()
    private val scope = CoroutineScope(Dispatchers.IO)
    private val handler = Handler(Looper.getMainLooper())

    private var connectivityManager: ConnectivityManager? = null
    private var networkCallback: ConnectivityManager.NetworkCallback? = null
    private var isNetworkAvailable = false

    private val relayStates = BooleanArray(4) { false }
    private var lastSentDimmer = 0
    private var isIpConnected = false
    private var isMqttConnected = false
    private var activeProfile: Int = 1 // 1..4

    private val recordAudioPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
            if (isGranted) {
                armWakeWordMode()
            } else {
                BackgroundVoiceService.disarmFromApp(this)
                updateVoiceButtonUI()
                logMessage(">> Microphone permission denied. Wake word unavailable.\n")
                Toast.makeText(this, "Microphone permission is required for voice commands", Toast.LENGTH_SHORT).show()
            }
        }

    companion object {
        private const val KEY_MANUAL_DISCONNECT = "manual_disconnect_flag"
        private const val VOICE_CHANNEL_ID = "home_automation_voice_channel"
        private const val VOICE_NOTIFICATION_ID = 1001
        private const val ACTION_START_VOICE_BG = "com.sasoftwares.homeautomationcontroller.action.START_VOICE_BG"
        private const val ACTION_STOP_VOICE_BG = "com.sasoftwares.homeautomationcontroller.action.STOP_VOICE_BG"
    }

    class BackgroundVoiceService : Service() {
        private val serviceScope = CoroutineScope(Dispatchers.IO)
        private val serviceHandler = Handler(Looper.getMainLooper())
        private val httpClient = OkHttpClient.Builder()
            .connectTimeout(6, TimeUnit.SECONDS)
            .readTimeout(6, TimeUnit.SECONDS)
            .writeTimeout(6, TimeUnit.SECONDS)
            .build()
        private val groqVoice = GroqVoiceController(httpClient)

        private var wakeLock: PowerManager.WakeLock? = null
        private var wifiLock: WifiManager.WifiLock? = null
        private var speechRecognizer: SpeechRecognizer? = null
        private var tts: TextToSpeech? = null
        private var isTtsReady = false

        private var wakeWordArmed = false
        private var awaitingCommandAfterWake = false
        private var isProcessingGroqCommand = false
        private var wakeListenGeneration = 0

        companion object {
            @Volatile
            private var instanceRef: WeakReference<BackgroundVoiceService>? = null

            @Volatile
            private var activityRef: WeakReference<MainActivity>? = null

            fun attachActivity(activity: MainActivity) {
                activityRef = WeakReference(activity)
                instanceRef?.get()?.notifyUiState()
            }

            fun detachActivity(activity: MainActivity) {
                if (activityRef?.get() === activity) {
                    activityRef = null
                }
            }

            fun isArmed(): Boolean = instanceRef?.get()?.wakeWordArmed == true

            fun isRecording(): Boolean = instanceRef?.get()?.groqVoice?.isRecording() == true

            fun isProcessing(): Boolean = instanceRef?.get()?.isProcessingGroqCommand == true

            fun isAwaitingCommand(): Boolean = instanceRef?.get()?.awaitingCommandAfterWake == true

            fun armFromApp(activity: MainActivity) {
                val intent = Intent(activity, BackgroundVoiceService::class.java).apply {
                    action = ACTION_START_VOICE_BG
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    activity.startForegroundService(intent)
                } else {
                    activity.startService(intent)
                }
                serviceHandlerPost {
                    instanceRef?.get()?.armInternal()
                }
            }

            fun disarmFromApp(context: Context) {
                val svc = instanceRef?.get()
                if (svc != null) {
                    svc.disarmInternal()
                } else {
                    val stopIntent = Intent(context, BackgroundVoiceService::class.java).apply {
                        action = ACTION_STOP_VOICE_BG
                    }
                    try {
                        context.startService(stopIntent)
                    } catch (_: Exception) {
                    }
                }
            }

            fun stopRecordingFromApp() {
                instanceRef?.get()?.groqVoice?.requestStopRecording()
            }

            private fun serviceHandlerPost(block: () -> Unit) {
                val svc = instanceRef?.get()
                if (svc != null) {
                    svc.serviceHandler.post(block)
                } else {
                    Handler(Looper.getMainLooper()).postDelayed(block, 250L)
                }
            }
        }

        override fun onCreate() {
            super.onCreate()
            instanceRef = WeakReference(this)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    VOICE_CHANNEL_ID,
                    getString(R.string.voice_notif_channel_name),
                    NotificationManager.IMPORTANCE_LOW
                )
                val manager = getSystemService(NotificationManager::class.java)
                manager.createNotificationChannel(channel)
            }

            val pm = getSystemService(Context.POWER_SERVICE) as? PowerManager
            wakeLock = pm?.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "HomeAutomationController::BackgroundWakeWordLock"
            )?.apply {
                setReferenceCounted(false)
            }

            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            @Suppress("DEPRECATION")
            val lockMode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                WifiManager.WIFI_MODE_FULL_LOW_LATENCY
            } else {
                WifiManager.WIFI_MODE_FULL_HIGH_PERF
            }
            wifiLock = wm?.createWifiLock(lockMode, "HomeAutomationController::BackgroundWifiLock")?.apply {
                setReferenceCounted(false)
            }

            tts = TextToSpeech(applicationContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    tts?.language = Locale.US
                    tts?.setSpeechRate(1.05f)
                    isTtsReady = true
                }
            }
        }

        override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
            if (intent?.action == ACTION_STOP_VOICE_BG) {
                disarmInternal()
                return START_NOT_STICKY
            }

            acquireLocksSafely()
            showForegroundNotification()
            if (wakeWordArmed && speechRecognizer == null && !isProcessingGroqCommand && !groqVoice.isRecording()) {
                scheduleWakeWordRestart(150L)
            }
            return START_STICKY
        }

        private fun showForegroundNotification() {
            val openAppIntent = Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            }
            val pendingIntent = PendingIntent.getActivity(
                this,
                0,
                openAppIntent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )

            val stopIntent = Intent(this, BackgroundVoiceService::class.java).apply {
                action = ACTION_STOP_VOICE_BG
            }
            val stopPendingIntent = PendingIntent.getService(
                this,
                1,
                stopIntent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )

            val notification: Notification = NotificationCompat.Builder(this, VOICE_CHANNEL_ID)
                .setContentTitle(getString(R.string.voice_notif_title))
                .setContentText(getString(R.string.voice_notif_text))
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentIntent(pendingIntent)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stopPendingIntent)
                .setOngoing(true)
                .build()

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(
                    VOICE_NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                )
            } else {
                startForeground(VOICE_NOTIFICATION_ID, notification)
            }
        }

        private fun acquireLocksSafely() {
            try {
                if (wakeLock?.isHeld != true) {
                    wakeLock?.acquire(6 * 60 * 60 * 1000L)
                }
            } catch (e: Exception) {
                Log.w("BG_VOICE", "Failed to acquire partial wake lock", e)
            }
            try {
                if (wifiLock?.isHeld != true) {
                    wifiLock?.acquire()
                }
            } catch (e: Exception) {
                Log.w("BG_VOICE", "Failed to acquire wifi lock", e)
            }
        }

        private fun releaseLocksSafely() {
            try {
                if (wakeLock?.isHeld == true) {
                    wakeLock?.release()
                }
            } catch (_: Exception) {
            }
            try {
                if (wifiLock?.isHeld == true) {
                    wifiLock?.release()
                }
            } catch (_: Exception) {
            }
        }

        private fun activeProfile(): Int {
            val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
            return prefs.getInt(ConfigActivity.KEY_ACTIVE_PROFILE, 1).coerceIn(1, 4)
        }

        private fun normalizePhrase(raw: String): String {
            return raw.lowercase()
                .replace(Regex("""[^a-z0-9\s]"""), " ")
                .replace(Regex("""\s+"""), " ")
                .trim()
        }

        private fun getActiveWakeWords(): List<String> {
            val profile = activeProfile()
            val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
            val customRaw = prefs.getString(
                ConfigActivity.key(ConfigActivity.KEY_WAKE_WORD, profile),
                ConfigActivity.DEFAULT_WAKE_WORD
            ).orEmpty()

            val phrases = customRaw.split(",")
                .map { normalizePhrase(it) }
                .filter { it.isNotEmpty() }
                .distinct()

            return phrases.ifEmpty { listOf(normalizePhrase(ConfigActivity.DEFAULT_WAKE_WORD)) }
        }

        private fun getPrimaryWakeWordDisplay(): String {
            val profile = activeProfile()
            val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
            val raw = prefs.getString(
                ConfigActivity.key(ConfigActivity.KEY_WAKE_WORD, profile),
                ConfigActivity.DEFAULT_WAKE_WORD
            ).orEmpty()
            return raw.split(",").map { it.trim() }.firstOrNull { it.isNotEmpty() }
                ?: ConfigActivity.DEFAULT_WAKE_WORD
        }

        fun armInternal() {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                logToUi(">> Microphone permission missing in service.\n")
                return
            }
            acquireLocksSafely()
            showForegroundNotification()
            wakeWordArmed = true
            awaitingCommandAfterWake = false
            notifyUiState()
            logToUi(">> Wake word armed in background service. Say \"${getPrimaryWakeWordDisplay()}\" anytime.\n")
            scheduleWakeWordRestart(100L)
        }

        fun disarmInternal() {
            wakeWordArmed = false
            awaitingCommandAfterWake = false
            isProcessingGroqCommand = false
            wakeListenGeneration++
            serviceHandler.removeCallbacksAndMessages(null)
            destroySpeechRecognizerSafely()
            if (groqVoice.isRecording()) {
                groqVoice.requestStopRecording()
            }
            releaseLocksSafely()
            notifyUiState()
            logToUi(">> Wake word mode disarmed.\n")
            try {
                stopForeground(STOP_FOREGROUND_REMOVE)
            } catch (_: Exception) {
            }
            stopSelf()
        }

        private fun destroySpeechRecognizerSafely() {
            val current = speechRecognizer
            speechRecognizer = null
            if (current != null) {
                try {
                    current.cancel()
                } catch (_: Exception) {
                }
                try {
                    current.destroy()
                } catch (_: Exception) {
                }
            }
        }

        private fun scheduleWakeWordRestart(delayMs: Long) {
            wakeListenGeneration++
            val expectedGen = wakeListenGeneration
            serviceHandler.removeCallbacksAndMessages(null)
            serviceHandler.postDelayed({
                if (expectedGen == wakeListenGeneration &&
                    wakeWordArmed &&
                    !isProcessingGroqCommand &&
                    !groqVoice.isRecording()
                ) {
                    startWakeWordListenCycle(expectedGen)
                }
            }, delayMs)
        }

        private fun createFreshSpeechRecognizer(expectedGen: Int): SpeechRecognizer? {
            destroySpeechRecognizerSafely()
            if (!SpeechRecognizer.isRecognitionAvailable(this)) {
                logToUi(">> Speech recognition is not available on this device.\n")
                return null
            }

            val recognizer = try {
                SpeechRecognizer.createSpeechRecognizer(this)
            } catch (e: Exception) {
                Log.e("WAKE_WORD", "Failed to create SpeechRecognizer in service", e)
                return null
            }

            recognizer.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    if (expectedGen == wakeListenGeneration) notifyUiState()
                }

                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}

                override fun onError(error: Int) {
                    if (expectedGen != wakeListenGeneration) return
                    awaitingCommandAfterWake = false
                    notifyUiState()
                    destroySpeechRecognizerSafely()

                    if (!wakeWordArmed || isProcessingGroqCommand) return

                    val pm = getSystemService(Context.POWER_SERVICE) as? PowerManager
                    val isScreenOn = pm?.isInteractive ?: true
                    val baseBackoff = when (error) {
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY,
                        SpeechRecognizer.ERROR_CLIENT,
                        SpeechRecognizer.ERROR_SERVER,
                        SpeechRecognizer.ERROR_NETWORK -> 1400L
                        SpeechRecognizer.ERROR_NO_MATCH,
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> 700L
                        else -> 900L
                    }
                    val backoffMs = if (isScreenOn) baseBackoff else maxOf(baseBackoff, 2500L)
                    scheduleWakeWordRestart(backoffMs)
                }

                override fun onResults(results: Bundle?) {
                    if (expectedGen != wakeListenGeneration) return
                    val spokenText = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                        .orEmpty()
                        .trim()

                    destroySpeechRecognizerSafely()

                    if (!wakeWordArmed || isProcessingGroqCommand) {
                        awaitingCommandAfterWake = false
                        notifyUiState()
                        return
                    }

                    val triggeredWake = spokenText.isNotEmpty() && handleWakeWordUtterance(spokenText)
                    if (!triggeredWake && spokenText.isNotEmpty()) {
                        logToUi(">> [Wake Heard] \"$spokenText\" (expected: ${getActiveWakeWords().joinToString()})\n")
                    }
                    notifyUiState()

                    if (!triggeredWake) {
                        scheduleWakeWordRestart(500L)
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    if (expectedGen != wakeListenGeneration) return
                    if (!wakeWordArmed || isProcessingGroqCommand) return
                    val partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                        .orEmpty()
                        .trim()
                    if (partial.isNotEmpty() && containsWakeWord(partial)) {
                        wakeListenGeneration++
                        destroySpeechRecognizerSafely()
                        handleWakeWordUtterance(partial)
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })

            speechRecognizer = recognizer
            return recognizer
        }

        private fun startWakeWordListenCycle(expectedGen: Int) {
            if (expectedGen != wakeListenGeneration) return
            if (!wakeWordArmed || isProcessingGroqCommand || groqVoice.isRecording()) return

            val recognizer = createFreshSpeechRecognizer(expectedGen) ?: run {
                scheduleWakeWordRestart(1500L)
                return
            }

            awaitingCommandAfterWake = false
            notifyUiState()

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L)
            }

            try {
                recognizer.startListening(intent)
            } catch (e: Exception) {
                Log.e("WAKE_WORD", "startListening failed in service", e)
                destroySpeechRecognizerSafely()
                scheduleWakeWordRestart(1200L)
            }
        }

        private fun containsWakeWord(text: String): Boolean {
            val normalizedSpoken = " ${normalizePhrase(text)} "
            if (normalizedSpoken.isBlank()) return false
            return getActiveWakeWords().any { phrase ->
                val cleanPhrase = phrase.trim()
                cleanPhrase.isNotEmpty() && normalizedSpoken.contains(" $cleanPhrase ")
            }
        }

        @Synchronized
        private fun handleWakeWordUtterance(spokenText: String): Boolean {
            if (isProcessingGroqCommand || groqVoice.isRecording()) return false
            val normalizedSpoken = " ${normalizePhrase(spokenText)} "
            val matchedWake = getActiveWakeWords().firstOrNull { phrase ->
                val cleanPhrase = phrase.trim()
                cleanPhrase.isNotEmpty() && normalizedSpoken.contains(" $cleanPhrase ")
            } ?: return false

            wakeListenGeneration++
            serviceHandler.removeCallbacksAndMessages(null)
            destroySpeechRecognizerSafely()
            playWakeDetectedDing()
            awaitingCommandAfterWake = true
            notifyUiState()
            logToUi(">> Wake word detected (\"$matchedWake\") from \"$spokenText\". Capturing audio for Groq…\n")
            startGroqVoiceRecording(resumeWakeWordAfter = wakeWordArmed)
            return true
        }

        private fun playWakeDetectedDing() {
            try {
                val toneGen = ToneGenerator(AudioManager.STREAM_MUSIC, 90)
                toneGen.startTone(ToneGenerator.TONE_PROP_ACK, 180)
                serviceHandler.postDelayed({
                    try {
                        toneGen.release()
                    } catch (_: Exception) {
                    }
                }, 250L)
            } catch (e: Exception) {
                Log.w("WAKE_DING", "Unable to play wake confirmation tone", e)
            }
        }

        private fun speakShortReply(text: String) {
            val profile = activeProfile()
            val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
            val enabled = prefs.getBoolean(ConfigActivity.key(ConfigActivity.KEY_TTS_ENABLED, profile), true)
            if (!enabled || !isTtsReady) return

            val cleaned = text.replace(Regex("""[*#]"""), "").replace(Regex("""\s+"""), " ").trim()
            if (cleaned.isEmpty()) return
            val clipped = if (cleaned.length > 140) {
                cleaned.take(140).substringBeforeLast(" ").ifEmpty { cleaned.take(140) } + "."
            } else {
                cleaned
            }
            tts?.speak(clipped, TextToSpeech.QUEUE_FLUSH, null, "groq_reply_${System.currentTimeMillis()}")
        }

        private fun sendHardwareCommandFromService(cmd: String, profile: Int) {
            val act = activityRef?.get()
            if (act != null && act.isIpConnected) {
                act.sendCommandFromExternal(cmd)
                return
            }

            serviceScope.launch {
                val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
                val ip = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_IP, profile), "")?.trim().orEmpty()
                val wsUser = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_USER, profile), "admin")?.trim() ?: "admin"
                val wsPass = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_PASS, profile), "admin1234S")?.trim() ?: "admin1234S"

                if (ip.isNotEmpty() && sendOverWebSocketOnce(ip, wsUser, wsPass, cmd, profile)) {
                    return@launch
                }

                sendOverMqttOnce(prefs, cmd, profile)
            }
        }

        private fun sendOverWebSocketOnce(ip: String, user: String, pass: String, cmd: String, profile: Int): Boolean {
            val latch = CountDownLatch(1)
            var sentOk = false
            var socket: WebSocket? = null

            val request = Request.Builder().url("ws://$ip:81/").build()
            socket = httpClient.newWebSocket(request, object : WebSocketListener() {
                override fun onOpen(webSocket: WebSocket, response: Response) {
                    try {
                        val authPayload = JSONObject().apply {
                            put("auth", JSONObject().put("user", user).put("pass", pass))
                        }.toString()
                        webSocket.send(authPayload)
                        val cmdPayload = JSONObject().put("command", cmd).toString()
                        sentOk = webSocket.send(cmdPayload)
                    } catch (e: Exception) {
                        Log.w("BG_WS", "WS send error", e)
                    } finally {
                        serviceHandler.postDelayed({
                            try {
                                webSocket.close(1000, "Done")
                            } catch (_: Exception) {
                            }
                            latch.countDown()
                        }, 300L)
                    }
                }

                override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                    Log.w("BG_WS", "WS failed on lock/bg: ${t.localizedMessage}")
                    latch.countDown()
                }
            })

            latch.await(4, TimeUnit.SECONDS)
            try {
                socket.cancel()
            } catch (_: Exception) {
            }

            if (sentOk) {
                logToUi(">> [D$profile] $cmd (Lock/BG WebSocket)\n")
            }
            return sentOk
        }

        private fun sendOverMqttOnce(prefs: android.content.SharedPreferences, cmd: String, profile: Int) {
            val mqttEnabled = prefs.getBoolean(ConfigActivity.key(ConfigActivity.KEY_MQTT_ENABLED, profile), true)
            if (!mqttEnabled) {
                logToUi(">> [D$profile] $cmd (Failed - MQTT disabled & local IP unreachable)\n")
                return
            }
            val server = prefs.getString(
                ConfigActivity.key(ConfigActivity.KEY_MQTT_SERVER, profile),
                "i11b0026.ala.eu-central-1.emqxsl.com"
            ) ?: "i11b0026.ala.eu-central-1.emqxsl.com"
            val port = prefs.getInt(ConfigActivity.key(ConfigActivity.KEY_MQTT_PORT, profile), 8883)
            val user = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_MQTT_USER, profile), "admin") ?: "admin"
            val pass = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_MQTT_PASS, profile), "admin1234S") ?: "admin1234S"
            val tCmd = prefs.getString(
                ConfigActivity.key(ConfigActivity.KEY_MQTT_TOPIC_CMD, profile),
                "home/room$profile/command"
            ) ?: "home/room$profile/command"

            var client: Mqtt5AsyncClient? = null
            try {
                client = MqttClient.builder()
                    .useMqttVersion5()
                    .serverHost(server)
                    .serverPort(port)
                    .sslWithDefaultConfig()
                    .buildAsync()
                client.connectWith()
                    .simpleAuth()
                    .username(user)
                    .password(pass.toByteArray())
                    .applySimpleAuth()
                    .send()
                    .get(8, TimeUnit.SECONDS)
                val payload = JSONObject().put("command", cmd).toString()
                client.publishWith()
                    .topic(tCmd)
                    .payload(payload.toByteArray())
                    .send()
                    .get(6, TimeUnit.SECONDS)
                logToUi(">> [D$profile] $cmd (Lock/BG MQTT)\n")
            } catch (e: Exception) {
                Log.e("BG_MQTT", "Failed lock/bg command $cmd", e)
                logToUi(">> [D$profile] $cmd (Lock/BG MQTT Error: ${e.localizedMessage})\n")
            } finally {
                try {
                    client?.disconnect()?.get(2, TimeUnit.SECONDS)
                } catch (_: Exception) {
                }
            }
        }

        private fun startGroqVoiceRecording(resumeWakeWordAfter: Boolean) {
            if (groqVoice.isRecording() || isProcessingGroqCommand) return

            val profile = activeProfile()
            val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
            val apiKey = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_GROQ_API_KEY, profile), "").orEmpty()
            val modelName = prefs.getString(
                ConfigActivity.key(ConfigActivity.KEY_GROQ_MODEL, profile),
                ConfigActivity.DEFAULT_GROQ_MODEL
            ).orEmpty()

            logToUi(">> [Groq Mic] Recording (up to ${GroqVoiceController.MAX_RECORD_SECONDS}s)…\n")

            serviceScope.launch {
                notifyUiState()
                val wavBytes = groqVoice.recordWav(GroqVoiceController.MAX_RECORD_SECONDS) { msg ->
                    logToUi(msg)
                }

                awaitingCommandAfterWake = false
                isProcessingGroqCommand = true
                notifyUiState()

                try {
                    if (wavBytes == null || wavBytes.isEmpty()) {
                        logToUi(">> [Groq Mic] No audio captured.\n")
                        return@launch
                    }

                    val transcript = groqVoice.transcribeWav(wavBytes, apiKey)
                    logToUi(">> [Groq Whisper] ${transcript.ifEmpty { "(empty)" }}\n")
                    if (transcript.isBlank()) {
                        speakShortReply("Could not hear clear speech.")
                        return@launch
                    }

                    val bridge = object : GroqVoiceController.HardwareBridge {
                        override fun sendRawCommand(cmd: String) {
                            sendHardwareCommandFromService(cmd, activeProfile())
                        }

                        override fun setDimmerLevel(level: Int) {
                            val clamped = level.coerceIn(0, 9)
                            activityRef?.get()?.setDimmerFromExternal(clamped)
                            sendHardwareCommandFromService("DIMMER:$clamped", activeProfile())
                        }

                        override fun switchProfile(profileNum: Int) {
                            val bounded = profileNum.coerceIn(1, 4)
                            getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
                                .edit { putInt(ConfigActivity.KEY_ACTIVE_PROFILE, bounded) }
                            activityRef?.get()?.switchProfileFromExternal(bounded)
                        }

                        override fun getRelayStates(): BooleanArray =
                            activityRef?.get()?.relayStatesCopy() ?: BooleanArray(4)

                        override fun getDimmerLevel(): Int =
                            activityRef?.get()?.currentDimmerLevel() ?: 0

                        override fun onLog(msg: String) {
                            logToUi(msg)
                        }
                    }

                    val reply = groqVoice.runIntent(transcript, apiKey, modelName, bridge)
                    logToUi(">> [Groq] $reply\n")
                    speakShortReply(reply)
                } catch (e: Exception) {
                    Log.e("GROQ_VOICE", "Voice pipeline error", e)
                    logToUi(">> [Groq Error] ${e.localizedMessage ?: e.message}\n")
                    speakShortReply("Voice command failed.")
                } finally {
                    isProcessingGroqCommand = false
                    notifyUiState()
                    if (resumeWakeWordAfter && wakeWordArmed) {
                        scheduleWakeWordRestart(600L)
                    } else if (!wakeWordArmed) {
                        disarmInternal()
                    }
                }
            }
        }

        private fun logToUi(msg: String) {
            activityRef?.get()?.logMessage(msg)
        }

        private fun notifyUiState() {
            activityRef?.get()?.runOnUiThread {
                activityRef?.get()?.updateVoiceButtonUI()
            }
        }

        override fun onDestroy() {
            wakeWordArmed = false
            awaitingCommandAfterWake = false
            isProcessingGroqCommand = false
            wakeListenGeneration++
            serviceHandler.removeCallbacksAndMessages(null)
            destroySpeechRecognizerSafely()
            releaseLocksSafely()
            if (groqVoice.isRecording()) {
                groqVoice.requestStopRecording()
            }
            tts?.stop()
            tts?.shutdown()
            tts = null
            if (instanceRef?.get() === this) {
                instanceRef = null
            }
            super.onDestroy()
        }

        override fun onBind(intent: Intent?): IBinder? = null
    }

    private fun relayStatesCopy(): BooleanArray = relayStates.copyOf()
    private fun currentDimmerLevel(): Int = binding.dimmerSeekBar.progress

    private fun sendCommandFromExternal(cmd: String) {
        sendCommand(cmd)
    }

    private fun setDimmerFromExternal(clamped: Int) {
        runOnUiThread {
            binding.dimmerSeekBar.progress = clamped
            updateDimmerText(clamped)
        }
        lastSentDimmer = -1
        sendDimmerCommand(clamped)
    }

    private fun switchProfileFromExternal(profileNum: Int) {
        runOnUiThread { switchToProfile(profileNum, forceConnect = true) }
    }

    private fun keepScreenAwake() {
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        keepScreenAwake()
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
        }

        registerNetworkMonitor()

        activeProfile = getSavedActiveProfile()
        setupControls()
        updateActiveProfileUI()
        resetToDefaultState()
        updateVoiceButtonUI()

        autoConnectWebSocket()
    }

    private fun registerNetworkMonitor() {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return
        connectivityManager = cm
        isNetworkAvailable = checkCurrentNetworkState(cm)

        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                runOnUiThread {
                    val wasOffline = !isNetworkAvailable
                    isNetworkAvailable = checkCurrentNetworkState(cm)
                    if (wasOffline) {
                        logMessage(">> Internet/network restored [Device: $activeProfile]. Reviving connections…\n")
                    }
                    reviveConnectionsIfNeeded()
                }
            }

            override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) {
                val hasInternet = networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                        networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
                runOnUiThread {
                    val wasOffline = !isNetworkAvailable
                    isNetworkAvailable = hasInternet || checkCurrentNetworkState(cm)
                    if (wasOffline && isNetworkAvailable) {
                        logMessage(">> Network validated [Device: $activeProfile]. Reviving connections…\n")
                        reviveConnectionsIfNeeded()
                    }
                }
            }

            override fun onLost(network: Network) {
                runOnUiThread {
                    isNetworkAvailable = checkCurrentNetworkState(cm)
                    if (!isNetworkAvailable) {
                        logMessage(">> Network/internet dropped! Cleaning up active sockets…\n")
                        handleNetworkLost()
                    }
                }
            }
        }

        networkCallback = callback
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                cm.registerDefaultNetworkCallback(callback)
            } else {
                val req = NetworkRequest.Builder()
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .build()
                cm.registerNetworkCallback(req, callback)
            }
        } catch (e: Exception) {
            Log.e("NET_MON", "Failed to register network callback", e)
        }
    }

    private fun checkCurrentNetworkState(cm: ConnectivityManager): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val activeNet = cm.activeNetwork ?: return false
                val caps = cm.getNetworkCapabilities(activeNet) ?: return false
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            } else {
                @Suppress("DEPRECATION")
                cm.activeNetworkInfo?.isConnected == true
            }
        } catch (_: Exception) {
            false
        }
    }

    private fun handleNetworkLost() {
        webSocket?.cancel()
        webSocket = null
        isIpConnected = false

        if (isMqttConnected || mqttClient != null) {
            disconnectMqttClient()
        }

        updateConnectionStatusUI()
        resetToDefaultState()
    }

    private fun reviveConnectionsIfNeeded() {
        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        val isManualDisconnect = prefs.getBoolean(ConfigActivity.key(KEY_MANUAL_DISCONNECT, activeProfile), false)

        if (!isIpConnected && !isMqttConnected && !isManualDisconnect) {
            autoConnectWebSocket()
        } else {
            checkAndHandleMqttState()
        }
    }

    override fun onStart() {
        super.onStart()
        keepScreenAwake()
        BackgroundVoiceService.attachActivity(this)
        updateVoiceButtonUI()
    }

    override fun onStop() {
        super.onStop()
        BackgroundVoiceService.detachActivity(this)
    }

    override fun onResume() {
        super.onResume()
        keepScreenAwake()
        BackgroundVoiceService.attachActivity(this)
        val cm = connectivityManager
        if (cm != null) {
            isNetworkAvailable = checkCurrentNetworkState(cm)
        }

        val latestProfile = getSavedActiveProfile()
        if (latestProfile != activeProfile) {
            switchToProfile(latestProfile, forceConnect = false)
            return
        }

        updateActiveProfileUI()
        updateConnectionStatusUI()
        updateVoiceButtonUI()

        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        val isManualDisconnect = prefs.getBoolean(ConfigActivity.key(KEY_MANUAL_DISCONNECT, activeProfile), false)

        if (!isIpConnected && !isMqttConnected && !isManualDisconnect) {
            logMessage(">> App resumed [Device: $activeProfile]. Reviving connection…\n")
            autoConnectWebSocket()
        } else {
            checkAndHandleMqttState()
        }
    }

    private fun getSavedActiveProfile(): Int {
        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getInt(ConfigActivity.KEY_ACTIVE_PROFILE, 1).coerceIn(1, 4)
    }

    private fun setSavedActiveProfile(profile: Int) {
        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit { putInt(ConfigActivity.KEY_ACTIVE_PROFILE, profile.coerceIn(1, 4)) }
    }

    private fun switchToProfile(profile: Int, forceConnect: Boolean) {
        activeProfile = profile.coerceIn(1, 4)
        setSavedActiveProfile(activeProfile)
        if (forceConnect) {
            setManualDisconnectFlag(false)
        }

        updateActiveProfileUI()
        resetToDefaultState()
        logMessage(">> Switched to Device: $activeProfile.\n")

        webSocket?.cancel()
        webSocket = null
        isIpConnected = false

        if (isMqttConnected || mqttClient != null) {
            disconnectMqttClient()
        }

        updateConnectionStatusUI()
        autoConnectWebSocket()
    }

    private fun updateActiveProfileUI() {
        binding.tvActiveConfig.text = getString(R.string.active_config_format, activeProfile)
        val buttons = listOf(
            binding.btnSelectConfig1,
            binding.btnSelectConfig2,
            binding.btnSelectConfig3,
            binding.btnSelectConfig4
        )
        buttons.forEachIndexed { index, button ->
            val profileNum = index + 1
            val isSelected = profileNum == activeProfile
            val colorHex = if (isSelected) "#2E7D32" else "#6200EE"
            button.backgroundTintList = ColorStateList.valueOf(colorHex.toColorInt())
            button.setTextColor("#FFFFFF".toColorInt())
        }
    }

    private fun updateVoiceButtonUI() {
        when {
            BackgroundVoiceService.isRecording() -> {
                binding.btnVoiceCommand.text = "Recording Groq Command… Tap to Send"
                binding.btnVoiceCommand.backgroundTintList = ColorStateList.valueOf("#2E7D32".toColorInt())
                binding.btnVoiceCommand.isEnabled = true
            }
            BackgroundVoiceService.isProcessing() -> {
                binding.btnVoiceCommand.text = "Groq Thinking…"
                binding.btnVoiceCommand.backgroundTintList = ColorStateList.valueOf("#1565C0".toColorInt())
                binding.btnVoiceCommand.isEnabled = false
            }
            BackgroundVoiceService.isAwaitingCommand() -> {
                binding.btnVoiceCommand.text = getString(R.string.btn_voice_listening)
                binding.btnVoiceCommand.backgroundTintList = ColorStateList.valueOf("#2E7D32".toColorInt())
                binding.btnVoiceCommand.isEnabled = true
            }
            BackgroundVoiceService.isArmed() -> {
                binding.btnVoiceCommand.text = getString(R.string.btn_voice_wake_armed)
                binding.btnVoiceCommand.backgroundTintList = ColorStateList.valueOf("#1565C0".toColorInt())
                binding.btnVoiceCommand.isEnabled = true
            }
            else -> {
                binding.btnVoiceCommand.text = getString(R.string.btn_voice_command)
                binding.btnVoiceCommand.backgroundTintList = ColorStateList.valueOf("#00796B".toColorInt())
                binding.btnVoiceCommand.isEnabled = true
            }
        }
        binding.btnVoiceCommand.setTextColor("#FFFFFF".toColorInt())
    }

    private fun setupControls() {
        val profileButtons = listOf(
            binding.btnSelectConfig1,
            binding.btnSelectConfig2,
            binding.btnSelectConfig3,
            binding.btnSelectConfig4
        )
        profileButtons.forEachIndexed { index, button ->
            val targetProfile = index + 1
            button.setOnClickListener {
                if (targetProfile == activeProfile && (isIpConnected || isMqttConnected)) {
                    return@setOnClickListener
                }
                switchToProfile(targetProfile, forceConnect = true)
            }
        }

        val relayButtons = listOf(binding.btnRelay1, binding.btnRelay2, binding.btnRelay3, binding.btnRelay4)

        relayButtons.forEachIndexed { index, button ->
            button.setOnClickListener {
                if (!isIpConnected && !isMqttConnected) {
                    logMessage(">> Action blocked: Not connected to ESP device.\n")
                    return@setOnClickListener
                }
                val targetState = !relayStates[index]
                val stateStr = if (targetState) "ON" else "OFF"
                sendCommand("POWER${index + 1} $stateStr")
            }
        }

        binding.dimmerSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    updateDimmerText(progress)
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                if (!isIpConnected && !isMqttConnected) {
                    logMessage(">> Action blocked: Not connected to ESP device.\n")
                    return
                }
                seekBar?.let {
                    updateDimmerText(it.progress)
                    sendDimmerCommand(it.progress)
                }
            }
        })

        setupButtonTapEffect(binding.btnDimmerMin) { sendDimmerCommand(0) }
        setupButtonTapEffect(binding.btnDimmerMax) { sendDimmerCommand(9) }
        setupButtonTapEffect(binding.btnDimmerMinus) {
            val newProg = maxOf(0, binding.dimmerSeekBar.progress - 1)
            sendDimmerCommand(newProg)
        }
        setupButtonTapEffect(binding.btnDimmerPlus) {
            val newProg = minOf(9, binding.dimmerSeekBar.progress + 1)
            sendDimmerCommand(newProg)
        }

        setupButtonTapEffect(binding.btnAllOn) { sendCommand("ALL_ON") }
        setupButtonTapEffect(binding.btnAllOff) { sendCommand("ALL_OFF") }
        setupButtonTapEffect(binding.btnGetStatus) { sendCommand("STATUS") }

        binding.btnConfig.backgroundTintList = ColorStateList.valueOf("#6200EE".toColorInt())
        binding.btnConfig.setTextColor("#FFFFFF".toColorInt())
        binding.btnConfig.setOnClickListener {
            startActivity(Intent(this, ConfigActivity::class.java))
        }

        binding.btnConnectIp.setOnClickListener {
            if (!isIpConnected) {
                clearManualDisconnectFlag()
                connectWebSocket()
            } else {
                setManualDisconnectFlag(true)
                disconnectWebSocket()
            }
        }

        binding.btnVoiceCommand.setOnClickListener {
            if (BackgroundVoiceService.isRecording()) {
                BackgroundVoiceService.stopRecordingFromApp()
                return@setOnClickListener
            }
            if (BackgroundVoiceService.isProcessing()) return@setOnClickListener

            if (BackgroundVoiceService.isArmed()) {
                disarmWakeWordMode()
                return@setOnClickListener
            }

            val hasPermission = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            if (hasPermission) {
                armWakeWordMode()
            } else {
                recordAudioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
        }
    }

    private fun armWakeWordMode() {
        keepScreenAwake()
        BackgroundVoiceService.armFromApp(this)
        handler.postDelayed({ updateVoiceButtonUI() }, 150L)
    }

    private fun disarmWakeWordMode() {
        BackgroundVoiceService.disarmFromApp(this)
        updateVoiceButtonUI()
    }

    private fun resetToDefaultState() {
        val relayButtons = listOf(binding.btnRelay1, binding.btnRelay2, binding.btnRelay3, binding.btnRelay4)
        relayButtons.forEachIndexed { index, button ->
            relayStates[index] = false
            button.text = getString(R.string.relay_off_label, index + 1)
            button.backgroundTintList = ColorStateList.valueOf("#6200EE".toColorInt())
            button.setTextColor("#FFFFFF".toColorInt())
        }
        lastSentDimmer = 0
        binding.dimmerSeekBar.progress = 0
        updateDimmerText(0)
    }

    private fun setupButtonTapEffect(button: Button, action: () -> Unit) {
        button.backgroundTintList = ColorStateList.valueOf("#6200EE".toColorInt())
        button.setTextColor("#FFFFFF".toColorInt())
        button.setOnClickListener {
            if (!isIpConnected && !isMqttConnected) {
                logMessage(">> Action blocked: Not connected to ESP device.\n")
                return@setOnClickListener
            }
            button.backgroundTintList = ColorStateList.valueOf("#4CAF50".toColorInt())
            action()
            handler.postDelayed({
                button.backgroundTintList = ColorStateList.valueOf("#6200EE".toColorInt())
            }, 250)
        }
    }

    private fun setManualDisconnectFlag(disconnected: Boolean) {
        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit { putBoolean(ConfigActivity.key(KEY_MANUAL_DISCONNECT, activeProfile), disconnected) }
    }

    private fun clearManualDisconnectFlag() {
        setManualDisconnectFlag(false)
    }

    private fun updateDimmerText(progress: Int) {
        binding.tvDimmerValue.text = getString(R.string.dimmer_level_text, progress)
    }

    private fun sendDimmerCommand(valInt: Int) {
        if (valInt != lastSentDimmer) {
            lastSentDimmer = valInt
            sendCommand("DIMMER:$valInt")
        }
    }

    private fun autoConnectWebSocket() {
        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        val ip = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_IP, activeProfile), "")?.trim()
        val isManualDisconnect = prefs.getBoolean(ConfigActivity.key(KEY_MANUAL_DISCONNECT, activeProfile), false)

        if (!ip.isNullOrEmpty() && !isManualDisconnect) {
            connectWebSocket()
        } else {
            logMessage(">> Auto-connect IP skipped [Device: $activeProfile]. Falling back to MQTT check…\n")
            checkAndHandleMqttState()
        }
    }

    private fun connectWebSocket() {
        webSocket?.cancel()
        webSocket = null

        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        val ip = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_IP, activeProfile), "192.168.29.110")?.trim()
        val user = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_USER, activeProfile), "admin")?.trim()
        val pass = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_PASS, activeProfile), "admin1234S")?.trim()

        if (ip.isNullOrEmpty()) {
            logMessage(">> Error: No IP configured in Device: $activeProfile.\n")
            checkAndHandleMqttState()
            return
        }

        if (isMqttConnected || mqttClient != null) {
            logMessage(">> IP connection starting. Disconnecting active MQTT client…\n")
            disconnectMqttClient()
        }

        val request = Request.Builder().url("ws://$ip:81/").build()
        logMessage(">> [Device: $activeProfile] Connecting to WebSocket ws://$ip:81/…\n")

        webSocket = okHttpClient.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                isIpConnected = true
                runOnUiThread {
                    updateConnectionStatusUI()
                    logMessage(">> Connected to ESP WebSocket. Authenticating…\n")
                }

                val authPayload = JSONObject().apply {
                    put("auth", JSONObject().put("user", user).put("pass", pass))
                }.toString()
                webSocket.send(authPayload)

                sendCommand("STATUS")
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                logMessage("<< $text\n")
                parseArduinoFeedback(text)
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                isIpConnected = false
                runOnUiThread {
                    updateConnectionStatusUI()
                    resetToDefaultState()
                    logMessage(">> WebSocket Error: ${t.localizedMessage}\n")
                    checkAndHandleMqttState()
                }
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                isIpConnected = false
                runOnUiThread {
                    updateConnectionStatusUI()
                    resetToDefaultState()
                    logMessage(">> IP WebSocket Disconnected.\n")
                    checkAndHandleMqttState()
                }
            }
        })
    }

    private fun disconnectWebSocket() {
        webSocket?.close(1000, "User disconnected")
        webSocket = null
        isIpConnected = false
        updateConnectionStatusUI()
        resetToDefaultState()
        logMessage(">> IP WebSocket Disconnected manually.\n")

        checkAndHandleMqttState()
    }

    private fun checkAndHandleMqttState() {
        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        val isMqttEnabled = prefs.getBoolean(ConfigActivity.key(ConfigActivity.KEY_MQTT_ENABLED, activeProfile), true)

        if (isMqttEnabled) {
            if (!isIpConnected && !isMqttConnected && (mqttClient == null || mqttClient?.state?.isConnected != true)) {
                initMqttClient()
            }
        } else {
            if (isMqttConnected || mqttClient != null) {
                disconnectMqttClient()
                logMessage(">> MQTT disabled in Device: $activeProfile. Disconnecting client.\n")
            }
        }
    }

    private fun initMqttClient() {
        val targetProfile = activeProfile
        scope.launch {
            val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
            val isMqttEnabled = prefs.getBoolean(ConfigActivity.key(ConfigActivity.KEY_MQTT_ENABLED, targetProfile), true)

            if (!isMqttEnabled || isIpConnected || targetProfile != activeProfile) {
                logMessage(">> MQTT connection skipped (Disabled, IP connected, or device changed).\n")
                return@launch
            }

            try {
                val server = prefs.getString(
                    ConfigActivity.key(ConfigActivity.KEY_MQTT_SERVER, targetProfile),
                    "i11b0026.ala.eu-central-1.emqxsl.com"
                ) ?: "i11b0026.ala.eu-central-1.emqxsl.com"
                val port = prefs.getInt(ConfigActivity.key(ConfigActivity.KEY_MQTT_PORT, targetProfile), 8883)
                val user = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_MQTT_USER, targetProfile), "admin") ?: "admin"
                val pass = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_MQTT_PASS, targetProfile), "admin1234S") ?: "admin1234S"

                logMessage(">> [Device: $targetProfile] Connecting to MQTT Broker…\n")

                mqttClient = MqttClient.builder()
                    .useMqttVersion5()
                    .serverHost(server)
                    .serverPort(port)
                    .sslWithDefaultConfig()
                    .buildAsync()

                mqttClient?.connectWith()
                    ?.simpleAuth()
                    ?.username(user)
                    ?.password(pass.toByteArray())
                    ?.applySimpleAuth()
                    ?.send()
                    ?.whenComplete { _, throwable ->
                        runOnUiThread {
                            val stillEnabled = prefs.getBoolean(
                                ConfigActivity.key(ConfigActivity.KEY_MQTT_ENABLED, targetProfile),
                                true
                            )
                            if (!stillEnabled || isIpConnected || targetProfile != activeProfile) {
                                disconnectMqttClient()
                                return@runOnUiThread
                            }

                            if (throwable == null) {
                                isMqttConnected = true
                                updateConnectionStatusUI()
                                logMessage(">> [Device: $targetProfile] Connected to MQTT Broker successfully!\n")
                                subscribeMqttTopics(targetProfile)
                                sendCommand("STATUS")
                            } else {
                                isMqttConnected = false
                                updateConnectionStatusUI()
                                resetToDefaultState()
                                logMessage(">> MQTT Connection failed: ${throwable.localizedMessage}\n")
                            }
                        }
                    }
            } catch (e: Exception) {
                Log.e("MQTT", "Connection Error", e)
                isMqttConnected = false
                runOnUiThread {
                    updateConnectionStatusUI()
                    resetToDefaultState()
                }
            }
        }
    }

    private fun disconnectMqttClient() {
        scope.launch {
            try {
                mqttClient?.disconnect()?.get()
            } catch (e: Exception) {
                Log.e("MQTT", "Disconnect error", e)
            } finally {
                mqttClient = null
                isMqttConnected = false
                runOnUiThread {
                    updateConnectionStatusUI()
                    if (!isIpConnected) {
                        resetToDefaultState()
                    }
                    logMessage(">> MQTT Client Disconnected.\n")
                }
            }
        }
    }

    private fun subscribeMqttTopics(profile: Int) {
        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        val tCmd = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_MQTT_TOPIC_CMD, profile), "home/room$profile/command")
            ?: "home/room$profile/command"
        val tState = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_MQTT_TOPIC_STATE, profile), "home/room$profile/state")
            ?: "home/room$profile/state"

        mqttClient?.subscribeWith()?.topicFilter(tCmd)?.callback { publish ->
            val msg = String(publish.payloadAsBytes)
            logMessage("<< [MQTT Cmd] $msg\n")
            parseArduinoFeedback(msg)
        }?.send()

        mqttClient?.subscribeWith()?.topicFilter(tState)?.callback { publish ->
            val msg = String(publish.payloadAsBytes)
            logMessage("<< [MQTT State] $msg\n")
            parseArduinoFeedback(msg)
        }?.send()
    }

    private fun sendCommand(cmd: String) {
        val currentProfile = activeProfile
        scope.launch {
            val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
            val isMqttEnabled = prefs.getBoolean(ConfigActivity.key(ConfigActivity.KEY_MQTT_ENABLED, currentProfile), true)

            if (isIpConnected && webSocket != null) {
                val payload = JSONObject().put("command", cmd).toString()
                webSocket?.send(payload)
                logMessage(">> [D$currentProfile] $cmd (WebSocket IP)\n")
            } else if (isMqttEnabled && isMqttConnected && mqttClient?.state?.isConnected == true) {
                val tCmd = prefs.getString(
                    ConfigActivity.key(ConfigActivity.KEY_MQTT_TOPIC_CMD, currentProfile),
                    "home/room$currentProfile/command"
                ) ?: "home/room$currentProfile/command"

                val mqttPayload = JSONObject().put("command", cmd).toString()
                mqttClient?.publishWith()
                    ?.topic(tCmd)
                    ?.payload(mqttPayload.toByteArray())
                    ?.send()
                logMessage(">> [D$currentProfile] $cmd (MQTT Broadcast)\n")
            } else {
                logMessage(">> [D$currentProfile] $cmd (Failed - Not Connected to ESP Device)\n")
            }
        }
    }

    private fun parseArduinoFeedback(jsonStr: String) {
        try {
            val data = JSONObject(jsonStr)
            for (i in 1..4) {
                val key = "POWER$i"
                if (data.has(key)) {
                    val isOn = data.getString(key) == "ON"
                    relayStates[i - 1] = isOn
                    runOnUiThread { updateUiRelay(i - 1, isOn) }
                }
            }
            if (data.has("Dimmer")) {
                val dimVal = data.getInt("Dimmer")
                lastSentDimmer = dimVal
                runOnUiThread {
                    if (binding.dimmerSeekBar.progress != dimVal) {
                        binding.dimmerSeekBar.progress = dimVal
                        updateDimmerText(dimVal)
                    }
                }
            }
        } catch (_: Exception) {}
    }

    private fun updateUiRelay(idx: Int, isOn: Boolean) {
        val buttons = listOf(binding.btnRelay1, binding.btnRelay2, binding.btnRelay3, binding.btnRelay4)
        val btn = buttons[idx]
        if (isOn) {
            btn.text = getString(R.string.relay_on_label, idx + 1)
            btn.backgroundTintList = ColorStateList.valueOf("#4CAF50".toColorInt())
            btn.setTextColor("#FFFFFF".toColorInt())
        } else {
            btn.text = getString(R.string.relay_off_label, idx + 1)
            btn.backgroundTintList = ColorStateList.valueOf("#6200EE".toColorInt())
            btn.setTextColor("#FFFFFF".toColorInt())
        }
    }

    private fun updateConnectionStatusUI() {
        if (isIpConnected) {
            binding.tvConnectionStatus.text = getString(R.string.status_connected_ip)
            binding.tvConnectionStatus.setTextColor("#2E7D32".toColorInt())
            binding.btnConnectIp.text = getString(R.string.btn_disconnect)
            binding.btnConnectIp.backgroundTintList = ColorStateList.valueOf("#4CAF50".toColorInt())
        } else if (isMqttConnected) {
            binding.tvConnectionStatus.text = getString(R.string.status_connected_mqtt)
            binding.tvConnectionStatus.setTextColor("#2E7D32".toColorInt())
            binding.btnConnectIp.text = getString(R.string.btn_connect_ip)
            binding.btnConnectIp.backgroundTintList = ColorStateList.valueOf("#6200EE".toColorInt())
        } else {
            binding.tvConnectionStatus.text = getString(R.string.status_disconnected)
            binding.tvConnectionStatus.setTextColor("#D32F2F".toColorInt())
            binding.btnConnectIp.text = getString(R.string.btn_connect_ip)
            binding.btnConnectIp.backgroundTintList = ColorStateList.valueOf("#6200EE".toColorInt())
        }
    }

    private fun logMessage(msg: String) {
        runOnUiThread {
            binding.tvConsoleLog.append(msg)
            val innerHeight = binding.tvConsoleLog.layout?.height ?: 0
            if (innerHeight > binding.tvConsoleLog.height) {
                binding.tvConsoleLog.scrollTo(0, innerHeight - binding.tvConsoleLog.height)
            }
        }
    }

    override fun onDestroy() {
        BackgroundVoiceService.detachActivity(this)
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        networkCallback?.let { cb ->
            try {
                connectivityManager?.unregisterNetworkCallback(cb)
            } catch (_: Exception) {
            }
        }
        networkCallback = null
        disconnectWebSocket()
        disconnectMqttClient()
    }
}