package com.sasoftwares.homeautomationcontroller

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.content.res.ColorStateList
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.util.Log
import android.view.WindowManager
import android.widget.Button
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import androidx.core.content.edit
import androidx.core.graphics.toColorInt
import com.hivemq.client.mqtt.MqttClient
import com.hivemq.client.mqtt.mqtt5.Mqtt5AsyncClient
import com.sasoftwares.homeautomationcontroller.databinding.ActivityMainBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    private var mqttClient: Mqtt5AsyncClient? = null
    private var webSocket: WebSocket? = null
    private val okHttpClient = OkHttpClient()
    private val scope = CoroutineScope(Dispatchers.IO)
    private val handler = Handler(Looper.getMainLooper())

    private var connectivityManager: ConnectivityManager? = null
    private var networkCallback: ConnectivityManager.NetworkCallback? = null
    private var isNetworkAvailable = false

    private val groqVoice = GroqVoiceController(okHttpClient)
    private var speechRecognizer: SpeechRecognizer? = null
    private var wakeListenGeneration = 0
    private var tts: TextToSpeech? = null
    private var isTtsReady = false

    private var wakeWordArmed = false
    private var awaitingCommandAfterWake = false
    private var isProcessingGroqCommand = false
    private var isActivityVisible = false

    private val relayStates = BooleanArray(4) { false }
    private var lastSentDimmer = 0
    private var isIpConnected = false
    private var isMqttConnected = false
    private var activeProfile: Int = 1 // 1..4

    private val recordAudioPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
            if (isGranted) {
                armWakeWordMode()
            } else {
                wakeWordArmed = false
                awaitingCommandAfterWake = false
                stopBackgroundVoiceService()
                updateVoiceButtonUI()
                logMessage(">> Microphone permission denied. Wake word unavailable.\n")
                Toast.makeText(this, "Microphone permission is required for voice commands", Toast.LENGTH_SHORT).show()
            }
        }

    companion object {
        private const val KEY_MANUAL_DISCONNECT = "manual_disconnect_flag"
        private const val VOICE_CHANNEL_ID = "home_automation_voice_channel"
        private const val VOICE_NOTIFICATION_ID = 1001
        private const val ACTION_START_VOICE_BG = "com.sasoftwares.homeautomationcontroller.action.START_VOICE_BG"
        private const val ACTION_STOP_VOICE_BG = "com.sasoftwares.homeautomationcontroller.action.STOP_VOICE_BG"
    }

    class BackgroundVoiceService : Service() {
        override fun onCreate() {
            super.onCreate()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    VOICE_CHANNEL_ID,
                    "Voice & Device Background Service",
                    NotificationManager.IMPORTANCE_LOW
                )
                val manager = getSystemService(NotificationManager::class.java)
                manager.createNotificationChannel(channel)
            }
        }

        override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
            if (intent?.action == ACTION_STOP_VOICE_BG) {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }

            val openAppIntent = Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            }
            val pendingIntent = PendingIntent.getActivity(
                this,
                0,
                openAppIntent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )

            val notification: Notification = NotificationCompat.Builder(this, VOICE_CHANNEL_ID)
                .setContentTitle("Home Automation Background Active")
                .setContentText("Wake word armed • Tap to open")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentIntent(pendingIntent)
                .setOngoing(true)
                .build()

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(
                    VOICE_NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                )
            } else {
                startForeground(VOICE_NOTIFICATION_ID, notification)
            }

            return START_STICKY
        }

        override fun onBind(intent: Intent?): IBinder? = null
    }

    private fun startBackgroundVoiceService() {
        val intent = Intent(this, BackgroundVoiceService::class.java).apply {
            action = ACTION_START_VOICE_BG
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    private fun stopBackgroundVoiceService() {
        val intent = Intent(this, BackgroundVoiceService::class.java).apply {
            action = ACTION_STOP_VOICE_BG
        }
        startService(intent)
    }

    private fun keepScreenAwake() {
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun bringAppToFrontIfNeeded() {
        if (isActivityVisible) return
        val intent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        startActivity(intent)
    }

    private fun normalizePhrase(raw: String): String {
        return raw.lowercase()
            .replace(Regex("""[^a-z0-9\s]"""), " ")
            .replace(Regex("""\s+"""), " ")
            .trim()
    }

    private fun getActiveWakeWords(): List<String> {
        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        val customRaw = prefs.getString(
            ConfigActivity.key(ConfigActivity.KEY_WAKE_WORD, activeProfile),
            ConfigActivity.DEFAULT_WAKE_WORD
        ).orEmpty()

        val customPhrases = customRaw.split(",")
            .map { normalizePhrase(it) }
            .filter { it.isNotEmpty() }
            .distinct()

        if (customPhrases.isNotEmpty()) {
            return customPhrases
        }

        return listOf(normalizePhrase(ConfigActivity.DEFAULT_WAKE_WORD))
    }

    private fun getPrimaryWakeWordDisplay(): String {
        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        val raw = prefs.getString(
            ConfigActivity.key(ConfigActivity.KEY_WAKE_WORD, activeProfile),
            ConfigActivity.DEFAULT_WAKE_WORD
        ).orEmpty()
        return raw.split(",").map { it.trim() }.firstOrNull { it.isNotEmpty() }
            ?: ConfigActivity.DEFAULT_WAKE_WORD
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        keepScreenAwake()
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
        }

        initTextToSpeech()
        registerNetworkMonitor()

        activeProfile = getSavedActiveProfile()
        wakeWordArmed = false
        setupControls()
        updateActiveProfileUI()
        resetToDefaultState()
        updateVoiceButtonUI()

        autoConnectWebSocket()
    }

    private fun registerNetworkMonitor() {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return
        connectivityManager = cm
        isNetworkAvailable = checkCurrentNetworkState(cm)

        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                runOnUiThread {
                    val wasOffline = !isNetworkAvailable
                    isNetworkAvailable = checkCurrentNetworkState(cm)
                    if (wasOffline) {
                        logMessage(">> Internet/network restored [Device: $activeProfile]. Reviving connections...\n")
                    }
                    reviveConnectionsIfNeeded()
                }
            }

            override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) {
                val hasInternet = networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                        networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
                runOnUiThread {
                    val wasOffline = !isNetworkAvailable
                    isNetworkAvailable = hasInternet || checkCurrentNetworkState(cm)
                    if (wasOffline && isNetworkAvailable) {
                        logMessage(">> Network validated [Device: $activeProfile]. Reviving connections...\n")
                        reviveConnectionsIfNeeded()
                    }
                }
            }

            override fun onLost(network: Network) {
                runOnUiThread {
                    isNetworkAvailable = checkCurrentNetworkState(cm)
                    if (!isNetworkAvailable) {
                        logMessage(">> Network/internet dropped! Cleaning up active sockets...\n")
                        handleNetworkLost()
                    }
                }
            }
        }

        networkCallback = callback
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                cm.registerDefaultNetworkCallback(callback)
            } else {
                val req = NetworkRequest.Builder()
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .build()
                cm.registerNetworkCallback(req, callback)
            }
        } catch (e: Exception) {
            Log.e("NET_MON", "Failed to register network callback", e)
        }
    }

    private fun checkCurrentNetworkState(cm: ConnectivityManager): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val activeNet = cm.activeNetwork ?: return false
                val caps = cm.getNetworkCapabilities(activeNet) ?: return false
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            } else {
                @Suppress("DEPRECATION")
                cm.activeNetworkInfo?.isConnected == true
            }
        } catch (_: Exception) {
            false
        }
    }

    private fun handleNetworkLost() {
        webSocket?.cancel()
        webSocket = null
        isIpConnected = false

        if (isMqttConnected || mqttClient != null) {
            disconnectMqttClient()
        }

        updateConnectionStatusUI()
        resetToDefaultState()
    }

    private fun reviveConnectionsIfNeeded() {
        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        val isManualDisconnect = prefs.getBoolean(ConfigActivity.key(KEY_MANUAL_DISCONNECT, activeProfile), false)

        if (!isIpConnected && !isMqttConnected && !isManualDisconnect) {
            autoConnectWebSocket()
        } else {
            checkAndHandleMqttState()
        }

        if (wakeWordArmed &&
            isActivityVisible &&
            !isProcessingGroqCommand &&
            !groqVoice.isRecording() &&
            speechRecognizer == null
        ) {
            scheduleWakeWordRestart(250L)
        }
    }

    private fun initTextToSpeech() {
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.US
                tts?.setSpeechRate(1.05f)
                isTtsReady = true
            }
        }
    }

    private fun speakShortReply(text: String) {
        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        val enabled = prefs.getBoolean(ConfigActivity.key(ConfigActivity.KEY_TTS_ENABLED, activeProfile), true)
        if (!enabled || !isTtsReady) return

        val cleaned = text.replace(Regex("""[*#]"""), "").replace(Regex("""\s+"""), " ").trim()
        if (cleaned.isEmpty()) return
        val clipped = if (cleaned.length > 140) {
            cleaned.take(140).substringBeforeLast(" ").ifEmpty { cleaned.take(140) } + "."
        } else {
            cleaned
        }
        tts?.speak(clipped, TextToSpeech.QUEUE_FLUSH, null, "groq_reply_${System.currentTimeMillis()}")
    }

    override fun onStart() {
        super.onStart()
        keepScreenAwake()
        isActivityVisible = true
        if (wakeWordArmed &&
            !isProcessingGroqCommand &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        ) {
            startBackgroundVoiceService()
            scheduleWakeWordRestart(150L)
        }
    }

    override fun onStop() {
        super.onStop()
        isActivityVisible = false
        wakeListenGeneration++
        handler.removeCallbacksAndMessages(null)
        destroySpeechRecognizerSafely()
        if (groqVoice.isRecording()) {
            groqVoice.requestStopRecording()
        }
        awaitingCommandAfterWake = false
        updateVoiceButtonUI()
    }

    override fun onResume() {
        super.onResume()
        keepScreenAwake()
        isActivityVisible = true
        val cm = connectivityManager
        if (cm != null) {
            isNetworkAvailable = checkCurrentNetworkState(cm)
        }

        val latestProfile = getSavedActiveProfile()
        if (latestProfile != activeProfile) {
            switchToProfile(latestProfile, forceConnect = false)
            return
        }

        updateActiveProfileUI()
        updateConnectionStatusUI()
        updateVoiceButtonUI()

        if (wakeWordArmed &&
            isActivityVisible &&
            !isProcessingGroqCommand &&
            !groqVoice.isRecording() &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        ) {
            scheduleWakeWordRestart(150L)
        }

        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        val isManualDisconnect = prefs.getBoolean(ConfigActivity.key(KEY_MANUAL_DISCONNECT, activeProfile), false)

        if (!isIpConnected && !isMqttConnected && !isManualDisconnect) {
            logMessage(">> App resumed [Device: $activeProfile]. Reviving connection...\n")
            autoConnectWebSocket()
        } else {
            checkAndHandleMqttState()
        }
    }

    private fun getSavedActiveProfile(): Int {
        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getInt(ConfigActivity.KEY_ACTIVE_PROFILE, 1).coerceIn(1, 4)
    }

    private fun setSavedActiveProfile(profile: Int) {
        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit { putInt(ConfigActivity.KEY_ACTIVE_PROFILE, profile.coerceIn(1, 4)) }
    }

    private fun switchToProfile(profile: Int, forceConnect: Boolean) {
        activeProfile = profile.coerceIn(1, 4)
        setSavedActiveProfile(activeProfile)
        if (forceConnect) {
            setManualDisconnectFlag(false)
        }

        updateActiveProfileUI()
        resetToDefaultState()
        logMessage(">> Switched to Device: $activeProfile.\n")

        webSocket?.cancel()
        webSocket = null
        isIpConnected = false

        if (isMqttConnected || mqttClient != null) {
            disconnectMqttClient()
        }

        updateConnectionStatusUI()
        autoConnectWebSocket()
    }

    private fun updateActiveProfileUI() {
        binding.tvActiveConfig.text = getString(R.string.active_config_format, activeProfile)
        val buttons = listOf(
            binding.btnSelectConfig1,
            binding.btnSelectConfig2,
            binding.btnSelectConfig3,
            binding.btnSelectConfig4
        )
        buttons.forEachIndexed { index, button ->
            val profileNum = index + 1
            val isSelected = profileNum == activeProfile
            val colorHex = if (isSelected) "#2E7D32" else "#6200EE"
            button.backgroundTintList = ColorStateList.valueOf(colorHex.toColorInt())
            button.setTextColor("#FFFFFF".toColorInt())
        }
    }

    private fun updateVoiceButtonUI() {
        when {
            groqVoice.isRecording() -> {
                binding.btnVoiceCommand.text = "Recording Groq Command… Tap to Send"
                binding.btnVoiceCommand.backgroundTintList = ColorStateList.valueOf("#2E7D32".toColorInt())
                binding.btnVoiceCommand.isEnabled = true
            }
            isProcessingGroqCommand -> {
                binding.btnVoiceCommand.text = "Groq Thinking…"
                binding.btnVoiceCommand.backgroundTintList = ColorStateList.valueOf("#1565C0".toColorInt())
                binding.btnVoiceCommand.isEnabled = false
            }
            awaitingCommandAfterWake -> {
                binding.btnVoiceCommand.text = getString(R.string.btn_voice_listening)
                binding.btnVoiceCommand.backgroundTintList = ColorStateList.valueOf("#2E7D32".toColorInt())
                binding.btnVoiceCommand.isEnabled = true
            }
            wakeWordArmed -> {
                binding.btnVoiceCommand.text = getString(R.string.btn_voice_wake_armed)
                binding.btnVoiceCommand.backgroundTintList = ColorStateList.valueOf("#1565C0".toColorInt())
                binding.btnVoiceCommand.isEnabled = true
            }
            else -> {
                binding.btnVoiceCommand.text = getString(R.string.btn_voice_command)
                binding.btnVoiceCommand.backgroundTintList = ColorStateList.valueOf("#00796B".toColorInt())
                binding.btnVoiceCommand.isEnabled = true
            }
        }
        binding.btnVoiceCommand.setTextColor("#FFFFFF".toColorInt())
    }

    private fun setupControls() {
        val profileButtons = listOf(
            binding.btnSelectConfig1,
            binding.btnSelectConfig2,
            binding.btnSelectConfig3,
            binding.btnSelectConfig4
        )
        profileButtons.forEachIndexed { index, button ->
            val targetProfile = index + 1
            button.setOnClickListener {
                if (targetProfile == activeProfile && (isIpConnected || isMqttConnected)) {
                    return@setOnClickListener
                }
                switchToProfile(targetProfile, forceConnect = true)
            }
        }

        val relayButtons = listOf(binding.btnRelay1, binding.btnRelay2, binding.btnRelay3, binding.btnRelay4)

        relayButtons.forEachIndexed { index, button ->
            button.setOnClickListener {
                if (!isIpConnected && !isMqttConnected) {
                    logMessage(">> Action blocked: Not connected to ESP device.\n")
                    return@setOnClickListener
                }
                val targetState = !relayStates[index]
                val stateStr = if (targetState) "ON" else "OFF"
                sendCommand("POWER${index + 1} $stateStr")
            }
        }

        binding.dimmerSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    updateDimmerText(progress)
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                if (!isIpConnected && !isMqttConnected) {
                    logMessage(">> Action blocked: Not connected to ESP device.\n")
                    return
                }
                seekBar?.let {
                    updateDimmerText(it.progress)
                    sendDimmerCommand(it.progress)
                }
            }
        })

        setupButtonTapEffect(binding.btnDimmerMin) { sendDimmerCommand(0) }
        setupButtonTapEffect(binding.btnDimmerMax) { sendDimmerCommand(9) }
        setupButtonTapEffect(binding.btnDimmerMinus) {
            val newProg = maxOf(0, binding.dimmerSeekBar.progress - 1)
            sendDimmerCommand(newProg)
        }
        setupButtonTapEffect(binding.btnDimmerPlus) {
            val newProg = minOf(9, binding.dimmerSeekBar.progress + 1)
            sendDimmerCommand(newProg)
        }

        setupButtonTapEffect(binding.btnAllOn) { sendCommand("ALL_ON") }
        setupButtonTapEffect(binding.btnAllOff) { sendCommand("ALL_OFF") }
        setupButtonTapEffect(binding.btnGetStatus) { sendCommand("STATUS") }

        binding.btnConfig.backgroundTintList = ColorStateList.valueOf("#6200EE".toColorInt())
        binding.btnConfig.setTextColor("#FFFFFF".toColorInt())
        binding.btnConfig.setOnClickListener {
            startActivity(Intent(this, ConfigActivity::class.java))
        }

        binding.btnConnectIp.setOnClickListener {
            if (!isIpConnected) {
                clearManualDisconnectFlag()
                connectWebSocket()
            } else {
                setManualDisconnectFlag(true)
                disconnectWebSocket()
            }
        }

        binding.btnVoiceCommand.setOnClickListener {
            if (groqVoice.isRecording()) {
                groqVoice.requestStopRecording()
                return@setOnClickListener
            }
            if (isProcessingGroqCommand) return@setOnClickListener

            if (wakeWordArmed) {
                disarmWakeWordMode()
                return@setOnClickListener
            }

            val hasPermission = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            if (hasPermission) {
                armWakeWordMode()
            } else {
                recordAudioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
        }
    }

    private fun armWakeWordMode() {
        keepScreenAwake()
        bringAppToFrontIfNeeded()
        wakeWordArmed = true
        awaitingCommandAfterWake = false
        updateVoiceButtonUI()
        startBackgroundVoiceService()
        val primaryWake = getPrimaryWakeWordDisplay()
        logMessage(">> Wake word armed. Say \"$primaryWake\" to record a Groq command.\n")
        if (isActivityVisible) {
            scheduleWakeWordRestart(100L)
        }
    }

    private fun disarmWakeWordMode() {
        wakeWordArmed = false
        awaitingCommandAfterWake = false
        wakeListenGeneration++
        handler.removeCallbacksAndMessages(null)
        destroySpeechRecognizerSafely()
        if (groqVoice.isRecording()) {
            groqVoice.requestStopRecording()
        }
        stopBackgroundVoiceService()
        updateVoiceButtonUI()
        logMessage(">> Wake word mode disarmed.\n")
    }

    private fun destroySpeechRecognizerSafely() {
        val current = speechRecognizer
        speechRecognizer = null
        if (current != null) {
            try {
                current.cancel()
            } catch (_: Exception) {
            }
            try {
                current.destroy()
            } catch (_: Exception) {
            }
        }
    }

    private fun scheduleWakeWordRestart(delayMs: Long) {
        wakeListenGeneration++
        val expectedGen = wakeListenGeneration
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({
            if (expectedGen == wakeListenGeneration &&
                wakeWordArmed &&
                isActivityVisible &&
                !isProcessingGroqCommand &&
                !groqVoice.isRecording()
            ) {
                startWakeWordListenCycle(expectedGen)
            }
        }, delayMs)
    }

    private fun createFreshSpeechRecognizer(expectedGen: Int): SpeechRecognizer? {
        destroySpeechRecognizerSafely()

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            logMessage(">> Speech recognition is not available on this device.\n")
            return null
        }

        val recognizer = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                SpeechRecognizer.isOnDeviceRecognitionAvailable(this)
            ) {
                SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
            } else {
                SpeechRecognizer.createSpeechRecognizer(this)
            }
        } catch (e: Exception) {
            Log.e("WAKE_WORD", "Failed to create SpeechRecognizer", e)
            return null
        }

        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                if (expectedGen == wakeListenGeneration) updateVoiceButtonUI()
            }

            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}

            override fun onError(error: Int) {
                if (expectedGen != wakeListenGeneration) return
                awaitingCommandAfterWake = false
                updateVoiceButtonUI()
                destroySpeechRecognizerSafely()

                if (!wakeWordArmed || !isActivityVisible || isProcessingGroqCommand) return

                val backoffMs = when (error) {
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY,
                    SpeechRecognizer.ERROR_CLIENT,
                    SpeechRecognizer.ERROR_SERVER,
                    SpeechRecognizer.ERROR_NETWORK -> 1200L
                    SpeechRecognizer.ERROR_NO_MATCH,
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> 450L
                    else -> 800L
                }
                scheduleWakeWordRestart(backoffMs)
            }

            override fun onResults(results: Bundle?) {
                if (expectedGen != wakeListenGeneration) return
                val spokenText = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    .orEmpty()
                    .trim()

                destroySpeechRecognizerSafely()

                if (!wakeWordArmed || !isActivityVisible || isProcessingGroqCommand) {
                    awaitingCommandAfterWake = false
                    updateVoiceButtonUI()
                    return
                }

                val triggeredWake = spokenText.isNotEmpty() && handleWakeWordUtterance(spokenText)
                if (!triggeredWake && spokenText.isNotEmpty()) {
                    logMessage(">> [Wake Heard] \"$spokenText\" (expected: ${getActiveWakeWords().joinToString()})\n")
                }
                updateVoiceButtonUI()

                if (!triggeredWake) {
                    scheduleWakeWordRestart(300L)
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {
                if (expectedGen != wakeListenGeneration) return
                if (!wakeWordArmed || !isActivityVisible || isProcessingGroqCommand) return
                val partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    .orEmpty()
                    .trim()
                if (partial.isNotEmpty() && containsWakeWord(partial)) {
                    wakeListenGeneration++
                    destroySpeechRecognizerSafely()
                    handleWakeWordUtterance(partial)
                }
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        speechRecognizer = recognizer
        return recognizer
    }

    private fun startWakeWordListenCycle(expectedGen: Int) {
        if (expectedGen != wakeListenGeneration) return
        if (!wakeWordArmed || !isActivityVisible || isProcessingGroqCommand || groqVoice.isRecording()) return

        val recognizer = createFreshSpeechRecognizer(expectedGen) ?: run {
            scheduleWakeWordRestart(1500L)
            return
        }

        awaitingCommandAfterWake = false
        updateVoiceButtonUI()

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                SpeechRecognizer.isOnDeviceRecognitionAvailable(this@MainActivity)
            ) {
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            }
        }

        try {
            recognizer.startListening(intent)
        } catch (e: Exception) {
            Log.e("WAKE_WORD", "startListening failed", e)
            destroySpeechRecognizerSafely()
            scheduleWakeWordRestart(1200L)
        }
    }

    private fun containsWakeWord(text: String): Boolean {
        val normalizedSpoken = " ${normalizePhrase(text)} "
        if (normalizedSpoken.isBlank()) return false
        return getActiveWakeWords().any { phrase ->
            val cleanPhrase = phrase.trim()
            cleanPhrase.isNotEmpty() && normalizedSpoken.contains(" $cleanPhrase ")
        }
    }

    @Synchronized
    private fun handleWakeWordUtterance(spokenText: String): Boolean {
        if (isProcessingGroqCommand || groqVoice.isRecording()) return false
        val normalizedSpoken = " ${normalizePhrase(spokenText)} "
        val matchedWake = getActiveWakeWords().firstOrNull { phrase ->
            val cleanPhrase = phrase.trim()
            cleanPhrase.isNotEmpty() && normalizedSpoken.contains(" $cleanPhrase ")
        } ?: return false

        wakeListenGeneration++
        handler.removeCallbacksAndMessages(null)
        destroySpeechRecognizerSafely()
        runOnUiThread {
            keepScreenAwake()
            bringAppToFrontIfNeeded()
        }
        awaitingCommandAfterWake = true
        updateVoiceButtonUI()
        logMessage(">> Wake word detected (\"$matchedWake\") from \"$spokenText\". Capturing audio for Groq…\n")
        startGroqVoiceRecording(resumeWakeWordAfter = wakeWordArmed)
        return true
    }

    private fun startGroqVoiceRecording(resumeWakeWordAfter: Boolean) {
        if (groqVoice.isRecording() || isProcessingGroqCommand) return

        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        val apiKey = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_GROQ_API_KEY, activeProfile), "").orEmpty()
        val modelName = prefs.getString(
            ConfigActivity.key(ConfigActivity.KEY_GROQ_MODEL, activeProfile),
            ConfigActivity.DEFAULT_GROQ_MODEL
        ).orEmpty()

        startBackgroundVoiceService()
        logMessage(">> [Groq Mic] Recording (up to ${GroqVoiceController.MAX_RECORD_SECONDS}s)…\n")

        scope.launch {
            runOnUiThread { updateVoiceButtonUI() }
            val wavBytes = groqVoice.recordWav(GroqVoiceController.MAX_RECORD_SECONDS) { msg ->
                logMessage(msg)
            }

            runOnUiThread {
                awaitingCommandAfterWake = false
                isProcessingGroqCommand = true
                updateVoiceButtonUI()
            }

            try {
                if (wavBytes == null || wavBytes.isEmpty()) {
                    logMessage(">> [Groq Mic] No audio captured.\n")
                    return@launch
                }

                val transcript = groqVoice.transcribeWav(wavBytes, apiKey)
                logMessage(">> [Groq Whisper] ${transcript.ifEmpty { "(empty)" }}\n")
                if (transcript.isBlank()) {
                    speakShortReply("Could not hear clear speech.")
                    return@launch
                }

                val bridge = object : GroqVoiceController.HardwareBridge {
                    override fun sendRawCommand(cmd: String) {
                        sendCommand(cmd)
                    }

                    override fun setDimmerLevel(level: Int) {
                        val clamped = level.coerceIn(0, 9)
                        runOnUiThread {
                            binding.dimmerSeekBar.progress = clamped
                            updateDimmerText(clamped)
                        }
                        lastSentDimmer = -1
                        sendDimmerCommand(clamped)
                    }

                    override fun switchProfile(profile: Int) {
                        runOnUiThread { switchToProfile(profile, forceConnect = true) }
                    }

                    override fun getRelayStates(): BooleanArray = relayStates.copyOf()

                    override fun getDimmerLevel(): Int = binding.dimmerSeekBar.progress

                    override fun onLog(msg: String) {
                        logMessage(msg)
                    }
                }

                val reply = groqVoice.runIntent(transcript, apiKey, modelName, bridge)
                logMessage(">> [Groq] $reply\n")
                runOnUiThread { speakShortReply(reply) }
            } catch (e: Exception) {
                Log.e("GROQ_VOICE", "Voice pipeline error", e)
                logMessage(">> [Groq Error] ${e.localizedMessage ?: e.message}\n")
                runOnUiThread { speakShortReply("Voice command failed.") }
            } finally {
                runOnUiThread {
                    isProcessingGroqCommand = false
                    updateVoiceButtonUI()
                    if (resumeWakeWordAfter && wakeWordArmed && isActivityVisible) {
                        scheduleWakeWordRestart(600L)
                    } else if (!wakeWordArmed) {
                        stopBackgroundVoiceService()
                    }
                }
            }
        }
    }

    private fun resetToDefaultState() {
        val relayButtons = listOf(binding.btnRelay1, binding.btnRelay2, binding.btnRelay3, binding.btnRelay4)
        relayButtons.forEachIndexed { index, button ->
            relayStates[index] = false
            button.text = getString(R.string.relay_off_label, index + 1)
            button.backgroundTintList = ColorStateList.valueOf("#6200EE".toColorInt())
            button.setTextColor("#FFFFFF".toColorInt())
        }
        lastSentDimmer = 0
        binding.dimmerSeekBar.progress = 0
        updateDimmerText(0)
    }

    private fun setupButtonTapEffect(button: Button, action: () -> Unit) {
        button.backgroundTintList = ColorStateList.valueOf("#6200EE".toColorInt())
        button.setTextColor("#FFFFFF".toColorInt())
        button.setOnClickListener {
            if (!isIpConnected && !isMqttConnected) {
                logMessage(">> Action blocked: Not connected to ESP device.\n")
                return@setOnClickListener
            }
            button.backgroundTintList = ColorStateList.valueOf("#4CAF50".toColorInt())
            action()
            handler.postDelayed({
                button.backgroundTintList = ColorStateList.valueOf("#6200EE".toColorInt())
            }, 250)
        }
    }

    private fun setManualDisconnectFlag(disconnected: Boolean) {
        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit { putBoolean(ConfigActivity.key(KEY_MANUAL_DISCONNECT, activeProfile), disconnected) }
    }

    private fun clearManualDisconnectFlag() {
        setManualDisconnectFlag(false)
    }

    private fun updateDimmerText(progress: Int) {
        binding.tvDimmerValue.text = getString(R.string.dimmer_level_text, progress)
    }

    private fun sendDimmerCommand(valInt: Int) {
        if (valInt != lastSentDimmer) {
            lastSentDimmer = valInt
            sendCommand("DIMMER:$valInt")
        }
    }

    private fun autoConnectWebSocket() {
        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        val ip = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_IP, activeProfile), "")?.trim()
        val isManualDisconnect = prefs.getBoolean(ConfigActivity.key(KEY_MANUAL_DISCONNECT, activeProfile), false)

        if (!ip.isNullOrEmpty() && !isManualDisconnect) {
            connectWebSocket()
        } else {
            logMessage(">> Auto-connect IP skipped [Device: $activeProfile]. Falling back to MQTT check…\n")
            checkAndHandleMqttState()
        }
    }

    private fun connectWebSocket() {
        webSocket?.cancel()
        webSocket = null

        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        val ip = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_IP, activeProfile), "192.168.29.110")?.trim()
        val user = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_USER, activeProfile), "admin")?.trim()
        val pass = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_PASS, activeProfile), "admin1234S")?.trim()

        if (ip.isNullOrEmpty()) {
            logMessage(">> Error: No IP configured in Device: $activeProfile.\n")
            checkAndHandleMqttState()
            return
        }

        if (isMqttConnected || mqttClient != null) {
            logMessage(">> IP connection starting. Disconnecting active MQTT client…\n")
            disconnectMqttClient()
        }

        val request = Request.Builder().url("ws://$ip:81/").build()
        logMessage(">> [Device: $activeProfile] Connecting to WebSocket ws://$ip:81/…\n")

        webSocket = okHttpClient.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                isIpConnected = true
                runOnUiThread {
                    updateConnectionStatusUI()
                    logMessage(">> Connected to ESP WebSocket. Authenticating…\n")
                }

                val authPayload = JSONObject().apply {
                    put("auth", JSONObject().put("user", user).put("pass", pass))
                }.toString()
                webSocket.send(authPayload)

                sendCommand("STATUS")
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                logMessage("<< $text\n")
                parseArduinoFeedback(text)
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                isIpConnected = false
                runOnUiThread {
                    updateConnectionStatusUI()
                    resetToDefaultState()
                    logMessage(">> WebSocket Error: ${t.localizedMessage}\n")
                    checkAndHandleMqttState()
                }
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                isIpConnected = false
                runOnUiThread {
                    updateConnectionStatusUI()
                    resetToDefaultState()
                    logMessage(">> IP WebSocket Disconnected.\n")
                    checkAndHandleMqttState()
                }
            }
        })
    }

    private fun disconnectWebSocket() {
        webSocket?.close(1000, "User disconnected")
        webSocket = null
        isIpConnected = false
        updateConnectionStatusUI()
        resetToDefaultState()
        logMessage(">> IP WebSocket Disconnected manually.\n")

        checkAndHandleMqttState()
    }

    private fun checkAndHandleMqttState() {
        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        val isMqttEnabled = prefs.getBoolean(ConfigActivity.key(ConfigActivity.KEY_MQTT_ENABLED, activeProfile), true)

        if (isMqttEnabled) {
            if (!isIpConnected && !isMqttConnected && (mqttClient == null || mqttClient?.state?.isConnected != true)) {
                initMqttClient()
            }
        } else {
            if (isMqttConnected || mqttClient != null) {
                disconnectMqttClient()
                logMessage(">> MQTT disabled in Device: $activeProfile. Disconnecting client.\n")
            }
        }
    }

    private fun initMqttClient() {
        val targetProfile = activeProfile
        scope.launch {
            val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
            val isMqttEnabled = prefs.getBoolean(ConfigActivity.key(ConfigActivity.KEY_MQTT_ENABLED, targetProfile), true)

            if (!isMqttEnabled || isIpConnected || targetProfile != activeProfile) {
                logMessage(">> MQTT connection skipped (Disabled, IP connected, or device changed).\n")
                return@launch
            }

            try {
                val server = prefs.getString(
                    ConfigActivity.key(ConfigActivity.KEY_MQTT_SERVER, targetProfile),
                    "i11b0026.ala.eu-central-1.emqxsl.com"
                ) ?: "i11b0026.ala.eu-central-1.emqxsl.com"
                val port = prefs.getInt(ConfigActivity.key(ConfigActivity.KEY_MQTT_PORT, targetProfile), 8883)
                val user = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_MQTT_USER, targetProfile), "admin") ?: "admin"
                val pass = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_MQTT_PASS, targetProfile), "admin1234S") ?: "admin1234S"

                logMessage(">> [Device: $targetProfile] Connecting to MQTT Broker…\n")

                mqttClient = MqttClient.builder()
                    .useMqttVersion5()
                    .serverHost(server)
                    .serverPort(port)
                    .sslWithDefaultConfig()
                    .buildAsync()

                mqttClient?.connectWith()
                    ?.simpleAuth()
                    ?.username(user)
                    ?.password(pass.toByteArray())
                    ?.applySimpleAuth()
                    ?.send()
                    ?.whenComplete { _, throwable ->
                        runOnUiThread {
                            val stillEnabled = prefs.getBoolean(
                                ConfigActivity.key(ConfigActivity.KEY_MQTT_ENABLED, targetProfile),
                                true
                            )
                            if (!stillEnabled || isIpConnected || targetProfile != activeProfile) {
                                disconnectMqttClient()
                                return@runOnUiThread
                            }

                            if (throwable == null) {
                                isMqttConnected = true
                                updateConnectionStatusUI()
                                logMessage(">> [Device: $targetProfile] Connected to MQTT Broker successfully!\n")
                                subscribeMqttTopics(targetProfile)
                                sendCommand("STATUS")
                            } else {
                                isMqttConnected = false
                                updateConnectionStatusUI()
                                resetToDefaultState()
                                logMessage(">> MQTT Connection failed: ${throwable.localizedMessage}\n")
                            }
                        }
                    }
            } catch (e: Exception) {
                Log.e("MQTT", "Connection Error", e)
                isMqttConnected = false
                runOnUiThread {
                    updateConnectionStatusUI()
                    resetToDefaultState()
                }
            }
        }
    }

    private fun disconnectMqttClient() {
        scope.launch {
            try {
                mqttClient?.disconnect()?.get()
            } catch (e: Exception) {
                Log.e("MQTT", "Disconnect error", e)
            } finally {
                mqttClient = null
                isMqttConnected = false
                runOnUiThread {
                    updateConnectionStatusUI()
                    if (!isIpConnected) {
                        resetToDefaultState()
                    }
                    logMessage(">> MQTT Client Disconnected.\n")
                }
            }
        }
    }

    private fun subscribeMqttTopics(profile: Int) {
        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        val tCmd = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_MQTT_TOPIC_CMD, profile), "home/room$profile/command")
            ?: "home/room$profile/command"
        val tState = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_MQTT_TOPIC_STATE, profile), "home/room$profile/state")
            ?: "home/room$profile/state"

        mqttClient?.subscribeWith()?.topicFilter(tCmd)?.callback { publish ->
            val msg = String(publish.payloadAsBytes)
            logMessage("<< [MQTT Cmd] $msg\n")
            parseArduinoFeedback(msg)
        }?.send()

        mqttClient?.subscribeWith()?.topicFilter(tState)?.callback { publish ->
            val msg = String(publish.payloadAsBytes)
            logMessage("<< [MQTT State] $msg\n")
            parseArduinoFeedback(msg)
        }?.send()
    }

    private fun sendCommand(cmd: String) {
        val currentProfile = activeProfile
        scope.launch {
            val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
            val isMqttEnabled = prefs.getBoolean(ConfigActivity.key(ConfigActivity.KEY_MQTT_ENABLED, currentProfile), true)

            if (isIpConnected && webSocket != null) {
                val payload = JSONObject().put("command", cmd).toString()
                webSocket?.send(payload)
                logMessage(">> [D$currentProfile] $cmd (WebSocket IP)\n")
            } else if (isMqttEnabled && isMqttConnected && mqttClient?.state?.isConnected == true) {
                val tCmd = prefs.getString(
                    ConfigActivity.key(ConfigActivity.KEY_MQTT_TOPIC_CMD, currentProfile),
                    "home/room$currentProfile/command"
                ) ?: "home/room$currentProfile/command"

                val mqttPayload = JSONObject().put("command", cmd).toString()
                mqttClient?.publishWith()
                    ?.topic(tCmd)
                    ?.payload(mqttPayload.toByteArray())
                    ?.send()
                logMessage(">> [D$currentProfile] $cmd (MQTT Broadcast)\n")
            } else {
                logMessage(">> [D$currentProfile] $cmd (Failed - Not Connected to ESP Device)\n")
            }
        }
    }

    private fun parseArduinoFeedback(jsonStr: String) {
        try {
            val data = JSONObject(jsonStr)
            for (i in 1..4) {
                val key = "POWER$i"
                if (data.has(key)) {
                    val isOn = data.getString(key) == "ON"
                    relayStates[i - 1] = isOn
                    runOnUiThread { updateUiRelay(i - 1, isOn) }
                }
            }
            if (data.has("Dimmer")) {
                val dimVal = data.getInt("Dimmer")
                lastSentDimmer = dimVal
                runOnUiThread {
                    if (binding.dimmerSeekBar.progress != dimVal) {
                        binding.dimmerSeekBar.progress = dimVal
                        updateDimmerText(dimVal)
                    }
                }
            }
        } catch (_: Exception) {}
    }

    private fun updateUiRelay(idx: Int, isOn: Boolean) {
        val buttons = listOf(binding.btnRelay1, binding.btnRelay2, binding.btnRelay3, binding.btnRelay4)
        val btn = buttons[idx]
        if (isOn) {
            btn.text = getString(R.string.relay_on_label, idx + 1)
            btn.backgroundTintList = ColorStateList.valueOf("#4CAF50".toColorInt())
            btn.setTextColor("#FFFFFF".toColorInt())
        } else {
            btn.text = getString(R.string.relay_off_label, idx + 1)
            btn.backgroundTintList = ColorStateList.valueOf("#6200EE".toColorInt())
            btn.setTextColor("#FFFFFF".toColorInt())
        }
    }

    private fun updateConnectionStatusUI() {
        if (isIpConnected) {
            binding.tvConnectionStatus.text = getString(R.string.status_connected_ip)
            binding.tvConnectionStatus.setTextColor("#2E7D32".toColorInt())
            binding.btnConnectIp.text = getString(R.string.btn_disconnect)
            binding.btnConnectIp.backgroundTintList = ColorStateList.valueOf("#4CAF50".toColorInt())
        } else if (isMqttConnected) {
            binding.tvConnectionStatus.text = getString(R.string.status_connected_mqtt)
            binding.tvConnectionStatus.setTextColor("#2E7D32".toColorInt())
            binding.btnConnectIp.text = getString(R.string.btn_connect_ip)
            binding.btnConnectIp.backgroundTintList = ColorStateList.valueOf("#6200EE".toColorInt())
        } else {
            binding.tvConnectionStatus.text = getString(R.string.status_disconnected)
            binding.tvConnectionStatus.setTextColor("#D32F2F".toColorInt())
            binding.btnConnectIp.text = getString(R.string.btn_connect_ip)
            binding.btnConnectIp.backgroundTintList = ColorStateList.valueOf("#6200EE".toColorInt())
        }
    }

    private fun logMessage(msg: String) {
        runOnUiThread {
            binding.tvConsoleLog.append(msg)
            val innerHeight = binding.tvConsoleLog.layout?.height ?: 0
            if (innerHeight > binding.tvConsoleLog.height) {
                binding.tvConsoleLog.scrollTo(0, innerHeight - binding.tvConsoleLog.height)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        wakeListenGeneration++
        handler.removeCallbacksAndMessages(null)
        networkCallback?.let { cb ->
            try {
                connectivityManager?.unregisterNetworkCallback(cb)
            } catch (_: Exception) {
            }
        }
        networkCallback = null
        destroySpeechRecognizerSafely()
        if (groqVoice.isRecording()) {
            groqVoice.requestStopRecording()
        }
        tts?.stop()
        tts?.shutdown()
        tts = null
        disconnectWebSocket()
        disconnectMqttClient()
    }
}