package com.sasoftwares.homeautomationcontroller

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.content.res.ColorStateList
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.ToneGenerator
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.tts.TextToSpeech
import android.util.Log
import android.view.WindowManager
import android.widget.Button
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.content.edit
import androidx.core.graphics.toColorInt
import com.hivemq.client.mqtt.MqttClient
import com.hivemq.client.mqtt.mqtt5.Mqtt5AsyncClient
import com.sasoftwares.homeautomationcontroller.databinding.ActivityMainBinding
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.lang.ref.WeakReference
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.time.Duration.Companion.milliseconds
import kotlin.time.Duration.Companion.seconds

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    private var mqttClient: Mqtt5AsyncClient? = null
    private var webSocket: WebSocket? = null
    private val okHttpClient = OkHttpClient()
    private val scope = CoroutineScope(Dispatchers.IO)
    private val handler = Handler(Looper.getMainLooper())

    private var connectivityManager: ConnectivityManager? = null
    private var networkCallback: ConnectivityManager.NetworkCallback? = null
    private var isNetworkAvailable = false

    private val relayStates = BooleanArray(4)
    private var lastSentDimmer = 0
    private var isIpConnected = false
    private var isMqttConnected = false
    private var isManualIpConnectAttempt = false
    private var activeProfile = 1 // 1..4

    private val recordAudioPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
            if (isGranted) {
                armWakeWordMode()
            } else {
                BackgroundVoiceService.disarmFromApp(this)
                updateVoiceButtonUI()
                logMessage(">> Microphone permission denied. Wake word unavailable.\n")
                Toast.makeText(
                    this,
                    getString(R.string.voice_permission_required),
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

    companion object {
        private const val KEY_MANUAL_DISCONNECT = "manual_disconnect_flag"
        private const val VOICE_CHANNEL_ID = "home_automation_voice_channel"
        private const val VOICE_NOTIFICATION_ID = 1001
        private const val ACTION_START_VOICE_BG = "com.sasoftwares.homeautomationcontroller.action.START_VOICE_BG"
        private const val ACTION_STOP_VOICE_BG = "com.sasoftwares.homeautomationcontroller.action.STOP_VOICE_BG"
    }

    class BackgroundVoiceService : Service() {
        private val serviceScope = CoroutineScope(Dispatchers.IO)
        private val serviceHandler = Handler(Looper.getMainLooper())
        private val httpClient = OkHttpClient.Builder()
            .connectTimeout(6, TimeUnit.SECONDS)
            .readTimeout(6, TimeUnit.SECONDS)
            .writeTimeout(6, TimeUnit.SECONDS)
            .build()
        private val groqVoice = GroqVoiceController(httpClient)

        private var audioManager: AudioManager? = null
        private var audioFocusRequest: AudioFocusRequest? = null
        private var hasAudioFocus = false
        private var pausedByPriorityApp = false

        private var wakeLock: PowerManager.WakeLock? = null
        private var wifiLock: WifiManager.WifiLock? = null
        private var tts: TextToSpeech? = null
        private var toneGenerator: ToneGenerator? = null
        private var isTtsReady = false

        @Volatile
        private var wakeWordArmed = false

        @Volatile
        private var capturingCommand = false

        @Volatile
        private var isProcessingVoiceCommand = false

        private var audioRecord: AudioRecord? = null
        private var streamJob: Job? = null
        private var commandBuffer: ByteArrayOutputStream? = null
        private var commandStartMs = 0L
        private var lastVoiceMs = 0L
        private var lastWakeCheckMs = 0L

        private val audioFocusChangeListener = AudioManager.OnAudioFocusChangeListener { focusChange ->
            serviceHandler.post {
                when (focusChange) {
                    AudioManager.AUDIOFOCUS_LOSS,
                    AudioManager.AUDIOFOCUS_LOSS_TRANSIENT,
                    AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                        hasAudioFocus = false
                        if (wakeWordArmed || capturingCommand) {
                            pausedByPriorityApp = true
                            capturingCommand = false
                            commandBuffer = null
                            stopContinuousAudioRecordStream()
                            notifyUiState()
                            logToUi(">> Mic yielded to priority app.\n")
                        }
                    }

                    AudioManager.AUDIOFOCUS_GAIN,
                    AudioManager.AUDIOFOCUS_GAIN_TRANSIENT,
                    AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK -> {
                        hasAudioFocus = true
                        if (wakeWordArmed && pausedByPriorityApp && !isPrioritySessionActive()) {
                            pausedByPriorityApp = false
                            logToUi(">> Priority app finished. Resuming wake word listener…\n")
                            startContinuousAudioRecordStream()
                        }
                    }
                }
            }
        }

        companion object {
            private const val SAMPLE_RATE = 16000
            private const val VOICE_RMS_THRESHOLD = 160.0
            private const val SILENCE_END_MS = 1300L
            private const val MAX_COMMAND_MS = 8000L
            private const val WAKE_BURST_END_MS = 320L
            private const val WAKE_MAX_INTERVAL_MS = 1400L
            private const val WAKE_WINDOW_MS = 2400L
            private const val PRE_ROLL_MS = 500L

            @Volatile
            private var instanceRef: WeakReference<BackgroundVoiceService>? = null

            @Volatile
            private var activityRef: WeakReference<MainActivity>? = null

            fun attachActivity(activity: MainActivity) {
                activityRef = WeakReference(activity)
                instanceRef?.get()?.notifyUiState()
            }

            fun detachActivity(activity: MainActivity) {
                if (activityRef?.get() === activity) {
                    activityRef = null
                }
            }

            fun isArmed(): Boolean = instanceRef?.get()?.wakeWordArmed == true

            fun isRecording(): Boolean = instanceRef?.get()?.capturingCommand == true

            fun isProcessing(): Boolean = instanceRef?.get()?.isProcessingVoiceCommand == true

            fun armFromApp(activity: MainActivity) {
                val intent = Intent(activity, BackgroundVoiceService::class.java).apply {
                    action = ACTION_START_VOICE_BG
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    activity.startForegroundService(intent)
                } else {
                    activity.startService(intent)
                }
                serviceHandlerPost {
                    instanceRef?.get()?.armInternal()
                }
            }

            fun disarmFromApp(context: Context) {
                val svc = instanceRef?.get()
                if (svc != null) {
                    svc.disarmInternal()
                } else {
                    val stopIntent = Intent(context, BackgroundVoiceService::class.java).apply {
                        action = ACTION_STOP_VOICE_BG
                    }
                    try {
                        context.startService(stopIntent)
                    } catch (_: Exception) {
                    }
                }
            }

            private fun serviceHandlerPost(block: () -> Unit) {
                val svc = instanceRef?.get()
                if (svc != null) {
                    svc.serviceHandler.post(block)
                } else {
                    Handler(Looper.getMainLooper()).postDelayed(block, 250L)
                }
            }
        }

        override fun onCreate() {
            super.onCreate()
            instanceRef = WeakReference(this)
            audioManager = getSystemService(Context.AUDIO_SERVICE) as? AudioManager

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    VOICE_CHANNEL_ID,
                    getString(R.string.voice_notif_channel_name),
                    NotificationManager.IMPORTANCE_LOW
                )
                val manager = getSystemService(NotificationManager::class.java)
                manager.createNotificationChannel(channel)
            }

            val pm = getSystemService(Context.POWER_SERVICE) as? PowerManager
            wakeLock = pm?.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "HomeAutomationController::WakeWordStreamLock"
            )?.apply {
                setReferenceCounted(false)
            }

            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            @Suppress("DEPRECATION")
            val lockMode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                WifiManager.WIFI_MODE_FULL_LOW_LATENCY
            } else {
                WifiManager.WIFI_MODE_FULL_HIGH_PERF
            }
            wifiLock = wm?.createWifiLock(lockMode, "HomeAutomationController::WakeWordWifiLock")?.apply {
                setReferenceCounted(false)
            }

            toneGenerator = try {
                ToneGenerator(AudioManager.STREAM_NOTIFICATION, ToneGenerator.MAX_VOLUME)
            } catch (e: Exception) {
                Log.w("WAKE_WORD", "ToneGenerator init failed", e)
                null
            }

            tts = TextToSpeech(applicationContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    tts?.language = Locale.US
                    tts?.setSpeechRate(1.05f)
                    isTtsReady = true
                }
            }
        }

        private fun playWakeWordChime() {
            serviceScope.launch(Dispatchers.IO) {
                try {
                    val sampleRate = 22050
                    val note1Ms = 95
                    val gapMs = 35
                    val note2Ms = 155
                    val totalSamples = sampleRate * (note1Ms + gapMs + note2Ms) / 1000
                    val pcm = ShortArray(totalSamples)

                    fun addTone(startSample: Int, durationMs: Int, freqHz: Double, amplitude: Double) {
                        val count = sampleRate * durationMs / 1000
                        val fadeSamples = (sampleRate * 0.006).toInt().coerceAtLeast(1)
                        for (i in 0 until count) {
                            val idx = startSample + i
                            if (idx >= pcm.size) break
                            val env = when {
                                i < fadeSamples -> i.toDouble() / fadeSamples
                                i > count - fadeSamples -> (count - i).toDouble() / fadeSamples
                                else -> 1.0
                            }.coerceIn(0.0, 1.0)
                            val wave = 0.82 * sin(2.0 * Math.PI * freqHz * i / sampleRate) +
                                    0.18 * sin(2.0 * Math.PI * (freqHz * 2.0) * i / sampleRate)
                            val sample = (env * amplitude * wave).coerceIn(-1.0, 1.0)
                            pcm[idx] = (sample * Short.MAX_VALUE).toInt().toShort()
                        }
                    }

                    // Crisp assistant-style ascending fifth (D5 -> A5)
                    addTone(0, note1Ms, 587.33, 0.90)
                    addTone(sampleRate * (note1Ms + gapMs) / 1000, note2Ms, 880.0, 0.92)

                    val track = AudioTrack.Builder()
                        .setAudioAttributes(
                            AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_MEDIA)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                                .build()
                        )
                        .setAudioFormat(
                            AudioFormat.Builder()
                                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                                .setSampleRate(sampleRate)
                                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                                .build()
                        )
                        .setBufferSizeInBytes(pcm.size * 2)
                        .setTransferMode(AudioTrack.MODE_STATIC)
                        .build()

                    track.write(pcm, 0, pcm.size)
                    track.play()
                    delay((note1Ms + gapMs + note2Ms + 80).milliseconds)
                    track.stop()
                    track.release()
                } catch (e: Exception) {
                    Log.w("WAKE_WORD", "Loud wake chime failed, falling back to ToneGenerator", e)
                    serviceHandler.post {
                        try {
                            toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP2, 200)
                        } catch (_: Exception) {
                        }
                    }
                }
            }
        }

        private fun hasRecordAudioPermission(): Boolean {
            return ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        }

        private fun isPrioritySessionActive(): Boolean {
            val am = audioManager ?: return false
            return when (am.mode) {
                AudioManager.MODE_IN_CALL,
                AudioManager.MODE_IN_COMMUNICATION,
                AudioManager.MODE_RINGTONE -> true
                else -> false
            }
        }

        private fun yieldToPriorityAppIfNeeded(): Boolean {
            if (!isPrioritySessionActive()) return false
            pausedByPriorityApp = true
            capturingCommand = false
            commandBuffer = null
            stopContinuousAudioRecordStream()
            abandonAudioFocusSafely()
            notifyUiState()
            logToUi(">> Mic yielded to priority app (active call/session).\n")
            return true
        }

        private fun requestAudioFocusSafely() {
            val am = audioManager ?: return
            if (hasAudioFocus) return

            val granted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val attrs = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
                val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                    .setAudioAttributes(attrs)
                    .setAcceptsDelayedFocusGain(true)
                    .setOnAudioFocusChangeListener(audioFocusChangeListener, serviceHandler)
                    .build()
                audioFocusRequest = req
                am.requestAudioFocus(req) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
            } else {
                @Suppress("DEPRECATION")
                am.requestAudioFocus(
                    audioFocusChangeListener,
                    AudioManager.STREAM_MUSIC,
                    AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK
                ) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
            }
            hasAudioFocus = granted
        }

        private fun abandonAudioFocusSafely() {
            val am = audioManager ?: return
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    audioFocusRequest?.let { am.abandonAudioFocusRequest(it) }
                } else {
                    @Suppress("DEPRECATION")
                    am.abandonAudioFocus(audioFocusChangeListener)
                }
            } catch (_: Exception) {
            } finally {
                audioFocusRequest = null
                hasAudioFocus = false
                pausedByPriorityApp = false
            }
        }

        override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
            if (intent?.action == ACTION_STOP_VOICE_BG) {
                disarmInternal()
                return START_NOT_STICKY
            }

            showForegroundNotification()
            acquireLocksSafely()

            if (intent?.action == ACTION_START_VOICE_BG) {
                armInternal()
            } else if (wakeWordArmed && !yieldToPriorityAppIfNeeded()) {
                startContinuousAudioRecordStream()
            }
            return START_STICKY
        }

        private fun showForegroundNotification() {
            val openAppIntent = Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            }
            val pendingIntent = PendingIntent.getActivity(
                this,
                0,
                openAppIntent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )

            val stopIntent = Intent(this, BackgroundVoiceService::class.java).apply {
                action = ACTION_STOP_VOICE_BG
            }
            val stopPendingIntent = PendingIntent.getService(
                this,
                1,
                stopIntent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )

            val notification: Notification = NotificationCompat.Builder(this, VOICE_CHANNEL_ID)
                .setContentTitle(getString(R.string.voice_notif_title))
                .setContentText(getString(R.string.voice_notif_text))
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentIntent(pendingIntent)
                .addAction(
                    android.R.drawable.ic_menu_close_clear_cancel,
                    getString(R.string.voice_notif_stop),
                    stopPendingIntent
                )
                .setOngoing(true)
                .build()

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(
                    VOICE_NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                )
            } else {
                startForeground(VOICE_NOTIFICATION_ID, notification)
            }
        }

        private fun acquireLocksSafely() {
            try {
                if (wakeLock?.isHeld != true) {
                    wakeLock?.acquire(6 * 60 * 60 * 1000L)
                }
            } catch (e: Exception) {
                Log.w("WAKE_WORD", "Failed to acquire partial wake lock", e)
            }
            try {
                if (wifiLock?.isHeld != true) {
                    wifiLock?.acquire()
                }
            } catch (e: Exception) {
                Log.w("WAKE_WORD", "Failed to acquire wifi lock", e)
            }
        }

        private fun releaseLocksSafely() {
            try {
                if (wakeLock?.isHeld == true) {
                    wakeLock?.release()
                }
            } catch (_: Exception) {
            }
            try {
                if (wifiLock?.isHeld == true) {
                    wifiLock?.release()
                }
            } catch (_: Exception) {
            }
        }

        private fun activeProfile(): Int {
            val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
            return prefs.getInt(ConfigActivity.KEY_ACTIVE_PROFILE, 1).coerceIn(1, 4)
        }

        private fun normalizePhrase(raw: String): String {
            return raw.lowercase()
                .replace(Regex("""[^a-z0-9\s]"""), " ")
                .replace(Regex("""\s+"""), " ")
                .trim()
        }

        private fun getActiveWakeWords(): List<String> {
            val profile = activeProfile()
            val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
            val customRaw = prefs.getString(
                ConfigActivity.key(ConfigActivity.KEY_WAKE_WORD, profile),
                ConfigActivity.DEFAULT_WAKE_WORD
            ).orEmpty()

            val phrases = customRaw.split(",")
                .map { normalizePhrase(it) }
                .filter { it.isNotEmpty() }
                .distinct()

            return phrases.ifEmpty { listOf(normalizePhrase(ConfigActivity.DEFAULT_WAKE_WORD)) }
        }

        private fun getPrimaryWakeWordDisplay(): String {
            val profile = activeProfile()
            val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
            val raw = prefs.getString(
                ConfigActivity.key(ConfigActivity.KEY_WAKE_WORD, profile),
                ConfigActivity.DEFAULT_WAKE_WORD
            ).orEmpty()
            return raw.split(",").map { it.trim() }.firstOrNull { it.isNotEmpty() }
                ?: ConfigActivity.DEFAULT_WAKE_WORD
        }

        private fun containsWakeWord(text: String): Boolean {
            val spoken = normalizePhrase(text)
            if (spoken.isBlank()) return false

            val targets = getActiveWakeWords()
            return targets.any { phrase ->
                val clean = normalizePhrase(phrase)
                if (clean.isEmpty()) return@any false

                if (spoken.contains(clean)) return@any true

                val targetTokens = clean.split(" ").filter { it.isNotEmpty() }
                val spokenTokens = spoken.split(" ").filter { it.isNotEmpty() }

                if (targetTokens.size == 2 && spokenTokens.isNotEmpty()) {
                    val first = targetTokens[0]
                    val second = targetTokens[1]
                    for (i in 0 until spokenTokens.size - 1) {
                        val t1 = spokenTokens[i]
                        val t2 = spokenTokens[i + 1]
                        val firstOk = t1 == first ||
                                t1.startsWith(first.take(2)) ||
                                first.startsWith(t1.take(2)) ||
                                (first == "hey" && (t1 == "a" || t1 == "eh" || t1 == "hay" || t1 == "hi"))
                        val secondOk = t2 == second ||
                                t2.startsWith("hom") ||
                                t2.startsWith(second.take(3)) ||
                                second.startsWith(t2)
                        if (firstOk && secondOk) return@any true
                    }
                    if (spokenTokens.any { it == second || it.startsWith("hom") } && spoken.length <= 14) {
                        return@any true
                    }
                } else if (targetTokens.size >= 2 && spokenTokens.size >= 2) {
                    val first = targetTokens.first()
                    val last = targetTokens.last()
                    for (i in 0 until spokenTokens.size - 1) {
                        val pairFirst = spokenTokens[i]
                        val pairSecond = spokenTokens[i + 1]
                        val firstMatches = pairFirst == first || pairFirst.startsWith(first) || first.startsWith(pairFirst)
                        val secondMatches = pairSecond == last || pairSecond.startsWith(last) || last.startsWith(pairSecond)
                        if (firstMatches && secondMatches) return@any true
                    }
                }
                false
            }
        }

        fun armInternal() {
            if (!hasRecordAudioPermission()) {
                logToUi(">> Microphone permission missing in service.\n")
                return
            }
            showForegroundNotification()
            acquireLocksSafely()
            wakeWordArmed = true
            capturingCommand = false
            commandBuffer = null
            lastWakeCheckMs = System.currentTimeMillis()
            if (yieldToPriorityAppIfNeeded()) {
                return
            }
            pausedByPriorityApp = false
            requestAudioFocusSafely()
            startContinuousAudioRecordStream()
            notifyUiState()
            logToUi(">> Wake word armed. Say \"${getPrimaryWakeWordDisplay()}\" to trigger.\n")
        }

        fun disarmInternal() {
            wakeWordArmed = false
            capturingCommand = false
            pausedByPriorityApp = false
            isProcessingVoiceCommand = false
            commandBuffer = null
            stopContinuousAudioRecordStream()
            abandonAudioFocusSafely()
            releaseLocksSafely()
            notifyUiState()
            logToUi(">> Wake word mode disarmed.\n")
            try {
                stopForeground(STOP_FOREGROUND_REMOVE)
            } catch (_: Exception) {
            }
            stopSelf()
        }

        private fun startContinuousAudioRecordStream() {
            if (!wakeWordArmed || pausedByPriorityApp || yieldToPriorityAppIfNeeded()) {
                return
            }
            if (!hasRecordAudioPermission()) {
                logToUi(">> Microphone permission missing for continuous stream.\n")
                return
            }
            if (audioRecord?.recordingState == AudioRecord.RECORDSTATE_RECORDING && streamJob?.isActive == true) {
                return
            }

            stopContinuousAudioRecordStream()

            val minBuf = AudioRecord.getMinBufferSize(
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )
            if (minBuf <= 0) {
                logToUi(">> AudioRecord unsupported buffer size.\n")
                return
            }

            val recorder = try {
                AudioRecord(
                    MediaRecorder.AudioSource.MIC,
                    SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    minBuf * 2
                )
            } catch (e: SecurityException) {
                Log.e("WAKE_WORD", "SecurityException creating AudioRecord", e)
                logToUi(">> Mic permission error: ${e.localizedMessage}\n")
                return
            } catch (e: Exception) {
                Log.e("WAKE_WORD", "Failed to create AudioRecord", e)
                logToUi(">> Failed to open mic: ${e.localizedMessage}\n")
                return
            }

            if (recorder.state != AudioRecord.STATE_INITIALIZED) {
                recorder.release()
                logToUi(">> AudioRecord failed to initialize.\n")
                return
            }

            try {
                recorder.startRecording()
            } catch (e: SecurityException) {
                Log.e("WAKE_WORD", "SecurityException starting AudioRecord", e)
                logToUi(">> AudioRecord SecurityException: ${e.localizedMessage}\n")
                recorder.release()
                return
            } catch (e: Exception) {
                Log.e("WAKE_WORD", "Failed to startRecording", e)
                logToUi(">> AudioRecord start error: ${e.localizedMessage}\n")
                recorder.release()
                return
            }

            if (recorder.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
                logToUi(">> AudioRecord did not enter RECORDSTATE_RECORDING (state=${recorder.recordingState}).\n")
                recorder.release()
                return
            }

            audioRecord = recorder
            logToUi(">> Mic stream live (16kHz mono).\n")

            val windowBytesMax = (SAMPLE_RATE * 2 * (WAKE_WINDOW_MS / 1000.0)).toInt()
            val preRollBytesMax = (SAMPLE_RATE * 2 * (PRE_ROLL_MS / 1000.0)).toInt()
            val ringBuffer = ArrayDeque<Byte>(windowBytesMax)
            var speechActiveInWindow = false
            var lastSpeechMs = 0L

            streamJob = serviceScope.launch {
                val readBuf = ShortArray(1024)
                val byteBuf = ByteArray(readBuf.size * 2)

                while (isActive && wakeWordArmed && !pausedByPriorityApp) {
                    val count = try {
                        recorder.read(readBuf, 0, readBuf.size)
                    } catch (_: Exception) {
                        break
                    }
                    if (count <= 0) continue

                    var sumSq = 0.0
                    for (i in 0 until count) {
                        val s = readBuf[i].toInt()
                        sumSq += (s * s).toDouble()
                        byteBuf[i * 2] = (s and 0xFF).toByte()
                        byteBuf[i * 2 + 1] = ((s shr 8) and 0xFF).toByte()
                    }
                    val rms = sqrt(sumSq / count)
                    val now = System.currentTimeMillis()

                    if (capturingCommand) {
                        commandBuffer?.write(byteBuf, 0, count * 2)
                        if (rms >= VOICE_RMS_THRESHOLD) {
                            lastVoiceMs = now
                        }
                        val elapsed = now - commandStartMs
                        val silentTooLong = (now - lastVoiceMs) >= SILENCE_END_MS && elapsed > 1200L
                        if (silentTooLong || elapsed >= MAX_COMMAND_MS) {
                            serviceHandler.post { finalizeCommandCapture() }
                        }
                    } else {
                        for (i in 0 until count * 2) {
                            if (ringBuffer.size >= windowBytesMax) {
                                ringBuffer.removeFirst()
                            }
                            ringBuffer.addLast(byteBuf[i])
                        }

                        if (rms >= VOICE_RMS_THRESHOLD) {
                            speechActiveInWindow = true
                            lastSpeechMs = now
                        }

                        val quietAfterSpeech = speechActiveInWindow && (now - lastSpeechMs) >= WAKE_BURST_END_MS
                        val periodicCheck = speechActiveInWindow && (now - lastWakeCheckMs) >= WAKE_MAX_INTERVAL_MS

                        if (!isProcessingVoiceCommand &&
                            (quietAfterSpeech || periodicCheck) &&
                            (now - lastWakeCheckMs) >= 450L &&
                            ringBuffer.size >= (SAMPLE_RATE / 2)
                        ) {
                            lastWakeCheckMs = now
                            speechActiveInWindow = false
                            val samplePcm = ringBuffer.toByteArray()
                            val tailPcm = if (ringBuffer.size > preRollBytesMax) {
                                samplePcm.copyOfRange(samplePcm.size - preRollBytesMax, samplePcm.size)
                            } else {
                                samplePcm
                            }
                            serviceScope.launch {
                                evaluateWakeWordSample(samplePcm, tailPcm)
                            }
                        }
                    }
                }
            }
        }

        private suspend fun evaluateWakeWordSample(windowPcm: ByteArray, preRollPcm: ByteArray) {
            if (!wakeWordArmed || capturingCommand || isProcessingVoiceCommand || pausedByPriorityApp) return
            val profile = activeProfile()
            val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
            val apiKey = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_GROQ_API_KEY, profile), "").orEmpty()
            if (apiKey.isBlank()) {
                Log.w("WAKE_WORD", "API key is blank for profile $profile")
                return
            }

            val wav = pcm16MonoToWav(windowPcm)
            val heard = try {
                groqVoice.transcribeWav(wav, apiKey)
            } catch (e: Exception) {
                Log.w("WAKE_WORD", "Wake check transcription error: ${e.localizedMessage}")
                ""
            }
            if (heard.isBlank()) return

            Log.d("WAKE_WORD", "Wake sample heard: \"$heard\"")
            if (containsWakeWord(heard)) {
                serviceHandler.post {
                    if (wakeWordArmed && !capturingCommand && !isProcessingVoiceCommand && !pausedByPriorityApp) {
                        playWakeWordChime()
                        val now = System.currentTimeMillis()
                        val buf = ByteArrayOutputStream()
                        buf.write(preRollPcm)
                        commandBuffer = buf
                        commandStartMs = now
                        lastVoiceMs = now
                        capturingCommand = true
                        notifyUiState()
                        logToUi(">> Wake word heard (\"$heard\"). Listening for command…\n")
                    }
                }
            }
        }

        @Synchronized
        private fun finalizeCommandCapture() {
            if (!capturingCommand) return
            capturingCommand = false
            val pcmBytes = commandBuffer?.toByteArray() ?: ByteArray(0)
            commandBuffer = null
            notifyUiState()

            if (pcmBytes.size < SAMPLE_RATE / 2) {
                logToUi(">> [Wake Mic] Short/empty command ignored.\n")
                return
            }

            val wavBytes = pcm16MonoToWav(pcmBytes)
            processWavCommand(wavBytes)
        }

        private fun stopContinuousAudioRecordStream() {
            streamJob?.cancel()
            streamJob = null
            val rec = audioRecord
            audioRecord = null
            if (rec != null) {
                try {
                    if (rec.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                        rec.stop()
                    }
                } catch (_: Exception) {
                }
                try {
                    rec.release()
                } catch (_: Exception) {
                }
            }
        }

        private fun pcm16MonoToWav(pcmData: ByteArray): ByteArray {
            val totalAudioLen = pcmData.size
            val totalDataLen = totalAudioLen + 36
            val channels = 1
            val byteRate = SAMPLE_RATE * channels * 2
            val out = ByteArrayOutputStream(totalAudioLen + 44)

            fun writeAscii(s: String) = out.write(s.toByteArray(Charsets.US_ASCII))
            fun writeIntLe(v: Int) {
                out.write(v and 0xFF)
                out.write((v shr 8) and 0xFF)
                out.write((v shr 16) and 0xFF)
                out.write((v shr 24) and 0xFF)
            }
            fun writeShortLe(v: Int) {
                out.write(v and 0xFF)
                out.write((v shr 8) and 0xFF)
            }

            writeAscii("RIFF")
            writeIntLe(totalDataLen)
            writeAscii("WAVE")
            writeAscii("fmt ")
            writeIntLe(16)
            writeShortLe(1)
            writeShortLe(channels)
            writeIntLe(SAMPLE_RATE)
            writeIntLe(byteRate)
            writeShortLe(channels * 2)
            writeShortLe(16)
            writeAscii("data")
            writeIntLe(totalAudioLen)
            out.write(pcmData)
            return out.toByteArray()
        }

        private fun processWavCommand(wavBytes: ByteArray) {
            if (isProcessingVoiceCommand) return
            val profile = activeProfile()
            val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
            val apiKey = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_GROQ_API_KEY, profile), "").orEmpty()
            val modelName = prefs.getString(
                ConfigActivity.key(ConfigActivity.KEY_GROQ_MODEL, profile),
                ConfigActivity.DEFAULT_GROQ_MODEL
            ).orEmpty()

            isProcessingVoiceCommand = true
            notifyUiState()

            serviceScope.launch {
                val tempWav = File(cacheDir, "voice_cmd_${System.currentTimeMillis()}.wav")
                try {
                    withContext(Dispatchers.IO) {
                        FileOutputStream(tempWav).use { it.write(wavBytes) }
                    }
                    val transcript = groqVoice.transcribeWav(wavBytes, apiKey)
                    logToUi(">> [Transcript] ${transcript.ifEmpty { "(empty)" }}\n")
                    if (transcript.isBlank()) {
                        speakShortReply("Could not hear clear speech.")
                        return@launch
                    }

                    val bridge = object : GroqVoiceController.HardwareBridge {
                        override fun sendRawCommand(cmd: String) {
                            sendHardwareCommandFromService(cmd, activeProfile())
                        }

                        override fun setDimmerLevel(level: Int) {
                            val clamped = level.coerceIn(0, 9)
                            activityRef?.get()?.setDimmerFromExternal(clamped)
                            sendHardwareCommandFromService("DIMMER:$clamped", activeProfile())
                        }

                        override fun switchProfile(profile: Int) {
                            val bounded = profile.coerceIn(1, 4)
                            getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
                                .edit { putInt(ConfigActivity.KEY_ACTIVE_PROFILE, bounded) }
                            activityRef?.get()?.switchProfileFromExternal(bounded)
                        }

                        override fun getRelayStates(): BooleanArray =
                            activityRef?.get()?.relayStatesCopy() ?: BooleanArray(4)

                        override fun getDimmerLevel(): Int =
                            activityRef?.get()?.currentDimmerLevel() ?: 0

                        override fun onLog(msg: String) {
                            logToUi(msg)
                        }
                    }

                    val reply = groqVoice.runIntent(transcript, apiKey, modelName, bridge)
                    logToUi(">> [Assistant] $reply\n")
                    speakShortReply(reply)
                } catch (e: Exception) {
                    Log.e("VOICE_CMD", "Voice pipeline error", e)
                    logToUi(">> [Assistant Error] ${e.localizedMessage ?: e.message}\n")
                    speakShortReply("Voice command failed.")
                } finally {
                    withContext(Dispatchers.IO) {
                        try {
                            if (tempWav.exists()) {
                                tempWav.delete()
                            }
                        } catch (_: Exception) {
                        }
                    }
                    isProcessingVoiceCommand = false
                    notifyUiState()
                }
            }
        }

        private fun speakShortReply(text: String) {
            val profile = activeProfile()
            val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
            val enabled = prefs.getBoolean(ConfigActivity.key(ConfigActivity.KEY_TTS_ENABLED, profile), true)
            if (!enabled || !isTtsReady) return

            val cleaned = text.replace(Regex("""[*#]"""), "").replace(Regex("""\s+"""), " ").trim()
            if (cleaned.isEmpty()) return
            val clipped = if (cleaned.length > 140) {
                cleaned.take(140).substringBeforeLast(" ").ifEmpty { cleaned.take(140) } + "."
            } else {
                cleaned
            }
            tts?.speak(clipped, TextToSpeech.QUEUE_FLUSH, null, "voice_reply_${System.currentTimeMillis()}")
        }

        private fun sendHardwareCommandFromService(cmd: String, profile: Int) {
            acquireLocksSafely()
            val act = activityRef?.get()
            if (act != null && act.isIpConnected) {
                act.sendCommandFromExternal(cmd)
                return
            }

            serviceScope.launch {
                val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
                val ip = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_IP, profile), "")?.trim().orEmpty()
                val wsUser = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_USER, profile), "admin")?.trim() ?: "admin"
                val wsPass = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_PASS, profile), "admin1234S")?.trim() ?: "admin1234S"

                if (ip.isNotEmpty() && sendOverWebSocketOnce(ip, wsUser, wsPass, cmd, profile)) {
                    return@launch
                }

                if (!sendOverMqttOnce(prefs, cmd, profile)) {
                    delay(800.milliseconds)
                    sendOverMqttOnce(prefs, cmd, profile)
                }
            }
        }

        private suspend fun sendOverWebSocketOnce(
            ip: String,
            user: String,
            pass: String,
            cmd: String,
            profile: Int
        ): Boolean {
            val resultDeferred = CompletableDeferred<Boolean>()
            var socket: WebSocket? = null

            val request = Request.Builder().url("ws://$ip:81/").build()
            socket = httpClient.newWebSocket(request, object : WebSocketListener() {
                override fun onOpen(webSocket: WebSocket, response: Response) {
                    try {
                        val authPayload = JSONObject().apply {
                            put("auth", JSONObject().put("user", user).put("pass", pass))
                        }.toString()
                        webSocket.send(authPayload)
                        val cmdPayload = JSONObject().put("command", cmd).toString()
                        val sentOk = webSocket.send(cmdPayload)
                        if (!resultDeferred.isCompleted) {
                            resultDeferred.complete(sentOk)
                        }
                    } catch (e: Exception) {
                        Log.w("BG_WS", "WS send error", e)
                        if (!resultDeferred.isCompleted) {
                            resultDeferred.complete(false)
                        }
                    } finally {
                        serviceHandler.postDelayed({
                            try {
                                webSocket.close(1000, "Done")
                            } catch (_: Exception) {
                            }
                        }, 300L)
                    }
                }

                override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                    Log.w("BG_WS", "WS failed on lock/bg: ${t.localizedMessage}")
                    if (!resultDeferred.isCompleted) {
                        resultDeferred.complete(false)
                    }
                }
            })

            val sentOk = withTimeoutOrNull(4.seconds) {
                resultDeferred.await()
            } ?: false

            if (!sentOk) {
                try {
                    socket.cancel()
                } catch (_: Exception) {
                }
            } else {
                logToUi(">> [D$profile] $cmd (Lock/BG WebSocket)\n")
            }
            return sentOk
        }

        private suspend fun sendOverMqttOnce(
            prefs: android.content.SharedPreferences,
            cmd: String,
            profile: Int
        ): Boolean {
            val mqttEnabled = prefs.getBoolean(ConfigActivity.key(ConfigActivity.KEY_MQTT_ENABLED, profile), true)
            if (!mqttEnabled) {
                logToUi(">> [D$profile] $cmd (Failed - MQTT disabled & local IP unreachable)\n")
                return true
            }
            val server = prefs.getString(
                ConfigActivity.key(ConfigActivity.KEY_MQTT_SERVER, profile),
                "i11b0026.ala.eu-central-1.emqxsl.com"
            ) ?: "i11b0026.ala.eu-central-1.emqxsl.com"
            val port = prefs.getInt(ConfigActivity.key(ConfigActivity.KEY_MQTT_PORT, profile), 8883)
            val user = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_MQTT_USER, profile), "admin") ?: "admin"
            val pass = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_MQTT_PASS, profile), "admin1234S") ?: "admin1234S"
            val tCmd = prefs.getString(
                ConfigActivity.key(ConfigActivity.KEY_MQTT_TOPIC_CMD, profile),
                "home/room$profile/command"
            ) ?: "home/room$profile/command"

            val client = MqttClient.builder()
                .useMqttVersion5()
                .serverHost(server)
                .serverPort(port)
                .sslWithDefaultConfig()
                .buildAsync()

            val publishDone = CompletableDeferred<Boolean>()
            client.connectWith()
                .simpleAuth()
                .username(user)
                .password(pass.toByteArray())
                .applySimpleAuth()
                .send()
                .whenComplete { _, connectErr ->
                    if (connectErr != null) {
                        Log.e("BG_MQTT", "Failed lock/bg connect for $cmd", connectErr)
                        logToUi(">> [D$profile] $cmd (Lock/BG MQTT Error: ${connectErr.localizedMessage})\n")
                        if (!publishDone.isCompleted) publishDone.complete(false)
                        return@whenComplete
                    }

                    val payload = JSONObject().put("command", cmd).toString()
                    client.publishWith()
                        .topic(tCmd)
                        .payload(payload.toByteArray())
                        .send()
                        .whenComplete { _, pubErr ->
                            if (pubErr != null) {
                                Log.e("BG_MQTT", "Failed lock/bg publish $cmd", pubErr)
                                logToUi(">> [D$profile] $cmd (Lock/BG MQTT Error: ${pubErr.localizedMessage})\n")
                                if (!publishDone.isCompleted) publishDone.complete(false)
                            } else {
                                logToUi(">> [D$profile] $cmd (Lock/BG MQTT)\n")
                                if (!publishDone.isCompleted) publishDone.complete(true)
                            }
                            client.disconnect()
                        }
                }

            val ok = withTimeoutOrNull(8.seconds) {
                publishDone.await()
            } ?: false

            if (!ok) {
                client.disconnect()
            }
            return ok
        }

        private fun logToUi(msg: String) {
            activityRef?.get()?.logMessage(msg)
        }

        private fun notifyUiState() {
            activityRef?.get()?.runOnUiThread {
                activityRef?.get()?.updateVoiceButtonUI()
            }
        }

        override fun onDestroy() {
            wakeWordArmed = false
            capturingCommand = false
            pausedByPriorityApp = false
            isProcessingVoiceCommand = false
            commandBuffer = null
            stopContinuousAudioRecordStream()
            abandonAudioFocusSafely()
            releaseLocksSafely()
            try {
                toneGenerator?.release()
            } catch (_: Exception) {
            }
            toneGenerator = null
            tts?.stop()
            tts?.shutdown()
            tts = null
            if (instanceRef?.get() === this) {
                instanceRef = null
            }
            super.onDestroy()
        }

        override fun onBind(intent: Intent?): IBinder? = null
    }

    private fun relayStatesCopy(): BooleanArray = relayStates.copyOf()
    private fun currentDimmerLevel(): Int = binding.dimmerSeekBar.progress

    private fun sendCommandFromExternal(cmd: String) {
        sendCommand(cmd)
    }

    private fun setDimmerFromExternal(clamped: Int) {
        runOnUiThread {
            binding.dimmerSeekBar.progress = clamped
            updateDimmerText(clamped)
        }
        lastSentDimmer = -1
        sendDimmerCommand(clamped)
    }

    private fun switchProfileFromExternal(profileNum: Int) {
        runOnUiThread { switchToProfile(profileNum, forceConnect = true) }
    }

    private fun keepScreenAwake() {
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        keepScreenAwake()
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
        }

        registerNetworkMonitor()

        activeProfile = getSavedActiveProfile()
        setupControls()
        updateActiveProfileUI()
        resetToDefaultState()
        updateVoiceButtonUI()

        autoConnectWebSocket()
    }

    private fun registerNetworkMonitor() {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return
        connectivityManager = cm
        isNetworkAvailable = checkCurrentNetworkState(cm)

        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                runOnUiThread {
                    val wasOffline = !isNetworkAvailable
                    isNetworkAvailable = checkCurrentNetworkState(cm)
                    if (wasOffline) {
                        logMessage(">> Internet/network restored [Device: $activeProfile]. Reviving connections…\n")
                    }
                    reviveConnectionsIfNeeded()
                }
            }

            override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) {
                val hasInternet = networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                        networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
                runOnUiThread {
                    val wasOffline = !isNetworkAvailable
                    isNetworkAvailable = hasInternet || checkCurrentNetworkState(cm)
                    if (wasOffline && isNetworkAvailable) {
                        logMessage(">> Network validated [Device: $activeProfile]. Reviving connections…\n")
                        reviveConnectionsIfNeeded()
                    }
                }
            }

            override fun onLost(network: Network) {
                runOnUiThread {
                    isNetworkAvailable = checkCurrentNetworkState(cm)
                    if (!isNetworkAvailable) {
                        logMessage(">> Network/internet dropped! Cleaning up active sockets…\n")
                        handleNetworkLost()
                    }
                }
            }
        }

        networkCallback = callback
        try {
            cm.registerDefaultNetworkCallback(callback)
        } catch (e: Exception) {
            Log.e("NET_MON", "Failed to register network callback", e)
        }
    }

    private fun checkCurrentNetworkState(cm: ConnectivityManager): Boolean {
        return try {
            val activeNet = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(activeNet) ?: return false
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } catch (_: Exception) {
            false
        }
    }

    private fun handleNetworkLost() {
        isManualIpConnectAttempt = false
        webSocket?.cancel()
        webSocket = null
        isIpConnected = false

        if (isMqttConnected || mqttClient != null) {
            disconnectMqttClient()
        }

        updateConnectionStatusUI()
        resetToDefaultState()
    }

    private fun reviveConnectionsIfNeeded() {
        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        val isManualDisconnect = prefs.getBoolean(ConfigActivity.key(KEY_MANUAL_DISCONNECT, activeProfile), false)

        if (!isIpConnected && !isMqttConnected && !isManualDisconnect) {
            autoConnectWebSocket()
        } else {
            checkAndHandleMqttState()
        }
    }

    override fun onStart() {
        super.onStart()
        keepScreenAwake()
        BackgroundVoiceService.attachActivity(this)
        updateVoiceButtonUI()
    }

    override fun onStop() {
        super.onStop()
        BackgroundVoiceService.detachActivity(this)
    }

    override fun onResume() {
        super.onResume()
        keepScreenAwake()
        BackgroundVoiceService.attachActivity(this)
        val cm = connectivityManager
        if (cm != null) {
            isNetworkAvailable = checkCurrentNetworkState(cm)
        }

        val latestProfile = getSavedActiveProfile()
        if (latestProfile != activeProfile) {
            switchToProfile(latestProfile, forceConnect = false)
            return
        }

        updateActiveProfileUI()
        updateConnectionStatusUI()
        updateVoiceButtonUI()

        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        val isManualDisconnect = prefs.getBoolean(ConfigActivity.key(KEY_MANUAL_DISCONNECT, activeProfile), false)

        if (!isIpConnected && !isMqttConnected && !isManualDisconnect) {
            logMessage(">> App resumed [Device: $activeProfile]. Reviving connection…\n")
            autoConnectWebSocket()
        } else {
            checkAndHandleMqttState()
        }
    }

    private fun getSavedActiveProfile(): Int {
        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getInt(ConfigActivity.KEY_ACTIVE_PROFILE, 1).coerceIn(1, 4)
    }

    private fun setSavedActiveProfile(profile: Int) {
        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit { putInt(ConfigActivity.KEY_ACTIVE_PROFILE, profile.coerceIn(1, 4)) }
    }

    private fun switchToProfile(profile: Int, forceConnect: Boolean) {
        activeProfile = profile.coerceIn(1, 4)
        setSavedActiveProfile(activeProfile)
        if (forceConnect) {
            setManualDisconnectFlag(false)
        }

        updateActiveProfileUI()
        resetToDefaultState()
        logMessage(">> Switched to Device: $activeProfile.\n")

        isManualIpConnectAttempt = false
        webSocket?.cancel()
        webSocket = null
        isIpConnected = false

        if (isMqttConnected || mqttClient != null) {
            disconnectMqttClient()
        }

        updateConnectionStatusUI()
        autoConnectWebSocket()
    }

    private fun updateActiveProfileUI() {
        binding.tvActiveConfig.text = getString(R.string.active_config_format, activeProfile)
        val buttons = listOf(
            binding.btnSelectConfig1,
            binding.btnSelectConfig2,
            binding.btnSelectConfig3,
            binding.btnSelectConfig4
        )
        buttons.forEachIndexed { index, button ->
            val profileNum = index + 1
            val isSelected = profileNum == activeProfile
            val colorHex = if (isSelected) "#2E7D32" else "#6200EE"
            button.backgroundTintList = ColorStateList.valueOf(colorHex.toColorInt())
            button.setTextColor("#FFFFFF".toColorInt())
        }
    }

    private fun updateVoiceButtonUI() {
        when {
            BackgroundVoiceService.isRecording() -> {
                binding.btnVoiceCommand.text = getString(R.string.btn_voice_listening)
                binding.btnVoiceCommand.backgroundTintList = ColorStateList.valueOf("#2E7D32".toColorInt())
                binding.btnVoiceCommand.isEnabled = true
            }
            BackgroundVoiceService.isProcessing() -> {
                binding.btnVoiceCommand.text = getString(R.string.btn_voice_processing)
                binding.btnVoiceCommand.backgroundTintList = ColorStateList.valueOf("#1565C0".toColorInt())
                binding.btnVoiceCommand.isEnabled = false
            }
            BackgroundVoiceService.isArmed() -> {
                binding.btnVoiceCommand.text = getString(R.string.btn_voice_wake_armed)
                binding.btnVoiceCommand.backgroundTintList = ColorStateList.valueOf("#1565C0".toColorInt())
                binding.btnVoiceCommand.isEnabled = true
            }
            else -> {
                binding.btnVoiceCommand.text = getString(R.string.btn_voice_command)
                binding.btnVoiceCommand.backgroundTintList = ColorStateList.valueOf("#00796B".toColorInt())
                binding.btnVoiceCommand.isEnabled = true
            }
        }
        binding.btnVoiceCommand.setTextColor("#FFFFFF".toColorInt())
    }

    private fun setupControls() {
        val profileButtons = listOf(
            binding.btnSelectConfig1,
            binding.btnSelectConfig2,
            binding.btnSelectConfig3,
            binding.btnSelectConfig4
        )
        profileButtons.forEachIndexed { index, button ->
            val targetProfile = index + 1
            button.setOnClickListener {
                if (targetProfile == activeProfile && (isIpConnected || isMqttConnected)) {
                    return@setOnClickListener
                }
                switchToProfile(targetProfile, forceConnect = true)
            }
        }

        val relayButtons = listOf(binding.btnRelay1, binding.btnRelay2, binding.btnRelay3, binding.btnRelay4)

        relayButtons.forEachIndexed { index, button ->
            button.setOnClickListener {
                if (!isIpConnected && !isMqttConnected) {
                    logMessage(">> Action blocked: Not connected to ESP device.\n")
                    return@setOnClickListener
                }
                val targetState = !relayStates[index]
                val stateStr = if (targetState) "ON" else "OFF"
                sendCommand("POWER${index + 1} $stateStr")
            }
        }

        binding.dimmerSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    updateDimmerText(progress)
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                if (!isIpConnected && !isMqttConnected) {
                    logMessage(">> Action blocked: Not connected to ESP device.\n")
                    return
                }
                seekBar?.let {
                    updateDimmerText(it.progress)
                    sendDimmerCommand(it.progress)
                }
            }
        })

        setupButtonTapEffect(binding.btnDimmerMin) { sendDimmerCommand(0) }
        setupButtonTapEffect(binding.btnDimmerMax) { sendDimmerCommand(9) }
        setupButtonTapEffect(binding.btnDimmerMinus) {
            val newProg = maxOf(0, binding.dimmerSeekBar.progress - 1)
            sendDimmerCommand(newProg)
        }
        setupButtonTapEffect(binding.btnDimmerPlus) {
            val newProg = minOf(9, binding.dimmerSeekBar.progress + 1)
            sendDimmerCommand(newProg)
        }

        setupButtonTapEffect(binding.btnAllOn) { sendCommand("ALL_ON") }
        setupButtonTapEffect(binding.btnAllOff) { sendCommand("ALL_OFF") }
        setupButtonTapEffect(binding.btnGetStatus) { sendCommand("STATUS") }

        binding.btnConfig.backgroundTintList = ColorStateList.valueOf("#6200EE".toColorInt())
        binding.btnConfig.setTextColor("#FFFFFF".toColorInt())
        binding.btnConfig.setOnClickListener {
            startActivity(Intent(this, ConfigActivity::class.java))
        }

        binding.btnConnectIp.setOnClickListener {
            if (!isIpConnected) {
                clearManualDisconnectFlag()
                connectWebSocket(manualConnect = true)
            } else {
                setManualDisconnectFlag(true)
                disconnectWebSocket()
            }
        }

        binding.btnVoiceCommand.setOnClickListener {
            if (BackgroundVoiceService.isProcessing()) return@setOnClickListener

            if (BackgroundVoiceService.isArmed()) {
                disarmWakeWordMode()
                return@setOnClickListener
            }

            val hasPermission = ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
            if (hasPermission) {
                armWakeWordMode()
            } else {
                recordAudioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
        }
    }

    private fun armWakeWordMode() {
        keepScreenAwake()
        BackgroundVoiceService.armFromApp(this)
        handler.postDelayed({ updateVoiceButtonUI() }, 150L)
    }

    private fun disarmWakeWordMode() {
        BackgroundVoiceService.disarmFromApp(this)
        updateVoiceButtonUI()
    }

    private fun resetToDefaultState() {
        val relayButtons = listOf(binding.btnRelay1, binding.btnRelay2, binding.btnRelay3, binding.btnRelay4)
        relayButtons.forEachIndexed { index, button ->
            relayStates[index] = false
            button.text = getString(R.string.relay_off_label, index + 1)
            button.backgroundTintList = ColorStateList.valueOf("#6200EE".toColorInt())
            button.setTextColor("#FFFFFF".toColorInt())
        }
        lastSentDimmer = 0
        binding.dimmerSeekBar.progress = 0
        updateDimmerText(0)
    }

    private fun setupButtonTapEffect(button: Button, action: () -> Unit) {
        button.backgroundTintList = ColorStateList.valueOf("#6200EE".toColorInt())
        button.setTextColor("#FFFFFF".toColorInt())
        button.setOnClickListener {
            if (!isIpConnected && !isMqttConnected) {
                logMessage(">> Action blocked: Not connected to ESP device.\n")
                return@setOnClickListener
            }
            button.backgroundTintList = ColorStateList.valueOf("#4CAF50".toColorInt())
            action()
            handler.postDelayed({
                button.backgroundTintList = ColorStateList.valueOf("#6200EE".toColorInt())
            }, 250)
        }
    }

    private fun setManualDisconnectFlag(disconnected: Boolean) {
        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit { putBoolean(ConfigActivity.key(KEY_MANUAL_DISCONNECT, activeProfile), disconnected) }
    }

    private fun clearManualDisconnectFlag() {
        setManualDisconnectFlag(false)
    }

    private fun updateDimmerText(progress: Int) {
        binding.tvDimmerValue.text = getString(R.string.dimmer_level_text, progress)
    }

    private fun sendDimmerCommand(valInt: Int) {
        if (valInt != lastSentDimmer) {
            lastSentDimmer = valInt
            sendCommand("DIMMER:$valInt")
        }
    }

    private fun autoConnectWebSocket() {
        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        val ip = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_IP, activeProfile), "")?.trim()
        val isManualDisconnect = prefs.getBoolean(ConfigActivity.key(KEY_MANUAL_DISCONNECT, activeProfile), false)

        if (!ip.isNullOrEmpty() && !isManualDisconnect) {
            connectWebSocket(manualConnect = false)
        } else {
            logMessage(">> Auto-connect IP skipped [Device: $activeProfile]. Falling back to MQTT check…\n")
            checkAndHandleMqttState()
        }
    }

    private fun isAuthFailureMessage(rawText: String): Boolean {
        val lower = rawText.lowercase()
        if (
            lower.contains("unauthorized") ||
            lower.contains("wrong credentials") ||
            lower.contains("wrong password") ||
            lower.contains("invalid credentials") ||
            lower.contains("invalid password") ||
            lower.contains("auth failed") ||
            lower.contains("authentication failed") ||
            lower.contains("access denied") ||
            lower.contains("forbidden")
        ) {
            return true
        }
        return try {
            val json = JSONObject(rawText)
            val authVal = json.optString("auth", "").lowercase()
            val statusVal = json.optString("status", "").lowercase()
            val errVal = json.optString("error", "").lowercase()
            val codeVal = json.optInt("code", -1)
            authVal in listOf("fail", "failed", "unauthorized", "error", "denied") ||
                    statusVal in listOf("unauthorized", "auth_failed", "forbidden") ||
                    errVal.contains("auth") ||
                    errVal.contains("unauth") ||
                    errVal.contains("credential") ||
                    codeVal == 401 || codeVal == 403
        } catch (_: Exception) {
            false
        }
    }

    private fun abortIpConnectionOnUnauthorized(reasonText: String = "Unauthorized / wrong credentials") {
        if (!isManualIpConnectAttempt && !isIpConnected && webSocket == null) return
        isManualIpConnectAttempt = false
        isIpConnected = false
        val socketToClose = webSocket
        webSocket = null
        try {
            socketToClose?.close(1008, reasonText.take(120))
        } catch (_: Exception) {
            try {
                socketToClose?.cancel()
            } catch (_: Exception) {
            }
        }
        runOnUiThread {
            updateConnectionStatusUI()
            resetToDefaultState()
            logMessage(">> [Device: $activeProfile] $reasonText. Disconnected IP.\n")
        }
    }

    private fun connectWebSocket(manualConnect: Boolean = true) {
        isManualIpConnectAttempt = manualConnect
        webSocket?.cancel()
        webSocket = null

        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        val ip = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_IP, activeProfile), "192.168.29.110")?.trim()
        val user = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_USER, activeProfile), "admin")?.trim()
        val pass = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_PASS, activeProfile), "admin1234S")?.trim()

        if (ip.isNullOrEmpty()) {
            isManualIpConnectAttempt = false
            logMessage(">> Error: No IP configured in Device: $activeProfile.\n")
            checkAndHandleMqttState()
            return
        }

        if (isMqttConnected || mqttClient != null) {
            logMessage(">> IP connection starting. Disconnecting active MQTT client…\n")
            disconnectMqttClient()
        }

        val request = Request.Builder().url("ws://$ip:81/").build()
        logMessage(">> [Device: $activeProfile] Connecting to WebSocket ws://$ip:81/…\n")

        webSocket = okHttpClient.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                isIpConnected = true
                runOnUiThread {
                    updateConnectionStatusUI()
                    logMessage(">> Connected to ESP WebSocket. Authenticating…\n")
                }

                val authPayload = JSONObject().apply {
                    put("auth", JSONObject().put("user", user).put("pass", pass))
                }.toString()
                webSocket.send(authPayload)

                sendCommand("STATUS")
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                logMessage("<< $text\n")
                if (isManualIpConnectAttempt && isAuthFailureMessage(text)) {
                    abortIpConnectionOnUnauthorized("Unauthorized / wrong credentials")
                    return
                }
                parseArduinoFeedback(text)
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                val wasManualConnect = isManualIpConnectAttempt
                isManualIpConnectAttempt = false
                isIpConnected = false
                val httpCode = response?.code ?: -1
                val msg = t.localizedMessage.orEmpty()
                val isUnauth = httpCode == 401 || httpCode == 403 ||
                        msg.contains("401") || msg.contains("403") || isAuthFailureMessage(msg)

                runOnUiThread {
                    updateConnectionStatusUI()
                    resetToDefaultState()
                    if (wasManualConnect && isUnauth) {
                        logMessage(">> [Device: $activeProfile] Unauthorized / wrong credentials. Disconnected IP.\n")
                        return@runOnUiThread
                    }
                    logMessage(">> WebSocket Error: ${t.localizedMessage}\n")
                    checkAndHandleMqttState()
                }
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                val wasManualConnect = isManualIpConnectAttempt
                isManualIpConnectAttempt = false
                isIpConnected = false
                val isUnauthClose = code == 1008 || code == 4001 || code == 4003 || isAuthFailureMessage(reason)

                runOnUiThread {
                    updateConnectionStatusUI()
                    resetToDefaultState()
                    if (wasManualConnect && isUnauthClose) {
                        logMessage(">> [Device: $activeProfile] Unauthorized / wrong credentials ($reason). Disconnected IP.\n")
                        return@runOnUiThread
                    }
                    logMessage(">> IP WebSocket Disconnected.\n")
                    checkAndHandleMqttState()
                }
            }
        })
    }

    private fun disconnectWebSocket() {
        isManualIpConnectAttempt = false
        webSocket?.close(1000, "User disconnected")
        webSocket = null
        isIpConnected = false
        updateConnectionStatusUI()
        resetToDefaultState()
        logMessage(">> IP WebSocket Disconnected manually.\n")

        checkAndHandleMqttState()
    }

    private fun checkAndHandleMqttState() {
        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        val isMqttEnabled = prefs.getBoolean(ConfigActivity.key(ConfigActivity.KEY_MQTT_ENABLED, activeProfile), true)

        if (isMqttEnabled) {
            if (!isIpConnected && !isMqttConnected && (mqttClient == null || mqttClient?.state?.isConnected != true)) {
                initMqttClient()
            }
        } else {
            if (isMqttConnected || mqttClient != null) {
                disconnectMqttClient()
                logMessage(">> MQTT disabled in Device: $activeProfile. Disconnecting client.\n")
            }
        }
    }

    private fun initMqttClient() {
        val targetProfile = activeProfile
        scope.launch {
            val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
            val isMqttEnabled = prefs.getBoolean(ConfigActivity.key(ConfigActivity.KEY_MQTT_ENABLED, targetProfile), true)

            if (!isMqttEnabled || isIpConnected || targetProfile != activeProfile) {
                logMessage(">> MQTT connection skipped (Disabled, IP connected, or device changed).\n")
                return@launch
            }

            try {
                val server = prefs.getString(
                    ConfigActivity.key(ConfigActivity.KEY_MQTT_SERVER, targetProfile),
                    "i11b0026.ala.eu-central-1.emqxsl.com"
                ) ?: "i11b0026.ala.eu-central-1.emqxsl.com"
                val port = prefs.getInt(ConfigActivity.key(ConfigActivity.KEY_MQTT_PORT, targetProfile), 8883)
                val user = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_MQTT_USER, targetProfile), "admin") ?: "admin"
                val pass = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_MQTT_PASS, targetProfile), "admin1234S") ?: "admin1234S"

                logMessage(">> [Device: $targetProfile] Connecting to MQTT Broker…\n")

                mqttClient = MqttClient.builder()
                    .useMqttVersion5()
                    .serverHost(server)
                    .serverPort(port)
                    .sslWithDefaultConfig()
                    .buildAsync()

                mqttClient?.connectWith()
                    ?.simpleAuth()
                    ?.username(user)
                    ?.password(pass.toByteArray())
                    ?.applySimpleAuth()
                    ?.send()
                    ?.whenComplete { _, throwable ->
                        runOnUiThread {
                            val stillEnabled = prefs.getBoolean(
                                ConfigActivity.key(ConfigActivity.KEY_MQTT_ENABLED, targetProfile),
                                true
                            )
                            if (!stillEnabled || isIpConnected || targetProfile != activeProfile) {
                                disconnectMqttClient()
                                return@runOnUiThread
                            }

                            if (throwable == null) {
                                isMqttConnected = true
                                updateConnectionStatusUI()
                                logMessage(">> [Device: $targetProfile] Connected to MQTT Broker successfully!\n")
                                subscribeMqttTopics(targetProfile)
                                sendCommand("STATUS")
                            } else {
                                isMqttConnected = false
                                updateConnectionStatusUI()
                                resetToDefaultState()
                                logMessage(">> MQTT Connection failed: ${throwable.localizedMessage}\n")
                            }
                        }
                    }
            } catch (e: Exception) {
                Log.e("MQTT", "Connection Error", e)
                isMqttConnected = false
                runOnUiThread {
                    updateConnectionStatusUI()
                    resetToDefaultState()
                }
            }
        }
    }

    private fun disconnectMqttClient() {
        val currentClient = mqttClient
        mqttClient = null
        isMqttConnected = false
        updateConnectionStatusUI()
        if (!isIpConnected) {
            resetToDefaultState()
        }
        logMessage(">> MQTT Client Disconnected.\n")

        if (currentClient != null) {
            scope.launch {
                val done = CompletableDeferred<Unit>()
                currentClient.disconnect().handle { _, throwable ->
                    if (throwable != null) {
                        Log.e("MQTT", "Disconnect error", throwable)
                    }
                    done.complete(Unit)
                }
                withTimeoutOrNull(4.seconds) {
                    done.await()
                }
            }
        }
    }

    private fun subscribeMqttTopics(profile: Int) {
        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        val tCmd = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_MQTT_TOPIC_CMD, profile), "home/room$profile/command")
            ?: "home/room$profile/command"
        val tState = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_MQTT_TOPIC_STATE, profile), "home/room$profile/state")
            ?: "home/room$profile/state"

        mqttClient?.subscribeWith()?.topicFilter(tCmd)?.callback { publish ->
            val msg = String(publish.payloadAsBytes)
            logMessage("<< [MQTT Cmd] $msg\n")
            parseArduinoFeedback(msg)
        }?.send()

        mqttClient?.subscribeWith()?.topicFilter(tState)?.callback { publish ->
            val msg = String(publish.payloadAsBytes)
            logMessage("<< [MQTT State] $msg\n")
            parseArduinoFeedback(msg)
        }?.send()
    }

    private fun sendCommand(cmd: String) {
        val currentProfile = activeProfile
        scope.launch {
            val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
            val isMqttEnabled = prefs.getBoolean(ConfigActivity.key(ConfigActivity.KEY_MQTT_ENABLED, currentProfile), true)

            if (isIpConnected && webSocket != null) {
                val payload = JSONObject().put("command", cmd).toString()
                webSocket?.send(payload)
                logMessage(">> [D$currentProfile] $cmd (WebSocket IP)\n")
            } else if (isMqttEnabled && isMqttConnected && mqttClient?.state?.isConnected == true) {
                val tCmd = prefs.getString(
                    ConfigActivity.key(ConfigActivity.KEY_MQTT_TOPIC_CMD, currentProfile),
                    "home/room$currentProfile/command"
                ) ?: "home/room$currentProfile/command"

                val mqttPayload = JSONObject().put("command", cmd).toString()
                mqttClient?.publishWith()
                    ?.topic(tCmd)
                    ?.payload(mqttPayload.toByteArray())
                    ?.send()
                logMessage(">> [D$currentProfile] $cmd (MQTT Broadcast)\n")
            } else {
                logMessage(">> [D$currentProfile] $cmd (Failed - Not Connected to ESP Device)\n")
            }
        }
    }

    private fun parseArduinoFeedback(jsonStr: String) {
        try {
            val data = JSONObject(jsonStr)
            for (i in 1..4) {
                val key = "POWER$i"
                if (data.has(key)) {
                    val isOn = data.getString(key) == "ON"
                    relayStates[i - 1] = isOn
                    runOnUiThread { updateUiRelay(i - 1, isOn) }
                }
            }
            if (data.has("Dimmer")) {
                val dimVal = data.getInt("Dimmer")
                lastSentDimmer = dimVal
                runOnUiThread {
                    if (binding.dimmerSeekBar.progress != dimVal) {
                        binding.dimmerSeekBar.progress = dimVal
                        updateDimmerText(dimVal)
                    }
                }
            }
        } catch (_: Exception) {}
    }

    private fun updateUiRelay(idx: Int, isOn: Boolean) {
        val buttons = listOf(binding.btnRelay1, binding.btnRelay2, binding.btnRelay3, binding.btnRelay4)
        val btn = buttons[idx]
        if (isOn) {
            btn.text = getString(R.string.relay_on_label, idx + 1)
            btn.backgroundTintList = ColorStateList.valueOf("#4CAF50".toColorInt())
            btn.setTextColor("#FFFFFF".toColorInt())
        } else {
            btn.text = getString(R.string.relay_off_label, idx + 1)
            btn.backgroundTintList = ColorStateList.valueOf("#6200EE".toColorInt())
            btn.setTextColor("#FFFFFF".toColorInt())
        }
    }

    private fun updateConnectionStatusUI() {
        if (isIpConnected) {
            binding.tvConnectionStatus.text = getString(R.string.status_connected_ip)
            binding.tvConnectionStatus.setTextColor("#2E7D32".toColorInt())
            binding.btnConnectIp.text = getString(R.string.btn_disconnect)
            binding.btnConnectIp.backgroundTintList = ColorStateList.valueOf("#4CAF50".toColorInt())
        } else if (isMqttConnected) {
            binding.tvConnectionStatus.text = getString(R.string.status_connected_mqtt)
            binding.tvConnectionStatus.setTextColor("#2E7D32".toColorInt())
            binding.btnConnectIp.text = getString(R.string.btn_connect_ip)
            binding.btnConnectIp.backgroundTintList = ColorStateList.valueOf("#6200EE".toColorInt())
        } else {
            binding.tvConnectionStatus.text = getString(R.string.status_disconnected)
            binding.tvConnectionStatus.setTextColor("#D32F2F".toColorInt())
            binding.btnConnectIp.text = getString(R.string.btn_connect_ip)
            binding.btnConnectIp.backgroundTintList = ColorStateList.valueOf("#6200EE".toColorInt())
        }
    }

    private fun logMessage(msg: String) {
        runOnUiThread {
            binding.tvConsoleLog.append(msg)
            val innerHeight = binding.tvConsoleLog.layout?.height ?: 0
            if (innerHeight > binding.tvConsoleLog.height) {
                binding.tvConsoleLog.scrollTo(0, innerHeight - binding.tvConsoleLog.height)
            }
        }
    }

    override fun onDestroy() {
        BackgroundVoiceService.detachActivity(this)
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        networkCallback?.let { cb ->
            try {
                connectivityManager?.unregisterNetworkCallback(cb)
            } catch (_: Exception) {
            }
        }
        networkCallback = null
        disconnectWebSocket()
        disconnectMqttClient()
    }
}