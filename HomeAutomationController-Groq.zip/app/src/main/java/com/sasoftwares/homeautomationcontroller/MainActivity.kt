package com.sasoftwares.homeautomationcontroller

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.ToneGenerator
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.util.Log
import android.view.WindowManager
import android.widget.Button
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.edit
import androidx.core.graphics.toColorInt
import com.hivemq.client.mqtt.MqttClient
import com.hivemq.client.mqtt.mqtt5.Mqtt5AsyncClient
import com.sasoftwares.homeautomationcontroller.databinding.ActivityMainBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import kotlin.math.abs
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.time.Duration.Companion.milliseconds

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    private var mqttClient: Mqtt5AsyncClient? = null
    private var webSocket: WebSocket? = null
    private val okHttpClient = OkHttpClient()
    private val scope = CoroutineScope(Dispatchers.IO)
    private val handler = Handler(Looper.getMainLooper())

    private var connectivityManager: ConnectivityManager? = null
    private var networkCallback: ConnectivityManager.NetworkCallback? = null
    private var isNetworkAvailable = false

    private val groqVoice = GroqVoiceController(okHttpClient)
    private var tts: TextToSpeech? = null
    private var isTtsReady = false
    private var alertToneGenerator: ToneGenerator? = null

    private var audioRecord: AudioRecord? = null
    private var micStreamJob: Job? = null

    @Volatile
    private var wakeWordArmed = false

    @Volatile
    private var isCapturingCommand = false

    @Volatile
    private var isCheckingWakePhrase = false

    @Volatile
    private var lastWakeTriggerMs = 0L

    private var awaitingCommandAfterWake = false
    private var isProcessingGroqCommand = false
    private var isActivityVisible = false

    private val relayStates = BooleanArray(4) { false }
    private var lastSentDimmer = 0
    private var isIpConnected = false
    private var isMqttConnected = false
    private var activeProfile: Int = 1 // 1..4

    private val nonAlnumRegex = Regex("[^a-z0-9\\s]")
    private val multiSpaceRegex = Regex("\\s+")
    private val markdownStripRegex = Regex("[*#]")

    private val recordAudioPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
            if (isGranted) {
                armWakeWordMode()
            } else {
                wakeWordArmed = false
                awaitingCommandAfterWake = false
                updateVoiceButtonUI()
                logMessage(">> Microphone permission denied. Wake word unavailable.\n")
                Toast.makeText(this, "Microphone permission is required for voice commands", Toast.LENGTH_SHORT).show()
            }
        }

    companion object {
        private const val KEY_MANUAL_DISCONNECT = "manual_disconnect_flag"
        private const val SAMPLE_RATE = 16000
        private const val CHANNEL_CONFIG = AudioFormat.CHANNEL_IN_MONO
        private const val AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT
        private const val MAX_COMMAND_SECONDS = 7
        private const val WAKE_COOLDOWN_MS = 1600L
    }

    private fun keepScreenAwake() {
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        binding.root.keepScreenOn = true
    }

    private fun normalizePhrase(raw: String): String {
        return raw.lowercase()
            .replace(nonAlnumRegex, " ")
            .replace(multiSpaceRegex, " ")
            .trim()
    }

    private fun getActiveWakeWords(): List<String> {
        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        val customRaw = prefs.getString(
            ConfigActivity.key(ConfigActivity.KEY_WAKE_WORD, activeProfile),
            ConfigActivity.DEFAULT_WAKE_WORD
        ).orEmpty()

        val parsedPhrases = customRaw.split(",")
            .map { normalizePhrase(it) }
            .filter { it.isNotEmpty() }
            .distinct()

        return parsedPhrases.ifEmpty {
            listOf(normalizePhrase(ConfigActivity.DEFAULT_WAKE_WORD))
        }
    }

    private fun getWakeWordsDisplayList(): String {
        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        val raw = prefs.getString(
            ConfigActivity.key(ConfigActivity.KEY_WAKE_WORD, activeProfile),
            ConfigActivity.DEFAULT_WAKE_WORD
        ).orEmpty()
        return raw.split(",")
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .joinToString(", ")
            .ifEmpty { ConfigActivity.DEFAULT_WAKE_WORD }
    }

    private fun isSingleWakeMatch(spokenRaw: String, targetRaw: String): Boolean {
        val spoken = normalizePhrase(spokenRaw)
        val target = normalizePhrase(targetRaw)
        if (spoken.isEmpty() || target.isEmpty()) return false
        if (spoken.contains(target)) return true

        val targetTokens = target.split(" ").filter { it.isNotEmpty() }
        val spokenTokens = spoken.split(" ").filter { it.isNotEmpty() }
        if (spokenTokens.isEmpty()) return false

        if (targetTokens.size == 1) {
            val word = targetTokens[0]
            return spokenTokens.any { token ->
                token == word ||
                        (word.length >= 4 && (token.startsWith(word.take(4)) || word.startsWith(token.take(4))))
            }
        }

        val first = targetTokens.first()
        val last = targetTokens.last()
        for (i in 0 until spokenTokens.size - 1) {
            val t1 = spokenTokens[i]
            val t2 = spokenTokens[i + 1]
            val firstOk = t1 == first ||
                    t1.startsWith(first.take(2)) ||
                    first.startsWith(t1.take(2)) ||
                    (first == "hey" && (t1 == "a" || t1 == "eh" || t1 == "hay" || t1 == "hi"))
            val secondOk = t2 == last ||
                    t2.startsWith(last.take(3)) ||
                    last.startsWith(t2.take(3))
            if (firstOk && secondOk) return true
        }
        return false
    }

    fun matchAnyWakeWord(spokenText: String): String? {
        if (spokenText.isBlank()) return null
        return getActiveWakeWords().firstOrNull { phrase -> isSingleWakeMatch(spokenText, phrase) }
    }

    private fun stripWakePhraseFromTranscript(transcript: String, matchedPhrase: String): String {
        val normTranscript = normalizePhrase(transcript)
        val normWake = normalizePhrase(matchedPhrase)
        if (normWake.isEmpty()) return transcript.trim()
        val idx = normTranscript.indexOf(normWake)
        if (idx >= 0) {
            val after = normTranscript.substring(idx + normWake.length).trim()
            if (after.isNotEmpty()) return after
        }
        return ""
    }

    private fun playWakeWordDetectedAlert() {
        scope.launch(Dispatchers.IO) {
            try {
                val sampleRate = 22050
                val note1Ms = 110
                val gapMs = 30
                val note2Ms = 190
                val totalSamples = sampleRate * (note1Ms + gapMs + note2Ms) / 1000
                val pcm = ShortArray(totalSamples)

                fun addTone(startSample: Int, durationMs: Int, freqHz: Double, amplitude: Double) {
                    val count = sampleRate * durationMs / 1000
                    val fadeSamples = (sampleRate * 0.005).toInt().coerceAtLeast(1)
                    for (i in 0 until count) {
                        val idx = startSample + i
                        if (idx >= pcm.size) break
                        val env = when {
                            i < fadeSamples -> i.toDouble() / fadeSamples
                            i > count - fadeSamples -> (count - i).toDouble() / fadeSamples
                            else -> 1.0
                        }.coerceIn(0.0, 1.0)
                        val wave = 0.80 * sin(2.0 * Math.PI * freqHz * i / sampleRate) +
                                0.20 * sin(2.0 * Math.PI * (freqHz * 2.0) * i / sampleRate)
                        val sample = (env * amplitude * wave).coerceIn(-1.0, 1.0)
                        pcm[idx] = (sample * Short.MAX_VALUE).toInt().toShort()
                    }
                }

                addTone(0, note1Ms, 587.33, 0.95)
                addTone(sampleRate * (note1Ms + gapMs) / 1000, note2Ms, 880.0, 0.98)

                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(pcm.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()

                track.write(pcm, 0, pcm.size)
                track.play()
                delay((note1Ms + gapMs + note2Ms + 90).milliseconds)
                track.stop()
                track.release()
            } catch (e: Exception) {
                Log.w("WAKE_WORD", "AudioTrack chime fallback to ToneGenerator", e)
                runOnUiThread {
                    try {
                        alertToneGenerator?.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 260)
                    } catch (_: Exception) {
                    }
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        keepScreenAwake()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
        }

        alertToneGenerator = try {
            ToneGenerator(AudioManager.STREAM_ALARM, ToneGenerator.MAX_VOLUME)
        } catch (e: Exception) {
            Log.w("WAKE_WORD", "ToneGenerator init failed", e)
            null
        }

        initTextToSpeech()
        registerNetworkMonitor()

        activeProfile = getSavedActiveProfile()
        wakeWordArmed = false
        setupControls()
        updateActiveProfileUI()
        resetToDefaultState()
        updateVoiceButtonUI()

        autoConnectWebSocket()
    }

    private fun registerNetworkMonitor() {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return
        connectivityManager = cm
        isNetworkAvailable = checkCurrentNetworkState(cm)

        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                runOnUiThread {
                    val wasOffline = !isNetworkAvailable
                    isNetworkAvailable = checkCurrentNetworkState(cm)
                    if (wasOffline) {
                        logMessage(">> Internet/network restored [Device: $activeProfile]. Reviving connections...\n")
                    }
                    reviveConnectionsIfNeeded()
                }
            }

            override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) {
                val hasInternet = networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                        networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
                runOnUiThread {
                    val wasOffline = !isNetworkAvailable
                    isNetworkAvailable = hasInternet || checkCurrentNetworkState(cm)
                    if (wasOffline && isNetworkAvailable) {
                        logMessage(">> Network validated [Device: $activeProfile]. Reviving connections...\n")
                        reviveConnectionsIfNeeded()
                    }
                }
            }

            override fun onLost(network: Network) {
                runOnUiThread {
                    isNetworkAvailable = checkCurrentNetworkState(cm)
                    if (!isNetworkAvailable) {
                        logMessage(">> Network/internet dropped! Cleaning up active sockets...\n")
                        handleNetworkLost()
                    }
                }
            }
        }

        networkCallback = callback
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                cm.registerDefaultNetworkCallback(callback)
            } else {
                val req = NetworkRequest.Builder()
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .build()
                cm.registerNetworkCallback(req, callback)
            }
        } catch (e: Exception) {
            Log.e("NET_MON", "Failed to register network callback", e)
        }
    }

    private fun checkCurrentNetworkState(cm: ConnectivityManager): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val activeNet = cm.activeNetwork ?: return false
                val caps = cm.getNetworkCapabilities(activeNet) ?: return false
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            } else {
                @Suppress("DEPRECATION")
                cm.activeNetworkInfo?.isConnected == true
            }
        } catch (_: Exception) {
            false
        }
    }

    private fun handleNetworkLost() {
        webSocket?.cancel()
        webSocket = null
        isIpConnected = false

        if (isMqttConnected || mqttClient != null) {
            disconnectMqttClient()
        }

        updateConnectionStatusUI()
        resetToDefaultState()
    }

    private fun reviveConnectionsIfNeeded() {
        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        val isManualDisconnect = prefs.getBoolean(ConfigActivity.key(KEY_MANUAL_DISCONNECT, activeProfile), false)

        if (!isIpConnected && !isMqttConnected && !isManualDisconnect) {
            autoConnectWebSocket()
        } else {
            checkAndHandleMqttState()
        }

        if (wakeWordArmed &&
            micStreamJob?.isActive != true &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        ) {
            startContinuousMicStream()
        }
    }

    private fun initTextToSpeech() {
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.US
                tts?.setSpeechRate(1.05f)
                isTtsReady = true
            }
        }
    }

    private fun speakShortReply(text: String) {
        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        val enabled = prefs.getBoolean(ConfigActivity.key(ConfigActivity.KEY_TTS_ENABLED, activeProfile), true)
        if (!enabled || !isTtsReady) return

        val cleaned = text.replace(markdownStripRegex, "").replace(multiSpaceRegex, " ").trim()
        if (cleaned.isEmpty()) return
        val clipped = if (cleaned.length > 140) {
            cleaned.take(140).substringBeforeLast(" ").ifEmpty { cleaned.take(140) } + "."
        } else {
            cleaned
        }
        tts?.speak(clipped, TextToSpeech.QUEUE_FLUSH, null, "groq_reply_${System.currentTimeMillis()}")
    }

    override fun onStart() {
        super.onStart()
        keepScreenAwake()
        isActivityVisible = true
        if (wakeWordArmed &&
            micStreamJob?.isActive != true &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        ) {
            startContinuousMicStream()
        }
    }

    override fun onResume() {
        super.onResume()
        keepScreenAwake()
        isActivityVisible = true
        val cm = connectivityManager
        if (cm != null) {
            isNetworkAvailable = checkCurrentNetworkState(cm)
        }

        val latestProfile = getSavedActiveProfile()
        if (latestProfile != activeProfile) {
            switchToProfile(latestProfile, forceConnect = false)
            return
        }

        updateActiveProfileUI()
        updateConnectionStatusUI()
        updateVoiceButtonUI()

        if (wakeWordArmed &&
            micStreamJob?.isActive != true &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        ) {
            startContinuousMicStream()
        }

        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        val isManualDisconnect = prefs.getBoolean(ConfigActivity.key(KEY_MANUAL_DISCONNECT, activeProfile), false)

        if (!isIpConnected && !isMqttConnected && !isManualDisconnect) {
            logMessage(">> App resumed [Device: $activeProfile]. Reviving connection...\n")
            autoConnectWebSocket()
        } else {
            checkAndHandleMqttState()
        }
    }

    private fun getSavedActiveProfile(): Int {
        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getInt(ConfigActivity.KEY_ACTIVE_PROFILE, 1).coerceIn(1, 4)
    }

    private fun setSavedActiveProfile(profile: Int) {
        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit { putInt(ConfigActivity.KEY_ACTIVE_PROFILE, profile.coerceIn(1, 4)) }
    }

    private fun switchToProfile(profile: Int, forceConnect: Boolean) {
        activeProfile = profile.coerceIn(1, 4)
        setSavedActiveProfile(activeProfile)
        if (forceConnect) {
            setManualDisconnectFlag(false)
        }

        updateActiveProfileUI()
        resetToDefaultState()
        logMessage(">> Switched to Device: $activeProfile.\n")

        webSocket?.cancel()
        webSocket = null
        isIpConnected = false

        if (isMqttConnected || mqttClient != null) {
            disconnectMqttClient()
        }

        updateConnectionStatusUI()
        autoConnectWebSocket()
    }

    private fun updateActiveProfileUI() {
        binding.tvActiveConfig.text = getString(R.string.active_config_format, activeProfile)
        val buttons = listOf(
            binding.btnSelectConfig1,
            binding.btnSelectConfig2,
            binding.btnSelectConfig3,
            binding.btnSelectConfig4
        )
        buttons.forEachIndexed { index, button ->
            val profileNum = index + 1
            val isSelected = profileNum == activeProfile
            val colorHex = if (isSelected) "#2E7D32" else "#6200EE"
            button.backgroundTintList = ColorStateList.valueOf(colorHex.toColorInt())
            button.setTextColor("#FFFFFF".toColorInt())
        }
    }

    private fun updateVoiceButtonUI() {
        if (wakeWordArmed) {
            binding.btnVoiceCommand.text = "Wake word ON"
            val colorHex = when {
                isProcessingGroqCommand -> "#1565C0"
                isCapturingCommand || awaitingCommandAfterWake -> "#2E7D32"
                else -> "#1565C0"
            }
            binding.btnVoiceCommand.backgroundTintList = ColorStateList.valueOf(colorHex.toColorInt())
        } else {
            binding.btnVoiceCommand.text = "Wake word OFF"
            binding.btnVoiceCommand.backgroundTintList = ColorStateList.valueOf("#00796B".toColorInt())
        }
        binding.btnVoiceCommand.isEnabled = true
        binding.btnVoiceCommand.setTextColor("#FFFFFF".toColorInt())
    }

    private fun setupControls() {
        val profileButtons = listOf(
            binding.btnSelectConfig1,
            binding.btnSelectConfig2,
            binding.btnSelectConfig3,
            binding.btnSelectConfig4
        )
        profileButtons.forEachIndexed { index, button ->
            val targetProfile = index + 1
            button.setOnClickListener {
                if (targetProfile == activeProfile && (isIpConnected || isMqttConnected)) {
                    return@setOnClickListener
                }
                switchToProfile(targetProfile, forceConnect = true)
            }
        }

        val relayButtons = listOf(binding.btnRelay1, binding.btnRelay2, binding.btnRelay3, binding.btnRelay4)

        relayButtons.forEachIndexed { index, button ->
            button.setOnClickListener {
                if (!isIpConnected && !isMqttConnected) {
                    logMessage(">> Action blocked: Not connected to ESP device.\n")
                    return@setOnClickListener
                }
                val targetState = !relayStates[index]
                val stateStr = if (targetState) "ON" else "OFF"
                sendCommand("POWER${index + 1} $stateStr")
            }
        }

        binding.dimmerSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    updateDimmerText(progress)
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                if (!isIpConnected && !isMqttConnected) {
                    logMessage(">> Action blocked: Not connected to ESP device.\n")
                    return
                }
                seekBar?.let {
                    updateDimmerText(it.progress)
                    sendDimmerCommand(it.progress)
                }
            }
        })

        setupButtonTapEffect(binding.btnDimmerMin) { sendDimmerCommand(0) }
        setupButtonTapEffect(binding.btnDimmerMax) { sendDimmerCommand(9) }
        setupButtonTapEffect(binding.btnDimmerMinus) {
            val newProg = maxOf(0, binding.dimmerSeekBar.progress - 1)
            sendDimmerCommand(newProg)
        }
        setupButtonTapEffect(binding.btnDimmerPlus) {
            val newProg = minOf(9, binding.dimmerSeekBar.progress + 1)
            sendDimmerCommand(newProg)
        }

        setupButtonTapEffect(binding.btnAllOn) { sendCommand("ALL_ON") }
        setupButtonTapEffect(binding.btnAllOff) { sendCommand("ALL_OFF") }
        setupButtonTapEffect(binding.btnGetStatus) { sendCommand("STATUS") }

        binding.btnConfig.backgroundTintList = ColorStateList.valueOf("#6200EE".toColorInt())
        binding.btnConfig.setTextColor("#FFFFFF".toColorInt())
        binding.btnConfig.setOnClickListener {
            startActivity(Intent(this, ConfigActivity::class.java))
        }

        binding.btnConnectIp.setOnClickListener {
            if (!isIpConnected) {
                clearManualDisconnectFlag()
                connectWebSocket()
            } else {
                setManualDisconnectFlag(true)
                disconnectWebSocket()
            }
        }

        binding.btnVoiceCommand.setOnClickListener {
            if (wakeWordArmed) {
                disarmWakeWordMode()
                return@setOnClickListener
            }

            val hasPermission = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            if (hasPermission) {
                armWakeWordMode()
            } else {
                recordAudioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
        }
    }

    private fun armWakeWordMode() {
        keepScreenAwake()
        wakeWordArmed = true
        isCapturingCommand = false
        isCheckingWakePhrase = false
        isProcessingGroqCommand = false
        awaitingCommandAfterWake = false
        updateVoiceButtonUI()
        val wakeListStr = getWakeWordsDisplayList()
        logMessage(">> Wake word ON. Waiting for wake word: [$wakeListStr]. Tap again to turn OFF.\n")
        startContinuousMicStream()
    }

    private fun disarmWakeWordMode() {
        wakeWordArmed = false
        isCapturingCommand = false
        isCheckingWakePhrase = false
        isProcessingGroqCommand = false
        awaitingCommandAfterWake = false
        stopContinuousMicStream()
        updateVoiceButtonUI()
        logMessage(">> Wake word OFF.\n")
    }

    @SuppressLint("MissingPermission")
    private fun initAudioRecordLocked(): AudioRecord? {
        audioRecord?.let { existing ->
            if (existing.state == AudioRecord.STATE_INITIALIZED) {
                if (existing.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
                    existing.startRecording()
                }
                return existing
            }
        }

        stopContinuousMicStream()

        val minBuf = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT)
        if (minBuf <= 0) {
            logMessage(">> AudioRecord invalid buffer size ($minBuf).\n")
            return null
        }

        val bufferSize = maxOf(minBuf * 2, SAMPLE_RATE * 2)
        val recorder = try {
            AudioRecord.Builder()
                .setAudioSource(MediaRecorder.AudioSource.MIC)
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AUDIO_FORMAT)
                        .setSampleRate(SAMPLE_RATE)
                        .setChannelMask(CHANNEL_CONFIG)
                        .build()
                )
                .setBufferSizeInBytes(bufferSize)
                .build()
        } catch (e: Exception) {
            Log.e("CONTINUOUS_MIC", "AudioRecord build failed", e)
            null
        }

        if (recorder == null || recorder.state != AudioRecord.STATE_INITIALIZED) {
            try {
                recorder?.release()
            } catch (_: Exception) {
            }
            logMessage(">> Failed to initialize continuous AudioRecord.\n")
            return null
        }

        return try {
            recorder.startRecording()
            audioRecord = recorder
            recorder
        } catch (e: Exception) {
            Log.e("CONTINUOUS_MIC", "startRecording failed", e)
            try {
                recorder.release()
            } catch (_: Exception) {
            }
            null
        }
    }

    private fun stopContinuousMicStream() {
        micStreamJob?.cancel()
        micStreamJob = null
        val current = audioRecord
        audioRecord = null
        if (current != null) {
            try {
                if (current.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                    current.stop()
                }
            } catch (_: Exception) {
            }
            try {
                current.release()
            } catch (_: Exception) {
            }
        }
    }

    private fun computeRms(samples: ShortArray, count: Int): Double {
        if (count <= 0) return 0.0
        var sumSq = 0.0
        for (i in 0 until count) {
            val v = samples[i].toDouble()
            sumSq += v * v
        }
        return sqrt(sumSq / count)
    }

    private fun startContinuousMicStream() {
        if (micStreamJob?.isActive == true) return

        micStreamJob = scope.launch(Dispatchers.IO) {
            val recorder = initAudioRecordLocked() ?: return@launch
            val chunkSamples = SAMPLE_RATE / 5 // 200ms frames
            val readBuf = ShortArray(chunkSamples)
            val preRollMaxBytes = (SAMPLE_RATE * 1.2 * 2).toInt()
            val preRoll = ByteArrayOutputStream(preRollMaxBytes)

            var wakeWindowPcm: ByteArrayOutputStream? = null
            var wakeWindowStartMs = 0L
            var wakeLastVoiceMs = 0L

            var commandPcm: ByteArrayOutputStream? = null
            var commandStartMs = 0L
            var lastVoiceMs = 0L

            val voiceAmpThreshold = 1100
            val silenceTailMs = 950L
            val maxWakeWindowMs = 2600L
            val maxCommandMs = MAX_COMMAND_SECONDS * 1000L

            while (isActive && wakeWordArmed) {
                val readCount = try {
                    recorder.read(readBuf, 0, readBuf.size)
                } catch (e: Exception) {
                    Log.e("CONTINUOUS_MIC", "read error", e)
                    break
                }

                if (readCount <= 0) {
                    delay(20.milliseconds)
                    continue
                }

                val pcmBytes = shortsToLittleEndianBytes(readBuf, readCount)
                var peak = 0
                for (i in 0 until readCount) {
                    val mag = abs(readBuf[i].toInt())
                    if (mag > peak) peak = mag
                }
                val rms = computeRms(readBuf, readCount)
                val nowMs = System.currentTimeMillis()
                val hasSpeechEnergy = peak >= voiceAmpThreshold || rms >= 320.0

                if (!isCapturingCommand && !isProcessingGroqCommand) {
                    preRoll.write(pcmBytes)
                    val curPre = preRoll.toByteArray()
                    if (curPre.size > preRollMaxBytes) {
                        val startIdx = curPre.size - preRollMaxBytes
                        preRoll.reset()
                        preRoll.write(curPre, startIdx, curPre.size - startIdx)
                    }

                    if (awaitingCommandAfterWake && (nowMs - lastWakeTriggerMs) >= WAKE_COOLDOWN_MS) {
                        isCapturingCommand = true
                        wakeWindowPcm = null
                        commandPcm = ByteArrayOutputStream().apply {
                            write(curPre)
                        }
                        preRoll.reset()
                        commandStartMs = nowMs
                        lastVoiceMs = nowMs
                        runOnUiThread {
                            updateVoiceButtonUI()
                            logMessage(">> [Mic] Recording command…\n")
                        }
                    } else if (!awaitingCommandAfterWake && !isCheckingWakePhrase && (nowMs - lastWakeTriggerMs) >= WAKE_COOLDOWN_MS) {
                        if (wakeWindowPcm == null && hasSpeechEnergy) {
                            wakeWindowPcm = ByteArrayOutputStream().apply {
                                write(curPre)
                                write(pcmBytes)
                            }
                            wakeWindowStartMs = nowMs
                            wakeLastVoiceMs = nowMs
                        } else if (wakeWindowPcm != null) {
                            wakeWindowPcm.write(pcmBytes)
                            if (hasSpeechEnergy) {
                                wakeLastVoiceMs = nowMs
                            }
                            val winElapsed = nowMs - wakeWindowStartMs
                            val winSilent = nowMs - wakeLastVoiceMs
                            val readyToCheckWake = winElapsed >= maxWakeWindowMs ||
                                    (winElapsed >= 800L && winSilent >= 550L)

                            if (readyToCheckWake) {
                                val candidateBytes = wakeWindowPcm.toByteArray()
                                wakeWindowPcm = null
                                isCheckingWakePhrase = true
                                evaluateCandidateForWakeWord(candidateBytes)
                            }
                        }
                    }
                } else if (isCapturingCommand) {
                    val buf = commandPcm ?: ByteArrayOutputStream().also { commandPcm = it }
                    buf.write(pcmBytes)
                    if (hasSpeechEnergy) {
                        lastVoiceMs = nowMs
                    }

                    val elapsed = nowMs - commandStartMs
                    val silentFor = nowMs - lastVoiceMs
                    val doneCapturing = elapsed >= maxCommandMs ||
                            (elapsed >= 1200L && silentFor >= silenceTailMs)

                    if (doneCapturing) {
                        val capturedBytes = buf.toByteArray()
                        commandPcm = null
                        isCapturingCommand = false
                        awaitingCommandAfterWake = false
                        isProcessingGroqCommand = true

                        runOnUiThread {
                            updateVoiceButtonUI()
                            logMessage(">> [Groq Mic] Captured ${capturedBytes.size} PCM bytes. Thinking…\n")
                        }

                        processCapturedCommandPcm(capturedBytes)
                    }
                }
            }
        }
    }

    private fun evaluateCandidateForWakeWord(candidatePcm: ByteArray) {
        scope.launch(Dispatchers.IO) {
            try {
                if (!wakeWordArmed || candidatePcm.size < SAMPLE_RATE / 2) return@launch
                val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
                val apiKey = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_GROQ_API_KEY, activeProfile), "").orEmpty()
                if (apiKey.isBlank()) return@launch

                val wavBytes = pcm16MonoToWav(candidatePcm)
                val transcript = groqVoice.transcribeWav(wavBytes, apiKey)
                if (!wakeWordArmed) return@launch
                val matchedWake = matchAnyWakeWord(transcript)
                if (matchedWake != null) {
                    lastWakeTriggerMs = System.currentTimeMillis()
                    playWakeWordDetectedAlert()
                    runOnUiThread {
                        if (!wakeWordArmed) return@runOnUiThread
                        keepScreenAwake()
                        awaitingCommandAfterWake = true
                        updateVoiceButtonUI()
                        logMessage(">> [WAKE] Matched \"$matchedWake\" from \"$transcript\". Listening for command…\n")
                    }

                    val inlineCommand = stripWakePhraseFromTranscript(transcript, matchedWake)
                    if (inlineCommand.isNotBlank() && wakeWordArmed) {
                        awaitingCommandAfterWake = false
                        isProcessingGroqCommand = true
                        runOnUiThread {
                            updateVoiceButtonUI()
                            logMessage(">> [Groq] Thinking…\n")
                        }
                        runGroqCommandFromTranscript(inlineCommand)
                    }
                }
            } catch (e: Exception) {
                Log.w("WAKE_WORD", "Wake phrase check error", e)
            } finally {
                isCheckingWakePhrase = false
            }
        }
    }

    private suspend fun runGroqCommandFromTranscript(transcript: String) {
        try {
            val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
            val apiKey = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_GROQ_API_KEY, activeProfile), "").orEmpty()
            val modelName = prefs.getString(
                ConfigActivity.key(ConfigActivity.KEY_GROQ_MODEL, activeProfile),
                ConfigActivity.DEFAULT_GROQ_MODEL
            ).orEmpty()

            if (transcript.isBlank()) {
                runOnUiThread { speakShortReply("Could not hear clear speech.") }
                return
            }

            val bridge = object : GroqVoiceController.HardwareBridge {
                override fun sendRawCommand(cmd: String) {
                    sendCommand(cmd)
                }

                override fun setDimmerLevel(level: Int) {
                    val clamped = level.coerceIn(0, 9)
                    runOnUiThread {
                        binding.dimmerSeekBar.progress = clamped
                        updateDimmerText(clamped)
                    }
                    lastSentDimmer = -1
                    sendDimmerCommand(clamped)
                }

                override fun switchProfile(profile: Int) {
                    runOnUiThread { switchToProfile(profile, forceConnect = true) }
                }

                override fun getRelayStates(): BooleanArray = relayStates.copyOf()

                override fun getDimmerLevel(): Int = binding.dimmerSeekBar.progress

                override fun onLog(msg: String) {
                    logMessage(msg)
                }
            }

            val reply = groqVoice.runIntent(transcript, apiKey, modelName, bridge)
            logMessage(">> [Groq] $reply\n")
            runOnUiThread { speakShortReply(reply) }
        } catch (e: Exception) {
            Log.e("GROQ_VOICE", "Voice pipeline error", e)
            logMessage(">> [Groq Error] ${e.localizedMessage ?: e.message}\n")
            runOnUiThread { speakShortReply("Voice command failed.") }
        } finally {
            runOnUiThread {
                isProcessingGroqCommand = false
                updateVoiceButtonUI()
                if (wakeWordArmed) {
                    logMessage(">> Ready. Waiting for wake word…\n")
                }
            }
        }
    }

    private fun processCapturedCommandPcm(pcmBytes: ByteArray) {
        scope.launch(Dispatchers.IO) {
            try {
                val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
                val apiKey = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_GROQ_API_KEY, activeProfile), "").orEmpty()

                if (pcmBytes.isEmpty()) {
                    logMessage(">> [Groq Mic] No audio captured.\n")
                    runOnUiThread {
                        isProcessingGroqCommand = false
                        updateVoiceButtonUI()
                    }
                    return@launch
                }

                val wavBytes = pcm16MonoToWav(pcmBytes)
                val transcript = groqVoice.transcribeWav(wavBytes, apiKey)
                logMessage(">> [Groq Whisper] ${transcript.ifEmpty { "(empty)" }}\n")
                runGroqCommandFromTranscript(transcript)
            } catch (e: Exception) {
                Log.e("GROQ_VOICE", "WAV transcription error", e)
                logMessage(">> [Groq Error] ${e.localizedMessage ?: e.message}\n")
                runOnUiThread {
                    isProcessingGroqCommand = false
                    updateVoiceButtonUI()
                    speakShortReply("Voice command failed.")
                }
            }
        }
    }

    private fun shortsToLittleEndianBytes(samples: ShortArray, count: Int): ByteArray {
        val out = ByteArray(count * 2)
        for (i in 0 until count) {
            val s = samples[i].toInt()
            out[i * 2] = (s and 0xFF).toByte()
            out[i * 2 + 1] = ((s ushr 8) and 0xFF).toByte()
        }
        return out
    }

    private fun pcm16MonoToWav(pcmData: ByteArray): ByteArray {
        val channels = 1
        val bitsPerSample = 16
        val byteRate = SAMPLE_RATE * channels * bitsPerSample / 8
        val blockAlign = channels * bitsPerSample / 8
        val totalDataLen = pcmData.size + 36

        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN).apply {
            put("RIFF".toByteArray(Charsets.US_ASCII))
            putInt(totalDataLen)
            put("WAVE".toByteArray(Charsets.US_ASCII))
            put("fmt ".toByteArray(Charsets.US_ASCII))
            putInt(16)
            putShort(1) // PCM
            putShort(channels.toShort())
            putInt(SAMPLE_RATE)
            putInt(byteRate)
            putShort(blockAlign.toShort())
            putShort(bitsPerSample.toShort())
            put("data".toByteArray(Charsets.US_ASCII))
            putInt(pcmData.size)
        }.array()

        val out = ByteArrayOutputStream(header.size + pcmData.size)
        out.write(header)
        out.write(pcmData)
        return out.toByteArray()
    }

    private fun resetToDefaultState() {
        val relayButtons = listOf(binding.btnRelay1, binding.btnRelay2, binding.btnRelay3, binding.btnRelay4)
        relayButtons.forEachIndexed { index, button ->
            relayStates[index] = false
            button.text = getString(R.string.relay_off_label, index + 1)
            button.backgroundTintList = ColorStateList.valueOf("#6200EE".toColorInt())
            button.setTextColor("#FFFFFF".toColorInt())
        }
        lastSentDimmer = 0
        binding.dimmerSeekBar.progress = 0
        updateDimmerText(0)
    }

    private fun setupButtonTapEffect(button: Button, action: () -> Unit) {
        button.backgroundTintList = ColorStateList.valueOf("#6200EE".toColorInt())
        button.setTextColor("#FFFFFF".toColorInt())
        button.setOnClickListener {
            if (!isIpConnected && !isMqttConnected) {
                logMessage(">> Action blocked: Not connected to ESP device.\n")
                return@setOnClickListener
            }
            button.backgroundTintList = ColorStateList.valueOf("#4CAF50".toColorInt())
            action()
            handler.postDelayed({
                button.backgroundTintList = ColorStateList.valueOf("#6200EE".toColorInt())
            }, 250)
        }
    }

    private fun setManualDisconnectFlag(disconnected: Boolean) {
        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit { putBoolean(ConfigActivity.key(KEY_MANUAL_DISCONNECT, activeProfile), disconnected) }
    }

    private fun clearManualDisconnectFlag() {
        setManualDisconnectFlag(false)
    }

    private fun updateDimmerText(progress: Int) {
        binding.tvDimmerValue.text = getString(R.string.dimmer_level_text, progress)
    }

    private fun sendDimmerCommand(valInt: Int) {
        if (valInt != lastSentDimmer) {
            lastSentDimmer = valInt
            sendCommand("DIMMER:$valInt")
        }
    }

    private fun autoConnectWebSocket() {
        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        val ip = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_IP, activeProfile), "")?.trim()
        val isManualDisconnect = prefs.getBoolean(ConfigActivity.key(KEY_MANUAL_DISCONNECT, activeProfile), false)

        if (!ip.isNullOrEmpty() && !isManualDisconnect) {
            connectWebSocket()
        } else {
            logMessage(">> Auto-connect IP skipped [Device: $activeProfile]. Falling back to MQTT check…\n")
            checkAndHandleMqttState()
        }
    }

    private fun isAuthFailureMessage(text: String): Boolean {
        val lower = text.lowercase()
        if (lower.contains("unauthorized") ||
            lower.contains("auth_failed") ||
            lower.contains("invalid_credentials") ||
            lower.contains("wrong password") ||
            lower.contains("auth failed")
        ) {
            return true
        }

        return try {
            val obj = JSONObject(text)
            val authVal = obj.optString("auth", "").lowercase()
            val statusVal = obj.optString("status", "").lowercase()
            val errorVal = obj.optString("error", "").lowercase()
            authVal in setOf("fail", "failed", "unauthorized", "denied", "error") ||
                    statusVal in setOf("unauthorized", "auth_failed", "forbidden") ||
                    errorVal.contains("auth") || errorVal.contains("credential") || errorVal.contains("unauth")
        } catch (_: Exception) {
            false
        }
    }

    private fun connectWebSocket() {
        webSocket?.cancel()
        webSocket = null

        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        val ip = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_IP, activeProfile), "192.168.29.110")?.trim()
        val user = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_USER, activeProfile), "admin")?.trim()
        val pass = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_PASS, activeProfile), "admin1234S")?.trim()

        if (ip.isNullOrEmpty()) {
            logMessage(">> Error: No IP configured in Device: $activeProfile.\n")
            checkAndHandleMqttState()
            return
        }

        if (isMqttConnected || mqttClient != null) {
            logMessage(">> IP connection starting. Disconnecting active MQTT client…\n")
            disconnectMqttClient()
        }

        val request = Request.Builder().url("ws://$ip:81/").build()
        logMessage(">> [Device: $activeProfile] Connecting to WebSocket ws://$ip:81/…\n")

        webSocket = okHttpClient.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                isIpConnected = true
                runOnUiThread {
                    updateConnectionStatusUI()
                    logMessage(">> Connected to ESP WebSocket. Authenticating…\n")
                }

                val authPayload = JSONObject().apply {
                    put("auth", JSONObject().put("user", user).put("pass", pass))
                }.toString()
                webSocket.send(authPayload)

                sendCommand("STATUS")
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                logMessage("<< $text\n")
                if (isAuthFailureMessage(text)) {
                    isIpConnected = false
                    setManualDisconnectFlag(true)
                    this@MainActivity.webSocket = null
                    try {
                        webSocket.close(4001, "Unauthorized")
                    } catch (_: Exception) {
                        webSocket.cancel()
                    }
                    runOnUiThread {
                        updateConnectionStatusUI()
                        resetToDefaultState()
                        logMessage(">> WebSocket authentication failed! IP disconnected.\n")
                        checkAndHandleMqttState()
                    }
                    return
                }
                parseArduinoFeedback(text)
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                isIpConnected = false
                runOnUiThread {
                    updateConnectionStatusUI()
                    resetToDefaultState()
                    logMessage(">> WebSocket Error: ${t.localizedMessage}\n")
                    checkAndHandleMqttState()
                }
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                isIpConnected = false
                runOnUiThread {
                    updateConnectionStatusUI()
                    resetToDefaultState()
                    logMessage(">> IP WebSocket Disconnected.\n")
                    checkAndHandleMqttState()
                }
            }
        })
    }

    private fun disconnectWebSocket() {
        webSocket?.close(1000, "User disconnected")
        webSocket = null
        isIpConnected = false
        updateConnectionStatusUI()
        resetToDefaultState()
        logMessage(">> IP WebSocket Disconnected manually.\n")

        checkAndHandleMqttState()
    }

    private fun checkAndHandleMqttState() {
        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        val isMqttEnabled = prefs.getBoolean(ConfigActivity.key(ConfigActivity.KEY_MQTT_ENABLED, activeProfile), true)

        if (isMqttEnabled) {
            if (!isIpConnected && !isMqttConnected && (mqttClient == null || mqttClient?.state?.isConnected != true)) {
                initMqttClient()
            }
        } else {
            if (isMqttConnected || mqttClient != null) {
                disconnectMqttClient()
                logMessage(">> MQTT disabled in Device: $activeProfile. Disconnecting client.\n")
            }
        }
    }

    private fun initMqttClient() {
        val targetProfile = activeProfile
        scope.launch {
            val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
            val isMqttEnabled = prefs.getBoolean(ConfigActivity.key(ConfigActivity.KEY_MQTT_ENABLED, targetProfile), true)

            if (!isMqttEnabled || isIpConnected || targetProfile != activeProfile) {
                logMessage(">> MQTT connection skipped (Disabled, IP connected, or device changed).\n")
                return@launch
            }

            try {
                val server = prefs.getString(
                    ConfigActivity.key(ConfigActivity.KEY_MQTT_SERVER, targetProfile),
                    "i11b0026.ala.eu-central-1.emqxsl.com"
                ) ?: "i11b0026.ala.eu-central-1.emqxsl.com"
                val port = prefs.getInt(ConfigActivity.key(ConfigActivity.KEY_MQTT_PORT, targetProfile), 8883)
                val user = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_MQTT_USER, targetProfile), "admin") ?: "admin"
                val pass = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_MQTT_PASS, targetProfile), "admin1234S") ?: "admin1234S"

                logMessage(">> [Device: $targetProfile] Connecting to MQTT Broker…\n")

                mqttClient = MqttClient.builder()
                    .useMqttVersion5()
                    .serverHost(server)
                    .serverPort(port)
                    .sslWithDefaultConfig()
                    .buildAsync()

                mqttClient?.connectWith()
                    ?.simpleAuth()
                    ?.username(user)
                    ?.password(pass.toByteArray())
                    ?.applySimpleAuth()
                    ?.send()
                    ?.whenComplete { _, throwable ->
                        runOnUiThread {
                            val stillEnabled = prefs.getBoolean(
                                ConfigActivity.key(ConfigActivity.KEY_MQTT_ENABLED, targetProfile),
                                true
                            )
                            if (!stillEnabled || isIpConnected || targetProfile != activeProfile) {
                                disconnectMqttClient()
                                return@runOnUiThread
                            }

                            if (throwable == null) {
                                isMqttConnected = true
                                updateConnectionStatusUI()
                                logMessage(">> [Device: $targetProfile] Connected to MQTT Broker successfully!\n")
                                subscribeMqttTopics(targetProfile)
                                sendCommand("STATUS")
                            } else {
                                isMqttConnected = false
                                updateConnectionStatusUI()
                                resetToDefaultState()
                                logMessage(">> MQTT Connection failed: ${throwable.localizedMessage}\n")
                            }
                        }
                    }
            } catch (e: Exception) {
                Log.e("MQTT", "Connection Error", e)
                isMqttConnected = false
                runOnUiThread {
                    updateConnectionStatusUI()
                    resetToDefaultState()
                }
            }
        }
    }

    private fun disconnectMqttClient() {
        scope.launch {
            try {
                mqttClient?.disconnect()?.get()
            } catch (e: Exception) {
                Log.e("MQTT", "Disconnect error", e)
            } finally {
                mqttClient = null
                isMqttConnected = false
                runOnUiThread {
                    updateConnectionStatusUI()
                    if (!isIpConnected) {
                        resetToDefaultState()
                    }
                    logMessage(">> MQTT Client Disconnected.\n")
                }
            }
        }
    }

    private fun subscribeMqttTopics(profile: Int) {
        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        val tCmd = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_MQTT_TOPIC_CMD, profile), "home/room$profile/command")
            ?: "home/room$profile/command"
        val tState = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_MQTT_TOPIC_STATE, profile), "home/room$profile/state")
            ?: "home/room$profile/state"

        mqttClient?.subscribeWith()?.topicFilter(tCmd)?.callback { publish ->
            val msg = String(publish.payloadAsBytes)
            logMessage("<< [MQTT Cmd] $msg\n")
            parseArduinoFeedback(msg)
        }?.send()

        mqttClient?.subscribeWith()?.topicFilter(tState)?.callback { publish ->
            val msg = String(publish.payloadAsBytes)
            logMessage("<< [MQTT State] $msg\n")
            parseArduinoFeedback(msg)
        }?.send()
    }

    private fun sendCommand(cmd: String) {
        val currentProfile = activeProfile
        scope.launch {
            val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
            val isMqttEnabled = prefs.getBoolean(ConfigActivity.key(ConfigActivity.KEY_MQTT_ENABLED, currentProfile), true)

            if (isIpConnected && webSocket != null) {
                val payload = JSONObject().put("command", cmd).toString()
                webSocket?.send(payload)
                logMessage(">> [D$currentProfile] $cmd (WebSocket IP)\n")
            } else if (isMqttEnabled && isMqttConnected && mqttClient?.state?.isConnected == true) {
                val tCmd = prefs.getString(
                    ConfigActivity.key(ConfigActivity.KEY_MQTT_TOPIC_CMD, currentProfile),
                    "home/room$currentProfile/command"
                ) ?: "home/room$currentProfile/command"

                val mqttPayload = JSONObject().put("command", cmd).toString()
                mqttClient?.publishWith()
                    ?.topic(tCmd)
                    ?.payload(mqttPayload.toByteArray())
                    ?.send()
                logMessage(">> [D$currentProfile] $cmd (MQTT Broadcast)\n")
            } else {
                logMessage(">> [D$currentProfile] $cmd (Failed - Not Connected to ESP Device)\n")
            }
        }
    }

    private fun parseArduinoFeedback(jsonStr: String) {
        try {
            val data = JSONObject(jsonStr)
            for (i in 1..4) {
                val key = "POWER$i"
                if (data.has(key)) {
                    val isOn = data.getString(key) == "ON"
                    relayStates[i - 1] = isOn
                    runOnUiThread { updateUiRelay(i - 1, isOn) }
                }
            }
            if (data.has("Dimmer")) {
                val dimVal = data.getInt("Dimmer")
                lastSentDimmer = dimVal
                runOnUiThread {
                    if (binding.dimmerSeekBar.progress != dimVal) {
                        binding.dimmerSeekBar.progress = dimVal
                        updateDimmerText(dimVal)
                    }
                }
            }
        } catch (_: Exception) {}
    }

    private fun updateUiRelay(idx: Int, isOn: Boolean) {
        val buttons = listOf(binding.btnRelay1, binding.btnRelay2, binding.btnRelay3, binding.btnRelay4)
        val btn = buttons[idx]
        if (isOn) {
            btn.text = getString(R.string.relay_on_label, idx + 1)
            btn.backgroundTintList = ColorStateList.valueOf("#4CAF50".toColorInt())
            btn.setTextColor("#FFFFFF".toColorInt())
        } else {
            btn.text = getString(R.string.relay_off_label, idx + 1)
            btn.backgroundTintList = ColorStateList.valueOf("#6200EE".toColorInt())
            btn.setTextColor("#FFFFFF".toColorInt())
        }
    }

    private fun updateConnectionStatusUI() {
        if (isIpConnected) {
            binding.tvConnectionStatus.text = getString(R.string.status_connected_ip)
            binding.tvConnectionStatus.setTextColor("#2E7D32".toColorInt())
            binding.btnConnectIp.text = getString(R.string.btn_disconnect)
            binding.btnConnectIp.backgroundTintList = ColorStateList.valueOf("#4CAF50".toColorInt())
        } else if (isMqttConnected) {
            binding.tvConnectionStatus.text = getString(R.string.status_connected_mqtt)
            binding.tvConnectionStatus.setTextColor("#2E7D32".toColorInt())
            binding.btnConnectIp.text = getString(R.string.btn_connect_ip)
            binding.btnConnectIp.backgroundTintList = ColorStateList.valueOf("#6200EE".toColorInt())
        } else {
            binding.tvConnectionStatus.text = getString(R.string.status_disconnected)
            binding.tvConnectionStatus.setTextColor("#D32F2F".toColorInt())
            binding.btnConnectIp.text = getString(R.string.btn_connect_ip)
            binding.btnConnectIp.backgroundTintList = ColorStateList.valueOf("#6200EE".toColorInt())
        }
    }

    private fun logMessage(msg: String) {
        runOnUiThread {
            binding.tvConsoleLog.append(msg)
            val innerHeight = binding.tvConsoleLog.layout?.height ?: 0
            if (innerHeight > binding.tvConsoleLog.height) {
                binding.tvConsoleLog.scrollTo(0, innerHeight - binding.tvConsoleLog.height)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        isActivityVisible = false
        handler.removeCallbacksAndMessages(null)
        networkCallback?.let { cb ->
            try {
                connectivityManager?.unregisterNetworkCallback(cb)
            } catch (_: Exception) {
            }
        }
        networkCallback = null
        stopContinuousMicStream()
        try {
            alertToneGenerator?.release()
        } catch (_: Exception) {
        }
        alertToneGenerator = null
        tts?.stop()
        tts?.shutdown()
        tts = null
        disconnectWebSocket()
        disconnectMqttClient()
    }
}