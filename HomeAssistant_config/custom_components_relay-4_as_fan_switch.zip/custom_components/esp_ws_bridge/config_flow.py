from __future__ import annotations

import ipaddress
from typing import Any
import voluptuous as vol

from homeassistant import config_entries
from homeassistant.const import CONF_HOST, CONF_NAME, CONF_PASSWORD, CONF_PORT, CONF_USERNAME
from homeassistant.core import callback
from homeassistant.data_entry_flow import FlowResult

DOMAIN = "esp_ws_bridge"
DEFAULT_NAME = "ESP Controller"
DEFAULT_PORT = 81
DEFAULT_USER = "admin"
DEFAULT_PASS = "ThunderSno0w@,,#"


def _is_valid_host(value: str) -> bool:
    """Validate IPv4/IPv6 address or hostname."""
    candidate = value.strip()
    if not candidate:
        return False
    try:
        ipaddress.ip_address(candidate)
        return True
    except ValueError:
        return all(part.isalnum() or part in "-." for part in candidate) and not candidate.startswith(".")


class EspWsBridgeConfigFlow(config_entries.ConfigFlow, domain=DOMAIN):
    """Handle a config flow for ESP WebSocket Bridge."""

    VERSION = 1

    async def async_step_user(self, user_input: dict[str, Any] | None = None) -> FlowResult:
        """Handle the initial setup step."""
        errors: dict[str, str] = {}

        if user_input is not None:
            host = user_input[CONF_HOST].strip()
            port = int(user_input[CONF_PORT])
            name = user_input[CONF_NAME].strip() or DEFAULT_NAME
            username = user_input[CONF_USERNAME].strip()
            password = user_input[CONF_PASSWORD]

            if not _is_valid_host(host):
                errors[CONF_HOST] = "invalid_host"
            elif not (1 <= port <= 65535):
                errors[CONF_PORT] = "invalid_port"
            else:
                await self.async_set_unique_id(f"{host}:{port}")
                self._abort_if_unique_id_configured()
                return self.async_create_entry(
                    title=f"{name} ({host})",
                    data={
                        CONF_NAME: name,
                        CONF_HOST: host,
                        CONF_PORT: port,
                        CONF_USERNAME: username,
                        CONF_PASSWORD: password,
                    },
                )

        schema = vol.Schema(
            {
                vol.Optional(CONF_NAME, default=DEFAULT_NAME): str,
                vol.Required(CONF_HOST, default="192.168.29.110"): str,
                vol.Optional(CONF_PORT, default=DEFAULT_PORT): vol.All(
                    vol.Coerce(int), vol.Range(min=1, max=65535)
                ),
                vol.Optional(CONF_USERNAME, default=DEFAULT_USER): str,
                vol.Optional(CONF_PASSWORD, default=DEFAULT_PASS): str,
            }
        )

        return self.async_show_form(step_id="user", data_schema=schema, errors=errors)

    @staticmethod
    @callback
    def async_get_options_flow(config_entry: config_entries.ConfigEntry) -> EspWsBridgeOptionsFlow:
        """Return options flow."""
        return EspWsBridgeOptionsFlow()


class EspWsBridgeOptionsFlow(config_entries.OptionsFlow):
    """Handle options for ESP WebSocket Bridge."""

    async def async_step_init(self, user_input: dict[str, Any] | None = None) -> FlowResult:
        """Update connection credentials/port."""
        if user_input is not None:
            return self.async_create_entry(title="", data=user_input)

        schema = vol.Schema(
            {
                vol.Optional(
                    CONF_PORT,
                    default=self.config_entry.options.get(
                        CONF_PORT, self.config_entry.data.get(CONF_PORT, DEFAULT_PORT)
                    ),
                ): vol.All(vol.Coerce(int), vol.Range(min=1, max=65535)),
                vol.Optional(
                    CONF_USERNAME,
                    default=self.config_entry.options.get(
                        CONF_USERNAME, self.config_entry.data.get(CONF_USERNAME, DEFAULT_USER)
                    ),
                ): str,
                vol.Optional(
                    CONF_PASSWORD,
                    default=self.config_entry.options.get(
                        CONF_PASSWORD, self.config_entry.data.get(CONF_PASSWORD, DEFAULT_PASS)
                    ),
                ): str,
            }
        )

        return self.async_show_form(step_id="init", data_schema=schema)
