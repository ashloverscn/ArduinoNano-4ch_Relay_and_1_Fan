from __future__ import annotations

from typing import Any

from homeassistant.components.switch import SwitchEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from . import EspWebSocketClient
from .config_flow import DOMAIN


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    """Set up fan soft switch first, followed by 4 ESP relay switches over WebSocket."""
    client: EspWebSocketClient = hass.data[DOMAIN][entry.entry_id]
    entities: list[SwitchEntity] = [
        EspFanSwitch(client, entry),
        *(EspRelaySwitch(client, entry, relay_index=i) for i in range(1, 5)),
    ]
    async_add_entities(entities)


class EspFanSwitch(SwitchEntity):
    """Soft switch for the fan dimmer that remembers and restores the last speed."""

    _attr_has_entity_name = True
    _attr_name = "Fan"
    _attr_should_poll = False

    def __init__(self, client: EspWebSocketClient, entry: ConfigEntry) -> None:
        self._client = client
        self._entry = entry
        self._attr_unique_id = f"{entry.entry_id}_fan_switch"
        self._attr_device_info = {
            "identifiers": {(DOMAIN, entry.entry_id)},
            "name": client.device_name,
            "manufacturer": "Custom ESP",
            "model": "4-Relay + Fan WS",
        }

    async def async_added_to_hass(self) -> None:
        """Subscribe to WebSocket and fan state updates."""
        self.async_on_remove(self._client.register_listener(self._on_ws_update))

    def _on_ws_update(self, _payload: dict[str, Any]) -> None:
        self.async_write_ha_state()

    @property
    def available(self) -> bool:
        return self._client.connected

    @property
    def is_on(self) -> bool:
        return self._client.fan_level > 0

    async def async_turn_on(self, **kwargs: Any) -> None:
        """Turn fan on by restoring the last turned-off dimmer speed."""
        await self._client.turn_fan_on()

    async def async_turn_off(self, **kwargs: Any) -> None:
        """Turn fan off by saving current speed and setting dimmer to 0."""
        await self._client.turn_fan_off()


class EspRelaySwitch(SwitchEntity):
    """Representation of an ESP relay over WebSocket."""

    _attr_has_entity_name = True
    _attr_should_poll = False

    def __init__(self, client: EspWebSocketClient, entry: ConfigEntry, relay_index: int) -> None:
        self._client = client
        self._entry = entry
        self._relay_index = relay_index
        self._attr_name = f"Relay {relay_index}"
        self._attr_unique_id = f"{entry.entry_id}_relay_{relay_index}"
        self._attr_device_info = {
            "identifiers": {(DOMAIN, entry.entry_id)},
            "name": client.device_name,
            "manufacturer": "Custom ESP",
            "model": "4-Relay + Fan WS",
        }

    async def async_added_to_hass(self) -> None:
        """Subscribe to WebSocket state updates."""
        self.async_on_remove(self._client.register_listener(self._on_ws_update))

    def _on_ws_update(self, _payload: dict[str, Any]) -> None:
        self.async_write_ha_state()

    @property
    def available(self) -> bool:
        return self._client.connected

    @property
    def is_on(self) -> bool:
        return self._client.relay_states[self._relay_index - 1]

    async def async_turn_on(self, **kwargs: Any) -> None:
        await self._client.send_command(f"POWER{self._relay_index} ON")
        self._client.relay_states[self._relay_index - 1] = True
        self.async_write_ha_state()

    async def async_turn_off(self, **kwargs: Any) -> None:
        await self._client.send_command(f"POWER{self._relay_index} OFF")
        self._client.relay_states[self._relay_index - 1] = False
        self.async_write_ha_state()