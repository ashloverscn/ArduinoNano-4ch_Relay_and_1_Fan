from __future__ import annotations

import asyncio
from collections.abc import Callable
import json
import logging
from typing import Any
import websockets

from homeassistant.config_entries import ConfigEntry
from homeassistant.const import CONF_HOST, CONF_NAME, CONF_PASSWORD, CONF_PORT, CONF_USERNAME
from homeassistant.core import HomeAssistant
from homeassistant.exceptions import HomeAssistantError

from .config_flow import DEFAULT_NAME, DEFAULT_PASS, DEFAULT_PORT, DEFAULT_USER, DOMAIN

_LOGGER = logging.getLogger(__name__)
PLATFORMS: list[str] = ["fan", "switch"]


def _parse_bool_state(val: Any) -> bool:
    if isinstance(val, bool):
        return val
    return str(val).strip().upper() in ("ON", "1", "TRUE")


class EspWebSocketClient:
    """Maintains a persistent WebSocket connection with JSON auth and state listeners."""

    def __init__(
        self,
        hass: HomeAssistant,
        host: str,
        port: int,
        username: str,
        password: str,
        device_name: str,
        entry_id: str,
    ) -> None:
        self.hass = hass
        self.host = host
        self.port = port
        self.username = username
        self.password = password
        self.device_name = device_name
        self.entry_id = entry_id

        self._ws: Any = None
        self._task: asyncio.Task[None] | None = None
        self._stopping = False
        self._listeners: list[Callable[[dict[str, Any]], None]] = []

        self.relay_states: list[bool] = [False, False, False, False]
        self.fan_level: int = 0
        self.last_fan_level: int = 9
        self.connected: bool = False

    def set_fan_level(self, level: int, *, record_last: bool = True) -> None:
        """Update current fan level (0-9) and optionally remember non-zero speed."""
        clamped = max(0, min(9, int(level)))
        self.fan_level = clamped
        if record_last and clamped > 0:
            self.last_fan_level = clamped

    @property
    def uri(self) -> str:
        return f"ws://{self.host}:{self.port}/"

    def register_listener(self, callback_fn: Callable[[dict[str, Any]], None]) -> Callable[[], None]:
        """Register a callback invoked whenever state updates arrive."""
        self._listeners.append(callback_fn)

        def _remove() -> None:
            if callback_fn in self._listeners:
                self._listeners.remove(callback_fn)

        return _remove

    def notify_listeners(self, payload: dict[str, Any]) -> None:
        """Notify all subscribed entities of a state change."""
        for cb in list(self._listeners):
            cb(payload)

    def start(self) -> None:
        """Start background reconnect & receive loop."""
        self._stopping = False
        if self._task is None or self._task.done():
            self._task = self.hass.async_create_background_task(
                self._run_loop(), name=f"{DOMAIN}_{self.entry_id}"
            )

    async def stop(self) -> None:
        """Stop loop and close WebSocket cleanly."""
        self._stopping = True
        if self._task and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        if self._ws is not None:
            try:
                await self._ws.close()
            except Exception:
                pass
            self._ws = None
        self.connected = False

    async def send_command(self, cmd: str) -> None:
        """Send a command string wrapped in {'command': cmd}."""
        if self._ws is None or not self.connected:
            raise HomeAssistantError(f"ESP WebSocket ({self.uri}) is not connected")
        message = json.dumps({"command": cmd})
        try:
            await self._ws.send(message)
        except Exception as err:
            self.connected = False
            self.notify_listeners({"_connected": False})
            raise HomeAssistantError(f"Failed sending command '{cmd}' to {self.uri}: {err}") from err

    def _handle_feedback(self, raw_message: str) -> None:
        """Parse JSON feedback matching the Tkinter controller format."""
        try:
            data = json.loads(raw_message)
        except json.JSONDecodeError:
            return

        if not isinstance(data, dict):
            return

        updated = False

        for i in range(1, 5):
            key = f"POWER{i}"
            if key in data:
                self.relay_states[i - 1] = _parse_bool_state(data[key])
                updated = True

        for fan_key in ("Dimmer", "dimmer", "Fan", "fan"):
            if fan_key in data:
                try:
                    self.set_fan_level(int(data[fan_key]), record_last=True)
                    updated = True
                except (ValueError, TypeError):
                    pass

        if data.get("type") == "state_update":
            relays = data.get("relays")
            if isinstance(relays, list):
                for idx, state in enumerate(relays[:4]):
                    self.relay_states[idx] = bool(state)
                    updated = True
            for fan_key in ("dimmer", "fan"):
                if fan_key in data:
                    try:
                        self.set_fan_level(int(data[fan_key]), record_last=True)
                        updated = True
                    except (ValueError, TypeError):
                        pass

        if updated:
            self.notify_listeners(data)

    async def _run_loop(self) -> None:
        backoff = 2
        while not self._stopping:
            try:
                async with websockets.connect(self.uri, ping_interval=20, ping_timeout=20) as ws:
                    self._ws = ws
                    self.connected = True
                    backoff = 2

                    auth_payload = json.dumps(
                        {"auth": {"user": self.username, "pass": self.password}}
                    )
                    await ws.send(auth_payload)
                    await ws.send(json.dumps({"command": "STATUS"}))
                    self.notify_listeners({"_connected": True})

                    async for message in ws:
                        if isinstance(message, bytes):
                            message = message.decode("utf-8", errors="ignore")
                        self._handle_feedback(message)

            except asyncio.CancelledError:
                break
            except Exception as err:
                was_connected = self.connected
                self._ws = None
                self.connected = False
                if was_connected:
                    self.notify_listeners({"_connected": False})
                _LOGGER.debug("WebSocket link to %s failed (%s), retrying in %ss", self.uri, err, backoff)
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, 30)
            finally:
                self._ws = None
                self.connected = False


async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Set up ESP WebSocket Bridge from a config entry."""
    host: str = entry.data[CONF_HOST]
    port: int = entry.options.get(CONF_PORT, entry.data.get(CONF_PORT, DEFAULT_PORT))
    username: str = entry.options.get(
        CONF_USERNAME, entry.data.get(CONF_USERNAME, DEFAULT_USER)
    )
    password: str = entry.options.get(
        CONF_PASSWORD, entry.data.get(CONF_PASSWORD, DEFAULT_PASS)
    )
    device_name: str = entry.data.get(CONF_NAME, DEFAULT_NAME)

    client = EspWebSocketClient(
        hass=hass,
        host=host,
        port=port,
        username=username,
        password=password,
        device_name=device_name,
        entry_id=entry.entry_id,
    )

    hass.data.setdefault(DOMAIN, {})[entry.entry_id] = client
    client.start()

    await hass.config_entries.async_forward_entry_setups(entry, PLATFORMS)
    entry.async_on_unload(entry.add_update_listener(_async_update_listener))
    return True


async def _async_update_listener(hass: HomeAssistant, entry: ConfigEntry) -> None:
    """Reload config entry when options change."""
    await hass.config_entries.async_reload(entry.entry_id)


async def async_unload_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Unload config entry and close WebSocket."""
    unload_ok = await hass.config_entries.async_unload_platforms(entry, PLATFORMS)
    client: EspWebSocketClient | None = hass.data.get(DOMAIN, {}).pop(entry.entry_id, None)
    if client is not None:
        await client.stop()
    return unload_ok