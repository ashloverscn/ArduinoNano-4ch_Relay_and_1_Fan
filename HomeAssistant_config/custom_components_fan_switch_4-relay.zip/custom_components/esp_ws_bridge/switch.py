from __future__ import annotations

from typing import Any

from homeassistant.components.switch import SwitchEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from . import EspWebSocketClient
from .config_flow import DOMAIN

RELAY_NAMES: dict[int, str] = {
    1: "Relay 1",
    2: "Relay 2",
    3: "Relay 3",
    4: "Relay 4",
}


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    """Set up virtual fan switch followed by relays 1-4 over WebSocket."""
    client: EspWebSocketClient = hass.data[DOMAIN][entry.entry_id]
    entities: list[SwitchEntity] = [EspFanVirtualSwitch(client, entry)]
    entities.extend(EspRelaySwitch(client, entry, relay_index=i) for i in range(1, 5))
    async_add_entities(entities)


class EspFanVirtualSwitch(SwitchEntity):
    """Virtual switch controlling fan ON/OFF via last non-zero dimmer level and 0."""

    _attr_has_entity_name = True
    _attr_should_poll = False

    def __init__(self, client: EspWebSocketClient, entry: ConfigEntry) -> None:
        self._client = client
        self._entry = entry
        self._attr_name = "Fan"
        self._attr_unique_id = f"{entry.entry_id}_fan_switch"
        self._attr_device_info = {
            "identifiers": {(DOMAIN, entry.entry_id)},
            "name": client.device_name,
            "manufacturer": "Custom ESP",
            "model": "4-Relay + Fan WS",
        }

    async def async_added_to_hass(self) -> None:
        """Subscribe to WebSocket state updates."""
        self.async_on_remove(self._client.register_listener(self._on_ws_update))

    def _on_ws_update(self, _payload: dict[str, Any]) -> None:
        self.async_write_ha_state()

    @property
    def available(self) -> bool:
        return self._client.connected

    @property
    def is_on(self) -> bool:
        return self._client.fan_level > 0

    async def async_turn_on(self, **kwargs: Any) -> None:
        target_level = self._client.last_fan_level if self._client.last_fan_level > 0 else 9
        await self._client.send_command(f"DIMMER:{target_level}")
        self._client.set_fan_level(target_level, record_last=True)
        self._client.notify_listeners({"dimmer": target_level})
        self.async_write_ha_state()

    async def async_turn_off(self, **kwargs: Any) -> None:
        if self._client.fan_level > 0:
            self._client.last_fan_level = self._client.fan_level
        await self._client.send_command("DIMMER:0")
        self._client.set_fan_level(0, record_last=False)
        self._client.notify_listeners({"dimmer": 0})
        self.async_write_ha_state()


class EspRelaySwitch(SwitchEntity):
    """Representation of an ESP relay over WebSocket."""

    _attr_has_entity_name = True
    _attr_should_poll = False

    def __init__(self, client: EspWebSocketClient, entry: ConfigEntry, relay_index: int) -> None:
        self._client = client
        self._entry = entry
        self._relay_index = relay_index
        self._attr_name = RELAY_NAMES.get(relay_index, f"Relay {relay_index}")
        self._attr_unique_id = f"{entry.entry_id}_relay_{relay_index}"
        self._attr_device_info = {
            "identifiers": {(DOMAIN, entry.entry_id)},
            "name": client.device_name,
            "manufacturer": "Custom ESP",
            "model": "4-Relay + Fan WS",
        }

    async def async_added_to_hass(self) -> None:
        """Subscribe to WebSocket state updates."""
        self.async_on_remove(self._client.register_listener(self._on_ws_update))

    def _on_ws_update(self, _payload: dict[str, Any]) -> None:
        self.async_write_ha_state()

    @property
    def available(self) -> bool:
        return self._client.connected

    @property
    def is_on(self) -> bool:
        return self._client.relay_states[self._relay_index - 1]

    async def async_turn_on(self, **kwargs: Any) -> None:
        await self._client.send_command(f"POWER{self._relay_index} ON")
        self._client.relay_states[self._relay_index - 1] = True
        self.async_write_ha_state()

    async def async_turn_off(self, **kwargs: Any) -> None:
        await self._client.send_command(f"POWER{self._relay_index} OFF")
        self._client.relay_states[self._relay_index - 1] = False
        self.async_write_ha_state()