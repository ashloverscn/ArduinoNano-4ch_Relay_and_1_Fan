from __future__ import annotations

import math
from typing import Any

from homeassistant.components.fan import FanEntity, FanEntityFeature
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from . import EspWebSocketClient
from .config_flow import DOMAIN

SPEED_COUNT = 9


def _percentage_to_level_0_9(percentage: int) -> int:
    """Map Home Assistant percentage (0-100) to fan level (0-9)."""
    clamped = max(0, min(100, percentage))
    if clamped == 0:
        return 0
    return max(1, min(SPEED_COUNT, math.ceil((clamped / 100) * SPEED_COUNT)))


def _level_0_9_to_percentage(level: int) -> int:
    """Map fan level (0-9) to Home Assistant percentage (0-100)."""
    clamped = max(0, min(SPEED_COUNT, level))
    if clamped == 0:
        return 0
    return round((clamped / SPEED_COUNT) * 100)


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    """Set up ESP fan over WebSocket."""
    client: EspWebSocketClient = hass.data[DOMAIN][entry.entry_id]
    async_add_entities([EspPhaseCutFan(client, entry)])


class EspPhaseCutFan(FanEntity):
    """Representation of the ESP AC phase-cut fan (levels 0-9) over WebSocket."""

    _attr_has_entity_name = True
    _attr_name = "Fan"
    _attr_should_poll = False
    _attr_supported_features = FanEntityFeature.SET_SPEED
    _attr_speed_count = SPEED_COUNT

    def __init__(self, client: EspWebSocketClient, entry: ConfigEntry) -> None:
        self._client = client
        self._entry = entry
        self._attr_unique_id = f"{entry.entry_id}_fan"
        self._attr_device_info = {
            "identifiers": {(DOMAIN, entry.entry_id)},
            "name": client.device_name,
            "manufacturer": "Custom ESP",
            "model": "4-Relay + Fan WS",
        }

    async def async_added_to_hass(self) -> None:
        """Subscribe to WebSocket state updates."""
        self.async_on_remove(self._client.register_listener(self._on_ws_update))

    def _on_ws_update(self, _payload: dict[str, Any]) -> None:
        self.async_write_ha_state()

    @property
    def available(self) -> bool:
        return self._client.connected

    @property
    def is_on(self) -> bool:
        return self._client.fan_level > 0

    @property
    def percentage(self) -> int:
        return _level_0_9_to_percentage(self._client.fan_level)

    async def async_set_percentage(self, percentage: int) -> None:
        """Set fan speed percentage (0-100) mapped to ESP level 0-9."""
        level = _percentage_to_level_0_9(percentage)
        await self._client.send_command(f"DIMMER:{level}")
        self._client.fan_level = level
        self.async_write_ha_state()

    async def async_turn_on(
        self,
        percentage: int | None = None,
        preset_mode: str | None = None,
        **kwargs: Any,
    ) -> None:
        """Turn fan on (defaults to saved level > 0 or max level 9)."""
        if percentage is not None:
            level = _percentage_to_level_0_9(percentage)
            if level == 0:
                level = 1
        elif self._client.fan_level > 0:
            level = self._client.fan_level
        else:
            level = SPEED_COUNT

        await self._client.send_command(f"DIMMER:{level}")
        self._client.fan_level = level
        self.async_write_ha_state()

    async def async_turn_off(self, **kwargs: Any) -> None:
        """Turn fan off (level 0)."""
        await self._client.send_command("DIMMER:0")
        self._client.fan_level = 0
        self.async_write_ha_state()