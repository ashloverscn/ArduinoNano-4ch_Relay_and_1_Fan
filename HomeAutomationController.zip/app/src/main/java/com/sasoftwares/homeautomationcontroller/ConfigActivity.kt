package com.sasoftwares.homeautomationcontroller

import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.edit
import com.sasoftwares.homeautomationcontroller.databinding.ActivityConfigBinding

class ConfigActivity : AppCompatActivity() {
    private lateinit var binding: ActivityConfigBinding

    companion object {
        const val PREFS_NAME = "HomeAutomationPrefs"
        const val KEY_IP = "esp_ip"
        const val KEY_USER = "esp_user"
        const val KEY_PASS = "esp_pass"
        const val KEY_MQTT_ENABLED = "mqtt_enabled"
        const val KEY_MQTT_SERVER = "mqtt_server"
        const val KEY_MQTT_PORT = "mqtt_port"
        const val KEY_MQTT_USER = "mqtt_user"
        const val KEY_MQTT_PASS = "mqtt_pass"
        const val KEY_MQTT_TOPIC_CMD = "mqtt_topic_cmd"
        const val KEY_MQTT_TOPIC_STATE = "mqtt_topic_state"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityConfigBinding.inflate(layoutInflater)
        setContentView(binding.root)

        loadSavedPreferences()

        binding.btnSave.setOnClickListener {
            savePreferences()
            Toast.makeText(this, "Settings Saved!", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun loadSavedPreferences() {
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

        binding.etIp.setText(prefs.getString(KEY_IP, "192.168.29.110"))
        binding.etUser.setText(prefs.getString(KEY_USER, "admin"))
        binding.etPass.setText(prefs.getString(KEY_PASS, "admin1234S"))

        binding.cbMqttEnabled.isChecked = prefs.getBoolean(KEY_MQTT_ENABLED, true)
        binding.etMqttServer.setText(prefs.getString(KEY_MQTT_SERVER, "i11b0026.ala.eu-central-1.emqxsl.com"))
        binding.etMqttPort.setText(prefs.getInt(KEY_MQTT_PORT, 8883).toString())
        binding.etMqttUser.setText(prefs.getString(KEY_MQTT_USER, "admin"))
        binding.etMqttPass.setText(prefs.getString(KEY_MQTT_PASS, "admin1234S"))
        binding.etMqttTopicCmd.setText(prefs.getString(KEY_MQTT_TOPIC_CMD, "home/esp32/command"))
        binding.etMqttTopicState.setText(prefs.getString(KEY_MQTT_TOPIC_STATE, "home/esp32/state"))
    }

    private fun savePreferences() {
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val portInt = binding.etMqttPort.text.toString().toIntOrNull() ?: 8883

        prefs.edit {
            putString(KEY_IP, binding.etIp.text.toString().trim())
            putString(KEY_USER, binding.etUser.text.toString().trim())
            putString(KEY_PASS, binding.etPass.text.toString().trim())
            putBoolean(KEY_MQTT_ENABLED, binding.cbMqttEnabled.isChecked)
            putString(KEY_MQTT_SERVER, binding.etMqttServer.text.toString().trim())
            putInt(KEY_MQTT_PORT, portInt)
            putString(KEY_MQTT_USER, binding.etMqttUser.text.toString().trim())
            putString(KEY_MQTT_PASS, binding.etMqttPass.text.toString().trim())
            putString(KEY_MQTT_TOPIC_CMD, binding.etMqttTopicCmd.text.toString().trim())
            putString(KEY_MQTT_TOPIC_STATE, binding.etMqttTopicState.text.toString().trim())
        }
    }
}