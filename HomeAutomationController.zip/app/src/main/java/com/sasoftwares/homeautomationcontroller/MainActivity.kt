package com.sasoftwares.homeautomationcontroller

import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.widget.Button
import android.widget.SeekBar
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.edit
import androidx.core.graphics.toColorInt
import com.sasoftwares.homeautomationcontroller.databinding.ActivityMainBinding
import com.hivemq.client.mqtt.MqttClient
import com.hivemq.client.mqtt.mqtt5.Mqtt5AsyncClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.*
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    private var mqttClient: Mqtt5AsyncClient? = null
    private var webSocket: WebSocket? = null
    private val okHttpClient = OkHttpClient()
    private val scope = CoroutineScope(Dispatchers.IO)
    private val handler = Handler(Looper.getMainLooper())

    private val relayStates = BooleanArray(4) { false }
    private var lastSentDimmer = 0
    private var isIpConnected = false
    private var isMqttConnected = false
    private var activeProfile: Int = 1 // 1..4

    companion object {
        private const val KEY_MANUAL_DISCONNECT = "manual_disconnect_flag"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        activeProfile = getSavedActiveProfile()
        setupControls()
        updateActiveProfileUI()
        resetToDefaultState()

        // Initial setup: Try auto-connecting IP first, otherwise fallback to MQTT if enabled
        autoConnectWebSocket()
    }

    override fun onResume() {
        super.onResume()
        val latestProfile = getSavedActiveProfile()
        if (latestProfile != activeProfile) {
            switchToProfile(latestProfile, forceConnect = false)
            return
        }

        updateActiveProfileUI()
        updateConnectionStatusUI()

        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        val isManualDisconnect = prefs.getBoolean(ConfigActivity.key(KEY_MANUAL_DISCONNECT, activeProfile), false)

        // Revive connection upon waking up if not connected and not manually disconnected
        if (!isIpConnected && !isMqttConnected && !isManualDisconnect) {
            logMessage(">> App resumed [Device: $activeProfile]. Reviving connection...\n")
            autoConnectWebSocket()
        } else {
            checkAndHandleMqttState()
        }
    }

    private fun getSavedActiveProfile(): Int {
        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getInt(ConfigActivity.KEY_ACTIVE_PROFILE, 1).coerceIn(1, 4)
    }

    private fun setSavedActiveProfile(profile: Int) {
        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit { putInt(ConfigActivity.KEY_ACTIVE_PROFILE, profile.coerceIn(1, 4)) }
    }

    private fun switchToProfile(profile: Int, forceConnect: Boolean) {
        activeProfile = profile.coerceIn(1, 4)
        setSavedActiveProfile(activeProfile)
        if (forceConnect) {
            setManualDisconnectFlag(false)
        }

        updateActiveProfileUI()
        resetToDefaultState()
        logMessage(">> Switched to Device: $activeProfile.\n")

        // Tear down existing connections from the previous device/profile before connecting
        webSocket?.cancel()
        webSocket = null
        isIpConnected = false

        if (isMqttConnected || mqttClient != null) {
            disconnectMqttClient()
        }

        updateConnectionStatusUI()
        autoConnectWebSocket()
    }

    private fun updateActiveProfileUI() {
        binding.tvActiveConfig.text = getString(R.string.active_config_format, activeProfile)
        val buttons = listOf(
            binding.btnSelectConfig1,
            binding.btnSelectConfig2,
            binding.btnSelectConfig3,
            binding.btnSelectConfig4
        )
        buttons.forEachIndexed { index, button ->
            val profileNum = index + 1
            val isSelected = profileNum == activeProfile
            val colorHex = if (isSelected) "#2E7D32" else "#6200EE"
            button.backgroundTintList = ColorStateList.valueOf(colorHex.toColorInt())
            button.setTextColor("#FFFFFF".toColorInt())
        }
    }

    private fun setupControls() {
        val profileButtons = listOf(
            binding.btnSelectConfig1,
            binding.btnSelectConfig2,
            binding.btnSelectConfig3,
            binding.btnSelectConfig4
        )
        profileButtons.forEachIndexed { index, button ->
            val targetProfile = index + 1
            button.setOnClickListener {
                if (targetProfile == activeProfile && (isIpConnected || isMqttConnected)) {
                    return@setOnClickListener
                }
                switchToProfile(targetProfile, forceConnect = true)
            }
        }

        val relayButtons = listOf(binding.btnRelay1, binding.btnRelay2, binding.btnRelay3, binding.btnRelay4)

        relayButtons.forEachIndexed { index, button ->
            button.setOnClickListener {
                if (!isIpConnected && !isMqttConnected) {
                    logMessage(">> Action blocked: Not connected to ESP device.\n")
                    return@setOnClickListener
                }
                val targetState = !relayStates[index]
                val stateStr = if (targetState) "ON" else "OFF"
                sendCommand("POWER${index + 1} $stateStr")
            }
        }

        binding.dimmerSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    updateDimmerText(progress)
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                if (!isIpConnected && !isMqttConnected) {
                    logMessage(">> Action blocked: Not connected to ESP device.\n")
                    return
                }
                seekBar?.let {
                    updateDimmerText(it.progress)
                    sendDimmerCommand(it.progress)
                }
            }
        })

        setupButtonTapEffect(binding.btnDimmerMin) { sendDimmerCommand(0) }
        setupButtonTapEffect(binding.btnDimmerMax) { sendDimmerCommand(9) }
        setupButtonTapEffect(binding.btnDimmerMinus) {
            val newProg = maxOf(0, binding.dimmerSeekBar.progress - 1)
            sendDimmerCommand(newProg)
        }
        setupButtonTapEffect(binding.btnDimmerPlus) {
            val newProg = minOf(9, binding.dimmerSeekBar.progress + 1)
            sendDimmerCommand(newProg)
        }

        setupButtonTapEffect(binding.btnAllOn) { sendCommand("ALL_ON") }
        setupButtonTapEffect(binding.btnAllOff) { sendCommand("ALL_OFF") }
        setupButtonTapEffect(binding.btnGetStatus) { sendCommand("STATUS") }

        binding.btnConfig.backgroundTintList = ColorStateList.valueOf("#6200EE".toColorInt())
        binding.btnConfig.setTextColor("#FFFFFF".toColorInt())
        binding.btnConfig.setOnClickListener {
            startActivity(Intent(this, ConfigActivity::class.java))
        }

        binding.btnConnectIp.setOnClickListener {
            if (!isIpConnected) {
                clearManualDisconnectFlag()
                connectWebSocket()
            } else {
                setManualDisconnectFlag(true)
                disconnectWebSocket()
            }
        }
    }

    private fun resetToDefaultState() {
        val relayButtons = listOf(binding.btnRelay1, binding.btnRelay2, binding.btnRelay3, binding.btnRelay4)
        relayButtons.forEachIndexed { index, button ->
            relayStates[index] = false
            button.text = getString(R.string.relay_off_label, index + 1)
            button.backgroundTintList = ColorStateList.valueOf("#6200EE".toColorInt())
            button.setTextColor("#FFFFFF".toColorInt())
        }
        lastSentDimmer = 0
        binding.dimmerSeekBar.progress = 0
        updateDimmerText(0)
    }

    private fun setupButtonTapEffect(button: Button, action: () -> Unit) {
        button.backgroundTintList = ColorStateList.valueOf("#6200EE".toColorInt())
        button.setTextColor("#FFFFFF".toColorInt())
        button.setOnClickListener {
            if (!isIpConnected && !isMqttConnected) {
                logMessage(">> Action blocked: Not connected to ESP device.\n")
                return@setOnClickListener
            }
            button.backgroundTintList = ColorStateList.valueOf("#4CAF50".toColorInt())
            action()
            handler.postDelayed({
                button.backgroundTintList = ColorStateList.valueOf("#6200EE".toColorInt())
            }, 250)
        }
    }

    private fun setManualDisconnectFlag(disconnected: Boolean) {
        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit { putBoolean(ConfigActivity.key(KEY_MANUAL_DISCONNECT, activeProfile), disconnected) }
    }

    private fun clearManualDisconnectFlag() {
        setManualDisconnectFlag(false)
    }

    private fun updateDimmerText(progress: Int) {
        binding.tvDimmerValue.text = getString(R.string.dimmer_level_text, progress)
    }

    private fun sendDimmerCommand(valInt: Int) {
        if (valInt != lastSentDimmer) {
            lastSentDimmer = valInt
            sendCommand("DIMMER:$valInt")
        }
    }

    private fun autoConnectWebSocket() {
        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        val ip = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_IP, activeProfile), "")?.trim()
        val isManualDisconnect = prefs.getBoolean(ConfigActivity.key(KEY_MANUAL_DISCONNECT, activeProfile), false)

        if (!ip.isNullOrEmpty() && !isManualDisconnect) {
            connectWebSocket()
        } else {
            logMessage(">> Auto-connect IP skipped [Device: $activeProfile]. Falling back to MQTT check...\n")
            checkAndHandleMqttState()
        }
    }

    private fun connectWebSocket() {
        // Clean up any stale socket reference before creating a new one
        webSocket?.cancel()
        webSocket = null

        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        val ip = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_IP, activeProfile), "192.168.29.110")?.trim()
        val user = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_USER, activeProfile), "admin")?.trim()
        val pass = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_PASS, activeProfile), "admin1234S")?.trim()

        if (ip.isNullOrEmpty()) {
            logMessage(">> Error: No IP configured in Device: $activeProfile.\n")
            checkAndHandleMqttState()
            return
        }

        // Mutual exclusivity: Disconnect MQTT when WebSocket connection attempt starts
        if (isMqttConnected || mqttClient != null) {
            logMessage(">> IP connection starting. Disconnecting active MQTT client...\n")
            disconnectMqttClient()
        }

        val request = Request.Builder().url("ws://$ip:81/").build()
        logMessage(">> [Device: $activeProfile] Connecting to WebSocket ws://$ip:81/...\n")

        webSocket = okHttpClient.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                isIpConnected = true
                runOnUiThread {
                    updateConnectionStatusUI()
                    logMessage(">> Connected to ESP WebSocket. Authenticating...\n")
                }

                val authPayload = JSONObject().apply {
                    put("auth", JSONObject().put("user", user).put("pass", pass))
                }.toString()
                webSocket.send(authPayload)

                sendCommand("STATUS")
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                logMessage("<< $text\n")
                parseArduinoFeedback(text)
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                isIpConnected = false
                runOnUiThread {
                    updateConnectionStatusUI()
                    resetToDefaultState()
                    logMessage(">> WebSocket Error: ${t.localizedMessage}\n")
                    // Fall back to MQTT upon IP failure
                    checkAndHandleMqttState()
                }
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                isIpConnected = false
                runOnUiThread {
                    updateConnectionStatusUI()
                    resetToDefaultState()
                    logMessage(">> IP WebSocket Disconnected.\n")
                    // Fall back to MQTT upon IP disconnection
                    checkAndHandleMqttState()
                }
            }
        })
    }

    private fun disconnectWebSocket() {
        webSocket?.close(1000, "User disconnected")
        webSocket = null
        isIpConnected = false
        updateConnectionStatusUI()
        resetToDefaultState()
        logMessage(">> IP WebSocket Disconnected manually.\n")

        // Fall back to MQTT when IP is manually disconnected
        checkAndHandleMqttState()
    }

    private fun checkAndHandleMqttState() {
        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        val isMqttEnabled = prefs.getBoolean(ConfigActivity.key(ConfigActivity.KEY_MQTT_ENABLED, activeProfile), true)

        if (isMqttEnabled) {
            // Only initialize MQTT if we aren't connected via direct IP WebSocket
            if (!isIpConnected && !isMqttConnected && (mqttClient == null || mqttClient?.state?.isConnected != true)) {
                initMqttClient()
            }
        } else {
            if (isMqttConnected || mqttClient != null) {
                disconnectMqttClient()
                logMessage(">> MQTT disabled in Device: $activeProfile. Disconnecting client.\n")
            }
        }
    }

    private fun initMqttClient() {
        val targetProfile = activeProfile
        scope.launch {
            val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
            val isMqttEnabled = prefs.getBoolean(ConfigActivity.key(ConfigActivity.KEY_MQTT_ENABLED, targetProfile), true)

            if (!isMqttEnabled || isIpConnected || targetProfile != activeProfile) {
                logMessage(">> MQTT connection skipped (Disabled, IP connected, or device changed).\n")
                return@launch
            }

            try {
                val server = prefs.getString(
                    ConfigActivity.key(ConfigActivity.KEY_MQTT_SERVER, targetProfile),
                    "i11b0026.ala.eu-central-1.emqxsl.com"
                ) ?: "i11b0026.ala.eu-central-1.emqxsl.com"
                val port = prefs.getInt(ConfigActivity.key(ConfigActivity.KEY_MQTT_PORT, targetProfile), 8883)
                val user = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_MQTT_USER, targetProfile), "admin") ?: "admin"
                val pass = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_MQTT_PASS, targetProfile), "admin1234S") ?: "admin1234S"

                logMessage(">> [Device: $targetProfile] Connecting to MQTT Broker...\n")

                mqttClient = MqttClient.builder()
                    .useMqttVersion5()
                    .serverHost(server)
                    .serverPort(port)
                    .sslWithDefaultConfig()
                    .buildAsync()

                mqttClient?.connectWith()
                    ?.simpleAuth()
                    ?.username(user)
                    ?.password(pass.toByteArray())
                    ?.applySimpleAuth()
                    ?.send()
                    ?.whenComplete { _, throwable ->
                        runOnUiThread {
                            // Re-verify preferences and ensure device/IP hasn't changed in the meantime
                            val stillEnabled = prefs.getBoolean(
                                ConfigActivity.key(ConfigActivity.KEY_MQTT_ENABLED, targetProfile),
                                true
                            )
                            if (!stillEnabled || isIpConnected || targetProfile != activeProfile) {
                                disconnectMqttClient()
                                return@runOnUiThread
                            }

                            if (throwable == null) {
                                isMqttConnected = true
                                updateConnectionStatusUI()
                                logMessage(">> [Device: $targetProfile] Connected to MQTT Broker successfully!\n")
                                subscribeMqttTopics(targetProfile)
                                sendCommand("STATUS")
                            } else {
                                isMqttConnected = false
                                updateConnectionStatusUI()
                                resetToDefaultState()
                                logMessage(">> MQTT Connection failed: ${throwable.localizedMessage}\n")
                            }
                        }
                    }
            } catch (e: Exception) {
                Log.e("MQTT", "Connection Error", e)
                isMqttConnected = false
                runOnUiThread {
                    updateConnectionStatusUI()
                    resetToDefaultState()
                }
            }
        }
    }

    private fun disconnectMqttClient() {
        scope.launch {
            try {
                mqttClient?.disconnect()?.get()
            } catch (e: Exception) {
                Log.e("MQTT", "Disconnect error", e)
            } finally {
                mqttClient = null
                isMqttConnected = false
                runOnUiThread {
                    updateConnectionStatusUI()
                    if (!isIpConnected) {
                        resetToDefaultState()
                    }
                    logMessage(">> MQTT Client Disconnected.\n")
                }
            }
        }
    }

    private fun subscribeMqttTopics(profile: Int) {
        val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
        val tCmd = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_MQTT_TOPIC_CMD, profile), "home/room$profile/command")
            ?: "home/room$profile/command"
        val tState = prefs.getString(ConfigActivity.key(ConfigActivity.KEY_MQTT_TOPIC_STATE, profile), "home/room$profile/state")
            ?: "home/room$profile/state"

        mqttClient?.subscribeWith()?.topicFilter(tCmd)?.callback { publish ->
            val msg = String(publish.payloadAsBytes)
            logMessage("<< [MQTT Cmd] $msg\n")
            parseArduinoFeedback(msg)
        }?.send()

        mqttClient?.subscribeWith()?.topicFilter(tState)?.callback { publish ->
            val msg = String(publish.payloadAsBytes)
            logMessage("<< [MQTT State] $msg\n")
            parseArduinoFeedback(msg)
        }?.send()
    }

    private fun sendCommand(cmd: String) {
        val currentProfile = activeProfile
        scope.launch {
            val prefs = getSharedPreferences(ConfigActivity.PREFS_NAME, Context.MODE_PRIVATE)
            val isMqttEnabled = prefs.getBoolean(ConfigActivity.key(ConfigActivity.KEY_MQTT_ENABLED, currentProfile), true)

            if (isIpConnected && webSocket != null) {
                val payload = JSONObject().put("command", cmd).toString()
                webSocket?.send(payload)
                logMessage(">> [D$currentProfile] $cmd (WebSocket IP)\n")
            } else if (isMqttEnabled && isMqttConnected && mqttClient?.state?.isConnected == true) {
                val tCmd = prefs.getString(
                    ConfigActivity.key(ConfigActivity.KEY_MQTT_TOPIC_CMD, currentProfile),
                    "home/room$currentProfile/command"
                ) ?: "home/room$currentProfile/command"

                val mqttPayload = JSONObject().put("command", cmd).toString()
                mqttClient?.publishWith()
                    ?.topic(tCmd)
                    ?.payload(mqttPayload.toByteArray())
                    ?.send()
                logMessage(">> [D$currentProfile] $cmd (MQTT Broadcast)\n")
            } else {
                logMessage(">> [D$currentProfile] $cmd (Failed - Not Connected to ESP Device)\n")
            }
        }
    }

    private fun parseArduinoFeedback(jsonStr: String) {
        try {
            val data = JSONObject(jsonStr)
            for (i in 1..4) {
                val key = "POWER$i"
                if (data.has(key)) {
                    val isOn = data.getString(key) == "ON"
                    relayStates[i - 1] = isOn
                    runOnUiThread { updateUiRelay(i - 1, isOn) }
                }
            }
            if (data.has("Dimmer")) {
                val dimVal = data.getInt("Dimmer")
                lastSentDimmer = dimVal
                runOnUiThread {
                    if (binding.dimmerSeekBar.progress != dimVal) {
                        binding.dimmerSeekBar.progress = dimVal
                        updateDimmerText(dimVal)
                    }
                }
            }
        } catch (_: Exception) {}
    }

    private fun updateUiRelay(idx: Int, isOn: Boolean) {
        val buttons = listOf(binding.btnRelay1, binding.btnRelay2, binding.btnRelay3, binding.btnRelay4)
        val btn = buttons[idx]
        if (isOn) {
            btn.text = getString(R.string.relay_on_label, idx + 1)
            btn.backgroundTintList = ColorStateList.valueOf("#4CAF50".toColorInt())
            btn.setTextColor("#FFFFFF".toColorInt())
        } else {
            btn.text = getString(R.string.relay_off_label, idx + 1)
            btn.backgroundTintList = ColorStateList.valueOf("#6200EE".toColorInt())
            btn.setTextColor("#FFFFFF".toColorInt())
        }
    }

    private fun updateConnectionStatusUI() {
        if (isIpConnected) {
            binding.tvConnectionStatus.text = getString(R.string.status_connected_ip)
            binding.tvConnectionStatus.setTextColor("#2E7D32".toColorInt())
            binding.btnConnectIp.text = getString(R.string.btn_disconnect)
            binding.btnConnectIp.backgroundTintList = ColorStateList.valueOf("#4CAF50".toColorInt())
        } else if (isMqttConnected) {
            binding.tvConnectionStatus.text = getString(R.string.status_connected_mqtt)
            binding.tvConnectionStatus.setTextColor("#2E7D32".toColorInt())
            binding.btnConnectIp.text = getString(R.string.btn_connect_ip)
            binding.btnConnectIp.backgroundTintList = ColorStateList.valueOf("#6200EE".toColorInt())
        } else {
            binding.tvConnectionStatus.text = getString(R.string.status_disconnected)
            binding.tvConnectionStatus.setTextColor("#D32F2F".toColorInt())
            binding.btnConnectIp.text = getString(R.string.btn_connect_ip)
            binding.btnConnectIp.backgroundTintList = ColorStateList.valueOf("#6200EE".toColorInt())
        }
    }

    private fun logMessage(msg: String) {
        runOnUiThread {
            binding.tvConsoleLog.append(msg)
            val innerHeight = binding.tvConsoleLog.layout?.height ?: 0
            if (innerHeight > binding.tvConsoleLog.height) {
                binding.tvConsoleLog.scrollTo(0, innerHeight - binding.tvConsoleLog.height)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        disconnectWebSocket()
        disconnectMqttClient()
    }
}